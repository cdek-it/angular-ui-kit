import { EnvironmentProviders } from '@angular/core';

declare function provideExtraThemes(): EnvironmentProviders;

export { provideExtraThemes };
