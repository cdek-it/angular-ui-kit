import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';

interface ExtraStepperItem {
    value: number | undefined;
    label: string;
    caption?: string;
    content?: string;
    disabled?: boolean;
    invalid?: boolean;
}
declare class ExtraStepperComponent {
    value: number | undefined;
    steps: ExtraStepperItem[];
    linear: boolean;
    orientation: 'horizontal' | 'vertical';
    showPanels: boolean;
    valueChange: EventEmitter<number>;
    onValueChange(newValue: number | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraStepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraStepperComponent, "extra-stepper", never, { "value": { "alias": "value"; "required": false; }; "steps": { "alias": "steps"; "required": false; }; "linear": { "alias": "linear"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "showPanels": { "alias": "showPanels"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

export { ExtraStepperComponent };
export type { ExtraStepperItem };
