import * as i0 from '@angular/core';

interface ExtraTabItem {
    value: string;
    label: string;
    icon?: string;
    disabled?: boolean;
    badge?: string;
    badgeSeverity?: 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast';
    content?: string;
}
declare class ExtraTabsComponent {
    value: string | number | undefined;
    tabs: ExtraTabItem[];
    scrollable: boolean;
    lazy: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraTabsComponent, "extra-tabs", never, { "value": { "alias": "value"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "scrollable": { "alias": "scrollable"; "required": false; }; "lazy": { "alias": "lazy"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraTabsComponent };
export type { ExtraTabItem };
