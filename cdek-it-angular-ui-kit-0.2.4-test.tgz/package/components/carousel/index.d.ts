import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter } from '@angular/core';
import { CarouselPageEvent, CarouselResponsiveOptions } from 'primeng/types/carousel';

type ExtraCarouselOrientation = 'horizontal' | 'vertical';
type ExtraCarouselPageEvent = CarouselPageEvent;
type ExtraCarouselResponsiveOptions = CarouselResponsiveOptions;
declare class ExtraCarouselItemDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraCarouselItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraCarouselItemDirective, "[extraCarouselItem]", never, {}, {}, never, never, true, never>;
}
declare class ExtraCarouselHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraCarouselHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraCarouselHeaderDirective, "[extraCarouselHeader]", never, {}, {}, never, never, true, never>;
}
declare class ExtraCarouselFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraCarouselFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraCarouselFooterDirective, "[extraCarouselFooter]", never, {}, {}, never, never, true, never>;
}
declare class ExtraCarouselComponent {
    value: any[];
    numVisible: number;
    numScroll: number;
    circular: boolean;
    orientation: ExtraCarouselOrientation;
    autoplayInterval: number;
    showIndicators: boolean;
    showNavigators: boolean;
    page: number;
    responsiveOptions: ExtraCarouselResponsiveOptions[] | undefined;
    verticalViewPortHeight: string;
    itemTemplate: TemplateRef<any> | null;
    headerTemplate: TemplateRef<any> | null;
    footerTemplate: TemplateRef<any> | null;
    onPage: EventEmitter<CarouselPageEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraCarouselComponent, "extra-carousel", never, { "value": { "alias": "value"; "required": false; }; "numVisible": { "alias": "numVisible"; "required": false; }; "numScroll": { "alias": "numScroll"; "required": false; }; "circular": { "alias": "circular"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "autoplayInterval": { "alias": "autoplayInterval"; "required": false; }; "showIndicators": { "alias": "showIndicators"; "required": false; }; "showNavigators": { "alias": "showNavigators"; "required": false; }; "page": { "alias": "page"; "required": false; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; }; "verticalViewPortHeight": { "alias": "verticalViewPortHeight"; "required": false; }; }, { "onPage": "onPage"; }, ["itemTemplate", "headerTemplate", "footerTemplate"], never, true, never>;
}

export { ExtraCarouselComponent, ExtraCarouselFooterDirective, ExtraCarouselHeaderDirective, ExtraCarouselItemDirective };
export type { ExtraCarouselOrientation, ExtraCarouselPageEvent, ExtraCarouselResponsiveOptions };
