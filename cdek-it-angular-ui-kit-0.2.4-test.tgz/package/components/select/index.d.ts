import * as i0 from '@angular/core';
import { OnInit, TemplateRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { SelectChangeEvent, SelectFilterEvent } from 'primeng/types/select';

type ExtraSelectSize = 'small' | 'base' | 'large' | 'xlarge';
type ExtraSelectLabelPosition = 'top' | 'left';
interface ExtraSelectOption {
    name: string;
    code: string | number;
}
interface ExtraSelectGroup {
    options: ExtraSelectOption[] | any[];
    name: string;
}
interface ExtraSelectChangeEvent {
    value: any;
    originalEvent: Event;
}
interface ExtraSelectFilterEvent {
    filter: string;
    originalEvent: Event;
}
declare class ExtraSelectOptionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSelectOptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraSelectOptionDirective, "[extraSelectOption]", never, {}, {}, never, never, true, never>;
}
declare class ExtraSelectSelectedItemDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSelectSelectedItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraSelectSelectedItemDirective, "[extraSelectSelectedItem]", never, {}, {}, never, never, true, never>;
}
declare class ExtraSelectOptionGroupDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSelectOptionGroupDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraSelectOptionGroupDirective, "[extraSelectOptionGroup]", never, {}, {}, never, never, true, never>;
}
declare class ExtraSelectComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private _ngControl;
    ngOnInit(): void;
    options: ExtraSelectGroup[] | ExtraSelectOption[] | any[] | null | undefined;
    optionLabel: string | undefined;
    optionValue: string | undefined;
    optionDisabled: string | undefined;
    optionGroupLabel: string | undefined;
    optionGroupChildren: string;
    group: boolean;
    placeholder: string;
    label: string;
    labelPosition: ExtraSelectLabelPosition;
    /** Плавающий лейбл внутри поля (PrimeNG `p-floatlabel`); перекрывает `labelPosition`. */
    floatLabel: boolean;
    caption: string;
    info: string;
    size: ExtraSelectSize;
    showFilter: boolean;
    /** Отображение иконки очистки поля при наличии значения. */
    clearable: boolean;
    showCheckbox: boolean;
    editable: boolean;
    readonly: boolean;
    loading: boolean;
    inputId: string | undefined;
    appendTo: any;
    checkmarkIcon: string;
    emptyMessage: string;
    emptyFilterMessage: string;
    optionTemplate: TemplateRef<any> | null;
    selectedItemTemplate: TemplateRef<any> | null;
    optionGroupTemplate: TemplateRef<any> | null;
    disabled: boolean;
    modelValue: any;
    onChange: EventEmitter<ExtraSelectChangeEvent>;
    onClear: EventEmitter<void>;
    onFilter: EventEmitter<ExtraSelectFilterEvent>;
    onShow: EventEmitter<void>;
    onHide: EventEmitter<void>;
    onFocus: EventEmitter<Event>;
    onBlur: EventEmitter<Event>;
    get invalid(): boolean;
    get primeSize(): 'small' | 'large' | undefined;
    get panelStyle(): Record<string, string>;
    get selectClasses(): Record<string, boolean>;
    private _onChange;
    private _onTouched;
    onSelectChange(event: SelectChangeEvent): void;
    onFilterHandler(event: SelectFilterEvent): void;
    handleBlur(event: Event): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraSelectComponent, "extra-select", never, { "options": { "alias": "options"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "optionValue": { "alias": "optionValue"; "required": false; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; }; "group": { "alias": "group"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "floatLabel": { "alias": "floatLabel"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "info": { "alias": "info"; "required": false; }; "size": { "alias": "size"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; "showCheckbox": { "alias": "showCheckbox"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "appendTo": { "alias": "appendTo"; "required": false; }; "checkmarkIcon": { "alias": "checkmarkIcon"; "required": false; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; }; }, { "onChange": "onChange"; "onClear": "onClear"; "onFilter": "onFilter"; "onShow": "onShow"; "onHide": "onHide"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["optionTemplate", "selectedItemTemplate", "optionGroupTemplate"], never, true, never>;
    static ngAcceptInputType_group: unknown;
    static ngAcceptInputType_floatLabel: unknown;
    static ngAcceptInputType_showFilter: unknown;
    static ngAcceptInputType_clearable: unknown;
    static ngAcceptInputType_showCheckbox: unknown;
    static ngAcceptInputType_editable: unknown;
    static ngAcceptInputType_readonly: unknown;
    static ngAcceptInputType_loading: unknown;
}

export { ExtraSelectComponent, ExtraSelectOptionDirective, ExtraSelectOptionGroupDirective, ExtraSelectSelectedItemDirective };
export type { ExtraSelectChangeEvent, ExtraSelectFilterEvent, ExtraSelectGroup, ExtraSelectLabelPosition, ExtraSelectOption, ExtraSelectSize };
