import * as i0 from '@angular/core';
import { AfterViewChecked, ElementRef } from '@angular/core';
import { ExtraMenuItem } from '@cdek-it/angular-ui-kit/shared';

declare class ExtraTieredMenuComponent implements AfterViewChecked {
    private readonly el;
    model: ExtraMenuItem[];
    autoDisplay: boolean;
    tabindex: number | undefined;
    private activeItemId;
    constructor(el: ElementRef<HTMLElement>);
    onItemClick(event: MouseEvent): void;
    ngAfterViewChecked(): void;
    private applyActiveClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTieredMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraTieredMenuComponent, "extra-tieredmenu", never, { "model": { "alias": "model"; "required": false; }; "autoDisplay": { "alias": "autoDisplay"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraTieredMenuComponent };
