import * as i0 from '@angular/core';

declare class ExtraScrollPanelComponent {
    step: number;
    height: string;
    width: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraScrollPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraScrollPanelComponent, "extra-scroll-panel", never, { "step": { "alias": "step"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}

export { ExtraScrollPanelComponent };
