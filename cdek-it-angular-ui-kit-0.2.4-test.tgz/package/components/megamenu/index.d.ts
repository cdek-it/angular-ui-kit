import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import { MegaMenuItem } from 'primeng/api';

type ExtraMegaMenuOrientation = 'horizontal' | 'vertical';
type ExtraMegaMenuItem = MegaMenuItem;
declare class ExtraMegaMenuItemDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMegaMenuItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraMegaMenuItemDirective, "[extraMegaMenuItem]", never, {}, {}, never, never, true, never>;
}
declare class ExtraMegaMenuComponent {
    model: ExtraMegaMenuItem[];
    orientation: ExtraMegaMenuOrientation;
    breakpoint: string;
    scrollHeight: string;
    disabled: boolean;
    ariaLabel: string | undefined;
    ariaLabelledBy: string | undefined;
    tabindex: number;
    itemTemplate: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMegaMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraMegaMenuComponent, "extra-megamenu", never, { "model": { "alias": "model"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "breakpoint": { "alias": "breakpoint"; "required": false; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, ["itemTemplate"], never, true, never>;
}

export { ExtraMegaMenuComponent, ExtraMegaMenuItemDirective };
export type { ExtraMegaMenuItem, ExtraMegaMenuOrientation };
