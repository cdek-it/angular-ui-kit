import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type ExtraInputNumberSize = 'small' | 'base' | 'large' | 'xlarge';
type ExtraInputNumberButtonLayout = 'stacked' | 'horizontal' | 'vertical';
declare class ExtraInputNumberComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private _ngControl;
    ngOnInit(): void;
    size: ExtraInputNumberSize;
    showButtons: boolean;
    buttonLayout: ExtraInputNumberButtonLayout;
    mode: string;
    currency: string | undefined;
    locale: string | undefined;
    placeholder: string;
    readonly: boolean;
    fluid: boolean;
    min: number | undefined;
    max: number | undefined;
    step: number;
    prefix: string | undefined;
    suffix: string | undefined;
    minFractionDigits: number | undefined;
    maxFractionDigits: number | undefined;
    useGrouping: boolean;
    incrementButtonIcon: string | undefined;
    decrementButtonIcon: string | undefined;
    disabled: boolean;
    get invalid(): boolean;
    onInput: EventEmitter<{
        value: number | null;
    }>;
    modelValue: number | null;
    private _onChange;
    onTouched: () => void;
    get inputSizeClass(): string;
    get sizeClass(): Record<string, boolean>;
    onModelChange(value: number | null): void;
    writeValue(value: number | null): void;
    registerOnChange(fn: (value: number | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraInputNumberComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraInputNumberComponent, "extra-input-number", never, { "size": { "alias": "size"; "required": false; }; "showButtons": { "alias": "showButtons"; "required": false; }; "buttonLayout": { "alias": "buttonLayout"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "currency": { "alias": "currency"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "prefix": { "alias": "prefix"; "required": false; }; "suffix": { "alias": "suffix"; "required": false; }; "minFractionDigits": { "alias": "minFractionDigits"; "required": false; }; "maxFractionDigits": { "alias": "maxFractionDigits"; "required": false; }; "useGrouping": { "alias": "useGrouping"; "required": false; }; "incrementButtonIcon": { "alias": "incrementButtonIcon"; "required": false; }; "decrementButtonIcon": { "alias": "decrementButtonIcon"; "required": false; }; }, { "onInput": "onInput"; }, never, never, true, never>;
}

export { ExtraInputNumberComponent };
export type { ExtraInputNumberButtonLayout, ExtraInputNumberSize };
