import * as i0 from '@angular/core';
import { AfterViewChecked, ElementRef } from '@angular/core';
import { ExtraMenuItem } from '@cdek-it/angular-ui-kit/shared';

declare class ExtraPanelMenuComponent implements AfterViewChecked {
    private readonly el;
    model: ExtraMenuItem[];
    multiple: boolean;
    tabindex: number | undefined;
    private activeItemId;
    constructor(el: ElementRef<HTMLElement>);
    onItemClick(event: MouseEvent): void;
    ngAfterViewChecked(): void;
    private applyActiveClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraPanelMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraPanelMenuComponent, "extra-panelmenu", never, { "model": { "alias": "model"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraPanelMenuComponent };
