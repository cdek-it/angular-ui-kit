import * as i0 from '@angular/core';

type ExtraInputGroupSize = 'small' | 'base' | 'large' | 'xlarge';
declare class ExtraInputGroupComponent {
    size: ExtraInputGroupSize;
    get sizeClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraInputGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraInputGroupComponent, "extra-input-group", never, { "size": { "alias": "size"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class ExtraInputGroupAddonComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraInputGroupAddonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraInputGroupAddonComponent, "extra-input-group-addon", never, {}, {}, never, ["*"], true, never>;
}

export { ExtraInputGroupAddonComponent, ExtraInputGroupComponent };
export type { ExtraInputGroupSize };
