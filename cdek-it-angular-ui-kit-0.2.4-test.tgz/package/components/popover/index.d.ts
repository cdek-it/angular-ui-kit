import * as i0 from '@angular/core';

declare class ExtraPopoverComponent {
    dismissable: boolean;
    appendTo: string | HTMLElement;
    private op;
    toggle(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraPopoverComponent, "extra-popover", never, { "dismissable": { "alias": "dismissable"; "required": false; }; "appendTo": { "alias": "appendTo"; "required": false; }; }, {}, never, ["*"], true, never>;
}

export { ExtraPopoverComponent };
