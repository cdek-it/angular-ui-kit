import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ButtonSeverity } from 'primeng/button';

type ExtraButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'text' | 'link';
type ExtraButtonSeverity = 'base' | 'danger' | 'warning' | 'success' | 'info';
type ExtraButtonSize = 'small' | 'base' | 'large' | 'xlarge';
type ExtraButtonIconPosition = 'left' | 'right';
declare class ExtraButtonComponent {
    label: string;
    icon: string;
    iconPosition: ExtraButtonIconPosition;
    variant: ExtraButtonVariant;
    severity: ExtraButtonSeverity;
    size: ExtraButtonSize;
    rounded: boolean;
    fluid: boolean;
    disabled: boolean;
    loading: boolean;
    focus: EventEmitter<FocusEvent>;
    blur: EventEmitter<FocusEvent>;
    get primeSize(): 'small' | 'large' | undefined;
    get primeStyleClass(): string;
    get primeSeverity(): ButtonSeverity;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraButtonComponent, "extra-button", never, { "label": { "alias": "label"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "severity": { "alias": "severity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "focus": "focus"; "blur": "blur"; }, never, never, true, never>;
}

export { ExtraButtonComponent };
export type { ExtraButtonIconPosition, ExtraButtonSeverity, ExtraButtonSize, ExtraButtonVariant };
