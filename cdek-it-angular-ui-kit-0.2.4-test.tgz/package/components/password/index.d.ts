import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type ExtraPasswordSize = 'small' | 'base' | 'large' | 'xlarge';
declare class ExtraPasswordHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraPasswordHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraPasswordHeaderDirective, "[extraPasswordHeader]", never, {}, {}, never, never, true, never>;
}
declare class ExtraPasswordFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraPasswordFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraPasswordFooterDirective, "[extraPasswordFooter]", never, {}, {}, never, never, true, never>;
}
declare class ExtraPasswordComponent implements ControlValueAccessor {
    headerTemplate: TemplateRef<any> | null;
    footerTemplate: TemplateRef<any> | null;
    feedback: boolean;
    toggleMask: boolean;
    disabled: boolean;
    placeholder: string | undefined;
    size: ExtraPasswordSize;
    variant: 'filled' | 'outlined';
    fluid: boolean;
    invalid: boolean;
    floatLabel: boolean;
    label: string;
    promptLabel: string;
    weakLabel: string;
    mediumLabel: string;
    strongLabel: string;
    inputId: string | undefined;
    inputStyleClass: string | undefined;
    ariaLabel: string | undefined;
    ariaLabelledBy: string | undefined;
    appendTo: any;
    autofocus: boolean;
    onFocus: EventEmitter<Event>;
    onBlur: EventEmitter<Event>;
    get sizeClass(): string;
    get computedInputStyleClass(): string;
    modelValue: string | null;
    private _onChange;
    private _onTouched;
    handleChange(value: string | null): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraPasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraPasswordComponent, "extra-password", never, { "feedback": { "alias": "feedback"; "required": false; }; "toggleMask": { "alias": "toggleMask"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "size": { "alias": "size"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "invalid": { "alias": "invalid"; "required": false; }; "floatLabel": { "alias": "floatLabel"; "required": false; }; "label": { "alias": "label"; "required": false; }; "promptLabel": { "alias": "promptLabel"; "required": false; }; "weakLabel": { "alias": "weakLabel"; "required": false; }; "mediumLabel": { "alias": "mediumLabel"; "required": false; }; "strongLabel": { "alias": "strongLabel"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "inputStyleClass": { "alias": "inputStyleClass"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; "appendTo": { "alias": "appendTo"; "required": false; }; "autofocus": { "alias": "autofocus"; "required": false; }; }, { "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["headerTemplate", "footerTemplate"], never, true, never>;
}

export { ExtraPasswordComponent, ExtraPasswordFooterDirective, ExtraPasswordHeaderDirective };
export type { ExtraPasswordSize };
