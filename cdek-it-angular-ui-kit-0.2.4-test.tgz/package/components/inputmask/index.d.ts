import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';

type ExtraInputMaskSize = 'small' | 'base' | 'large' | 'xlarge';
type ExtraInputMaskLabelPosition = 'top' | 'left';
declare class ExtraInputMaskComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private readonly destroyRef;
    private _ngControl;
    readonly control: FormControl<string>;
    /** Уникальный id поля для связи label ↔ input. */
    readonly inputId: string;
    mask: string;
    slotChar: string;
    autoClear: boolean;
    /** Отображение иконки очистки поля при наличии значения. */
    clearable: boolean;
    unmask: boolean;
    placeholder: string;
    label: string;
    labelPosition: ExtraInputMaskLabelPosition;
    /** Плавающий лейбл внутри поля (PrimeNG `p-floatlabel`); перекрывает `labelPosition`. */
    floatLabel: boolean;
    caption: string;
    info: string;
    size: ExtraInputMaskSize;
    readonly: boolean;
    /** Растягивает поле на всю ширину контейнера. */
    fluid: boolean;
    characterPattern: string;
    keepBuffer: boolean;
    autocomplete: string;
    onComplete: EventEmitter<void>;
    onFocus: EventEmitter<Event>;
    onBlur: EventEmitter<Event>;
    onInput: EventEmitter<Event>;
    onClear: EventEmitter<void>;
    private _onChange;
    private _onTouched;
    ngOnInit(): void;
    get invalid(): boolean;
    get primeSize(): 'small' | 'large' | undefined;
    /**
     * Классы на сам input (p-inputmask прокидывает styleClass именно туда):
     * xlg — размер вне шкалы PrimeNG, clearable — место под иконку очистки справа.
     * Класс вешаем по пропу, а не по наличию иконки: иконка появляется только у
     * заполненного поля, и padding прыгал бы на первом введённом символе.
     */
    get fieldClass(): string;
    /**
     * p-inputmask пишет placeholder в атрибут как есть, а FloatLabel поднимает лейбл
     * по селектору `:has(input[placeholder])` — с пустой строкой атрибут остаётся в DOM
     * и лейбл висит наверху всегда. Пустое значение отдаём как undefined.
     */
    get fieldPlaceholder(): string | undefined;
    handleBlur(event: Event): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraInputMaskComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraInputMaskComponent, "extra-input-mask", never, { "mask": { "alias": "mask"; "required": false; }; "slotChar": { "alias": "slotChar"; "required": false; }; "autoClear": { "alias": "autoClear"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; "unmask": { "alias": "unmask"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "floatLabel": { "alias": "floatLabel"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "info": { "alias": "info"; "required": false; }; "size": { "alias": "size"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "characterPattern": { "alias": "characterPattern"; "required": false; }; "keepBuffer": { "alias": "keepBuffer"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; }, { "onComplete": "onComplete"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onInput": "onInput"; "onClear": "onClear"; }, never, never, true, never>;
    static ngAcceptInputType_autoClear: unknown;
    static ngAcceptInputType_clearable: unknown;
    static ngAcceptInputType_unmask: unknown;
    static ngAcceptInputType_floatLabel: unknown;
    static ngAcceptInputType_readonly: unknown;
    static ngAcceptInputType_fluid: unknown;
    static ngAcceptInputType_keepBuffer: unknown;
}

export { ExtraInputMaskComponent };
export type { ExtraInputMaskLabelPosition, ExtraInputMaskSize };
