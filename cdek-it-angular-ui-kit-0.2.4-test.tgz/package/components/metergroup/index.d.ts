import { MeterItem } from 'primeng/metergroup';
import * as i0 from '@angular/core';

type ExtraMeterGroupOrientation = 'horizontal' | 'vertical';
type ExtraMeterGroupLabelPosition = 'start' | 'end';
type ExtraMeterGroupLabelOrientation = 'horizontal' | 'vertical';
type ExtraMeterItem = MeterItem;
declare class ExtraMeterGroupComponent {
    value: ExtraMeterItem[];
    orientation: ExtraMeterGroupOrientation;
    labelPosition: ExtraMeterGroupLabelPosition;
    labelOrientation: ExtraMeterGroupLabelOrientation;
    get hostDisplay(): string;
    get hostHeight(): string;
    get hostFlex(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMeterGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraMeterGroupComponent, "extra-metergroup", never, { "value": { "alias": "value"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "labelOrientation": { "alias": "labelOrientation"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraMeterGroupComponent };
export type { ExtraMeterGroupLabelOrientation, ExtraMeterGroupLabelPosition, ExtraMeterGroupOrientation, ExtraMeterItem };
