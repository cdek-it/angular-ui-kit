import * as i0 from '@angular/core';
import { TemplateRef, Provider } from '@angular/core';
import { ExtraButtonSeverity } from '@cdek-it/angular-ui-kit/components/button';
import { Confirmation, ConfirmationService } from 'primeng/api';

type ExtraConfirmDialogSize = 'sm' | 'default' | 'lg' | 'xlg';
type ExtraConfirmDialogSeverity = 'success' | 'info' | 'warning' | 'help' | 'danger' | 'default';
declare class ExtraConfirmDialogHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraConfirmDialogHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraConfirmDialogHeaderDirective, "[extraConfirmDialogHeader]", never, {}, {}, never, never, true, never>;
}
declare class ExtraConfirmDialogFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraConfirmDialogFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraConfirmDialogFooterDirective, "[extraConfirmDialogFooter]", never, {}, {}, never, never, true, never>;
}
declare class ExtraConfirmDialogComponent {
    key: string;
    size: ExtraConfirmDialogSize;
    severity: ExtraConfirmDialogSeverity;
    headerTemplate: TemplateRef<any> | null;
    footerTemplate: TemplateRef<any> | null;
    mapSeverity(severity: string | null | undefined): ExtraButtonSeverity;
    get computedClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraConfirmDialogComponent, "extra-confirm-dialog", never, { "key": { "alias": "key"; "required": false; }; "size": { "alias": "size"; "required": false; }; "severity": { "alias": "severity"; "required": false; }; }, {}, ["headerTemplate", "footerTemplate"], never, true, never>;
}

type ExtraConfirmDialogOptions = Pick<Confirmation, 'key' | 'message' | 'header' | 'icon' | 'acceptLabel' | 'rejectLabel' | 'accept' | 'reject' | 'acceptButtonProps'>;
declare function provideExtraConfirmDialog(): Provider[];
declare class ExtraConfirmDialogService {
    private readonly confirmationService;
    constructor(confirmationService: ConfirmationService);
    confirm(options: ExtraConfirmDialogOptions): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraConfirmDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExtraConfirmDialogService>;
}

export { ExtraConfirmDialogComponent, ExtraConfirmDialogFooterDirective, ExtraConfirmDialogHeaderDirective, ExtraConfirmDialogService, provideExtraConfirmDialog };
export type { ExtraConfirmDialogOptions, ExtraConfirmDialogSeverity, ExtraConfirmDialogSize };
