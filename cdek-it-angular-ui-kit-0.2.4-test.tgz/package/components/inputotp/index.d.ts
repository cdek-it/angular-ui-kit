import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';
import { InputOtpChangeEvent } from 'primeng/inputotp';

type ExtraInputOtpSize = 'small' | 'base' | 'large';
interface ExtraInputOtpChangeEvent {
    value: string;
    originalEvent: Event;
}
declare class ExtraInputOtpComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private readonly _cdr;
    private readonly destroyRef;
    private _ngControl;
    readonly control: FormControl<string>;
    length: number;
    mask: boolean;
    integerOnly: boolean;
    /** Размер ячейки. */
    size: ExtraInputOtpSize;
    disabled: boolean;
    /** PrimeNG знает только small/large; base — размер по умолчанию, без класса. */
    protected get primeSize(): 'small' | 'large' | undefined;
    onChange: EventEmitter<ExtraInputOtpChangeEvent>;
    private _onChange;
    private _onTouched;
    ngOnInit(): void;
    get invalid(): boolean;
    onChangeHandler(event: InputOtpChangeEvent): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraInputOtpComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraInputOtpComponent, "extra-input-otp", never, { "length": { "alias": "length"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "integerOnly": { "alias": "integerOnly"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}

export { ExtraInputOtpComponent };
export type { ExtraInputOtpChangeEvent, ExtraInputOtpSize };
