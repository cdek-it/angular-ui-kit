import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type ExtraInputTextSize = 'small' | 'base' | 'large' | 'xlarge';
type ExtraInputTextLabelPosition = 'default' | 'float' | 'left';
type ExtraInputTextType = 'text' | 'password';
declare class ExtraInputTextComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private _ngControl;
    ngOnInit(): void;
    placeholder: string;
    label: string;
    labelPosition: ExtraInputTextLabelPosition;
    clearable: boolean;
    caption: string;
    info: string;
    size: ExtraInputTextSize;
    /** Растягивает поле на всю ширину контейнера. */
    fluid: boolean;
    type: ExtraInputTextType;
    /** Уникальный id поля для связи label ↔ input. */
    readonly inputId: string;
    disabled: boolean;
    get invalid(): boolean;
    onClear: EventEmitter<void>;
    modelValue: string;
    private _onChange;
    get primeSize(): 'small' | 'large' | undefined;
    get sizeClass(): Record<string, boolean>;
    onInput(event: Event): void;
    onTouched: () => void;
    clearValue(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraInputTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraInputTextComponent, "extra-input-text", never, { "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "info": { "alias": "info"; "required": false; }; "size": { "alias": "size"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, { "onClear": "onClear"; }, never, never, true, never>;
    static ngAcceptInputType_clearable: unknown;
    static ngAcceptInputType_fluid: unknown;
}

export { ExtraInputTextComponent };
export type { ExtraInputTextLabelPosition, ExtraInputTextSize, ExtraInputTextType };
