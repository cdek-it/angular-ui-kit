import { ExtraMenuItem } from '@cdek-it/angular-ui-kit/shared';
import * as i0 from '@angular/core';

declare class ExtraBreadcrumbComponent {
    model: ExtraMenuItem[];
    home: ExtraMenuItem | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraBreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraBreadcrumbComponent, "extra-breadcrumb", never, { "model": { "alias": "model"; "required": false; }; "home": { "alias": "home"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraBreadcrumbComponent };
