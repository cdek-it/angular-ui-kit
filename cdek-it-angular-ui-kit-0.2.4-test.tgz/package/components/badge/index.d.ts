import { Badge } from 'primeng/badge';
import * as i0 from '@angular/core';

type ExtraBadgeSeverity = 'primary' | 'success' | 'info' | 'warning' | 'danger';
type ExtraBadgeSize = 'base' | 'large' | 'xlarge';
type PrimeBadgeSeverity = ReturnType<Badge['severity']>;
type PrimeBadgeSize = ReturnType<Badge['size']>;
declare class ExtraBadgeComponent {
    value: string | number;
    severity: ExtraBadgeSeverity;
    size: ExtraBadgeSize;
    get primeSeverity(): PrimeBadgeSeverity;
    get primeSize(): PrimeBadgeSize;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraBadgeComponent, "extra-badge", never, { "value": { "alias": "value"; "required": false; }; "severity": { "alias": "severity"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraBadgeComponent };
export type { ExtraBadgeSeverity, ExtraBadgeSize };
