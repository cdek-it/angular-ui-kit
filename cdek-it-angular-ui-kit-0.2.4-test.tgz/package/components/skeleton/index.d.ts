import * as i0 from '@angular/core';

type ExtraSkeletonShape = 'rectangle' | 'circle';
type ExtraSkeletonAnimation = 'wave' | 'none';
declare class ExtraSkeletonComponent {
    shape: ExtraSkeletonShape;
    animation: ExtraSkeletonAnimation;
    width: string;
    height: string;
    size: string | undefined;
    borderRadius: string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraSkeletonComponent, "extra-skeleton", never, { "shape": { "alias": "shape"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; "size": { "alias": "size"; "required": false; }; "borderRadius": { "alias": "borderRadius"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraSkeletonComponent };
export type { ExtraSkeletonAnimation, ExtraSkeletonShape };
