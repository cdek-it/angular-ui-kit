import * as i0 from '@angular/core';

type ExtraAvatarSize = 'base' | 'large' | 'xlarge';
type ExtraAvatarShape = 'square' | 'circle';
declare class ExtraAvatarComponent {
    label: string;
    icon: string;
    image: string;
    size: ExtraAvatarSize;
    shape: ExtraAvatarShape;
    get hostClass(): string;
    get primeSize(): 'large' | 'xlarge' | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraAvatarComponent, "extra-avatar", never, { "label": { "alias": "label"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "image": { "alias": "image"; "required": false; }; "size": { "alias": "size"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; }, {}, never, never, true, never>;
}
declare class ExtraAvatarGroupComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraAvatarGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraAvatarGroupComponent, "extra-avatar-group", never, {}, {}, never, ["*"], true, never>;
}

export { ExtraAvatarComponent, ExtraAvatarGroupComponent };
export type { ExtraAvatarShape, ExtraAvatarSize };
