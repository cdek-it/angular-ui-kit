import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';

interface ExtraAccordionItem {
    value: string;
    header: string;
    content: string;
    icon?: string;
    disabled?: boolean;
}
declare class ExtraAccordionComponent {
    items: ExtraAccordionItem[];
    multiple: boolean;
    activeValue: string | null;
    activeValueChange: EventEmitter<string | number | string[] | number[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraAccordionComponent, "extra-accordion", never, { "items": { "alias": "items"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "activeValue": { "alias": "activeValue"; "required": false; }; }, { "activeValueChange": "activeValueChange"; }, never, never, true, never>;
}

export { ExtraAccordionComponent };
export type { ExtraAccordionItem };
