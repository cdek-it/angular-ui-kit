import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { CheckboxChangeEvent } from 'primeng/checkbox';

type ExtraCheckboxLabelPosition = 'right' | 'left';
interface ExtraCheckboxChangeEvent {
    checked: boolean;
    originalEvent: Event;
}
declare class ExtraCheckboxComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private _ngControl;
    ngOnInit(): void;
    label: string;
    labelPosition: ExtraCheckboxLabelPosition;
    caption: string;
    indeterminate: boolean;
    onChange: EventEmitter<ExtraCheckboxChangeEvent>;
    /** Уникальный id поля для связи label ↔ input. */
    readonly inputId: string;
    disabled: boolean;
    modelValue: boolean;
    get invalid(): boolean;
    private _onChange;
    private _onTouched;
    onChangeHandler(event: CheckboxChangeEvent): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraCheckboxComponent, "extra-checkbox", never, { "label": { "alias": "label"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}

export { ExtraCheckboxComponent };
export type { ExtraCheckboxChangeEvent, ExtraCheckboxLabelPosition };
