import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';

type ExtraTimelineLine = 'solid' | 'dashed' | 'dotted' | 'none';
declare class ExtraTimelineContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTimelineContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraTimelineContentDirective, "[extraTimelineContent]", never, {}, {}, never, never, true, never>;
}
declare class ExtraTimelineOppositeDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTimelineOppositeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraTimelineOppositeDirective, "[extraTimelineOpposite]", never, {}, {}, never, never, true, never>;
}
declare class ExtraTimelineMarkerDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTimelineMarkerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraTimelineMarkerDirective, "[extraTimelineMarker]", never, {}, {}, never, never, true, never>;
}
declare class ExtraTimelineComponent {
    value: any[];
    align: 'left' | 'right' | 'alternate' | 'top' | 'bottom';
    layout: 'vertical' | 'horizontal';
    showCaption: boolean;
    line: ExtraTimelineLine;
    icon: string;
    markerColor: string;
    get dataLine(): ExtraTimelineLine;
    get markerColorVar(): string;
    contentTemplate?: TemplateRef<any>;
    oppositeTemplate?: TemplateRef<any>;
    markerTemplate?: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTimelineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraTimelineComponent, "extra-timeline", never, { "value": { "alias": "value"; "required": false; }; "align": { "alias": "align"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "showCaption": { "alias": "showCaption"; "required": false; }; "line": { "alias": "line"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "markerColor": { "alias": "markerColor"; "required": false; }; }, {}, ["contentTemplate", "oppositeTemplate", "markerTemplate"], never, true, never>;
}

export { ExtraTimelineComponent, ExtraTimelineContentDirective, ExtraTimelineMarkerDirective, ExtraTimelineOppositeDirective };
export type { ExtraTimelineLine };
