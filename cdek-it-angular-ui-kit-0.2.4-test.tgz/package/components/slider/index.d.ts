import * as i0 from '@angular/core';
import { OnChanges, OnDestroy, EventEmitter, SimpleChanges } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';
import { SliderSlideEndEvent } from 'primeng/slider';

type ExtraSliderOrientation = 'horizontal' | 'vertical';
type ExtraSliderSlideEndEvent = SliderSlideEndEvent;
declare class ExtraSliderComponent implements ControlValueAccessor, OnChanges, OnDestroy {
    min: number;
    max: number;
    step: number | undefined;
    range: boolean;
    orientation: ExtraSliderOrientation;
    set disabled(value: boolean);
    onSlideEnd: EventEmitter<SliderSlideEndEvent>;
    readonly control: FormControl<number | number[]>;
    private _onChange;
    private _onTouched;
    private readonly _sub;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    writeValue(value: number | number[]): void;
    registerOnChange(fn: (value: number | number[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    private normalize;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraSliderComponent, "extra-slider", never, { "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "range": { "alias": "range"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "onSlideEnd": "onSlideEnd"; }, never, never, true, never>;
}

export { ExtraSliderComponent };
export type { ExtraSliderOrientation, ExtraSliderSlideEndEvent };
