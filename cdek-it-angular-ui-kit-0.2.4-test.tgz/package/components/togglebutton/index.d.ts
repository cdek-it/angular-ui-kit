import * as i0 from '@angular/core';
import { ChangeDetectorRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ToggleButtonChangeEvent } from 'primeng/togglebutton';

type ExtraToggleButtonSize = 'small' | 'base' | 'large' | 'xlarge';
declare class ExtraToggleButtonComponent implements ControlValueAccessor {
    private cdr;
    constructor(cdr: ChangeDetectorRef);
    onLabel: string;
    offLabel: string;
    onIcon: string | undefined;
    offIcon: string | undefined;
    iconPos: 'left' | 'right';
    size: ExtraToggleButtonSize;
    disabled: boolean;
    iconOnly: boolean;
    allowEmpty: boolean | undefined;
    fluid: boolean;
    ariaLabel: string | undefined;
    ariaLabelledBy: string | undefined;
    inputId: string | undefined;
    tabindex: number | undefined;
    autofocus: boolean | undefined;
    onChange: EventEmitter<ToggleButtonChangeEvent>;
    modelValue: boolean;
    private _onChange;
    private _onTouched;
    get primeSize(): 'small' | 'large' | undefined;
    get extraClasses(): Record<string, boolean>;
    onChangeHandler(event: ToggleButtonChangeEvent): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraToggleButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraToggleButtonComponent, "extra-toggle-button", never, { "onLabel": { "alias": "onLabel"; "required": false; }; "offLabel": { "alias": "offLabel"; "required": false; }; "onIcon": { "alias": "onIcon"; "required": false; }; "offIcon": { "alias": "offIcon"; "required": false; }; "iconPos": { "alias": "iconPos"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; "autofocus": { "alias": "autofocus"; "required": false; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}

export { ExtraToggleButtonComponent };
export type { ExtraToggleButtonSize };
