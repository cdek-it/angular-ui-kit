import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ListboxChangeEvent } from 'primeng/listbox';

type ExtraListboxChangeEvent = ListboxChangeEvent;
declare class ExtraListboxItemDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraListboxItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraListboxItemDirective, "[extraListboxItem]", never, {}, {}, never, never, true, never>;
}
declare class ExtraListboxComponent implements ControlValueAccessor {
    options: any[];
    optionLabel: string;
    optionValue: string | undefined;
    multiple: boolean;
    filter: boolean;
    filterPlaceHolder: string | undefined;
    checkmark: boolean;
    group: boolean;
    optionGroupLabel: string | undefined;
    optionGroupChildren: string | undefined;
    scrollHeight: string;
    emptyMessage: string | undefined;
    itemTemplate: TemplateRef<any> | null;
    onFocus: EventEmitter<FocusEvent>;
    onBlur: EventEmitter<FocusEvent>;
    protected modelValue: any;
    private _disabled;
    private _onChange;
    private _onTouched;
    get isDisabled(): boolean;
    onChangeHandler(event: ExtraListboxChangeEvent): void;
    onBlurHandler(event: FocusEvent): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraListboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraListboxComponent, "extra-listbox", never, { "options": { "alias": "options"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "optionValue": { "alias": "optionValue"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "filterPlaceHolder": { "alias": "filterPlaceHolder"; "required": false; }; "checkmark": { "alias": "checkmark"; "required": false; }; "group": { "alias": "group"; "required": false; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; }; }, { "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["itemTemplate"], never, true, never>;
}

export { ExtraListboxComponent, ExtraListboxItemDirective };
export type { ExtraListboxChangeEvent };
