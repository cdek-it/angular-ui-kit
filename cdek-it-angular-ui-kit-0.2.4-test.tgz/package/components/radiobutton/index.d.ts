import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { RadioButtonClickEvent } from 'primeng/radiobutton';

type ExtraRadiobuttonVariant = 'outlined' | 'filled';
type ExtraRadiobuttonSize = 'small' | 'base' | 'large';
type ExtraRadioButtonClickEvent = RadioButtonClickEvent;
declare class ExtraRadiobuttonComponent implements ControlValueAccessor {
    value: any;
    name: string | undefined;
    disabled: boolean;
    invalid: boolean;
    variant: ExtraRadiobuttonVariant;
    size: ExtraRadiobuttonSize;
    inputId: string | undefined;
    tabindex: number | undefined;
    ariaLabel: string | undefined;
    ariaLabelledBy: string | undefined;
    autofocus: boolean;
    onClick: EventEmitter<RadioButtonClickEvent>;
    onFocus: EventEmitter<Event>;
    onBlur: EventEmitter<Event>;
    modelValue: any;
    private _onChange;
    private _onTouched;
    get primeSize(): 'small' | 'large' | undefined;
    get primeVariant(): 'filled' | undefined;
    onClickHandler(event: ExtraRadioButtonClickEvent): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraRadiobuttonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraRadiobuttonComponent, "extra-radiobutton", never, { "value": { "alias": "value"; "required": false; }; "name": { "alias": "name"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "invalid": { "alias": "invalid"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "size": { "alias": "size"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; "autofocus": { "alias": "autofocus"; "required": false; }; }, { "onClick": "onClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}

export { ExtraRadiobuttonComponent };
export type { ExtraRadioButtonClickEvent, ExtraRadiobuttonSize, ExtraRadiobuttonVariant };
