import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import { ExtraMenuItem } from '@cdek-it/angular-ui-kit/shared';

declare class ExtraMenubarItemDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMenubarItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraMenubarItemDirective, "[extraMenubarItem]", never, {}, {}, never, never, true, never>;
}
declare class ExtraMenubarComponent {
    model: ExtraMenuItem[];
    itemTemplate: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMenubarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraMenubarComponent, "extra-menubar", never, { "model": { "alias": "model"; "required": false; }; }, {}, ["itemTemplate"], never, true, never>;
}

export { ExtraMenubarComponent, ExtraMenubarItemDirective };
