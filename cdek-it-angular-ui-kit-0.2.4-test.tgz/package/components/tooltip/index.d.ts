import * as i0 from '@angular/core';
import { OnChanges, SimpleChanges } from '@angular/core';
import * as i1 from 'primeng/tooltip';

type ExtraTooltipPosition = 'right' | 'left' | 'top' | 'bottom';
type ExtraTooltipEvent = 'hover' | 'focus' | 'both';
declare class ExtraTooltipDirective implements OnChanges {
    private readonly delegate;
    /** Текст подсказки — соответствует Figma-свойству `text-tooltip`. */
    tooltip: string | undefined;
    /** Позиция подсказки относительно хост-элемента. */
    position: ExtraTooltipPosition;
    /** Событие, по которому показывается подсказка. */
    event: ExtraTooltipEvent;
    /** Задержка перед появлением подсказки в миллисекундах. */
    showDelay: number | undefined;
    /** Задержка перед скрытием подсказки в миллисекундах. */
    hideDelay: number | undefined;
    /**
     * Отключает подсказку. Названо `tooltipDisabled`, а не `disabled`, чтобы не
     * конфликтовать с одноимённым свойством хост-компонента (например, `extra-button`).
     */
    tooltipDisabled: boolean;
    ngOnChanges(_changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraTooltipDirective, "[extra-tooltip]", never, { "tooltip": { "alias": "extra-tooltip"; "required": false; }; "position": { "alias": "position"; "required": false; }; "event": { "alias": "event"; "required": false; }; "showDelay": { "alias": "showDelay"; "required": false; }; "hideDelay": { "alias": "hideDelay"; "required": false; }; "tooltipDisabled": { "alias": "tooltipDisabled"; "required": false; }; }, {}, never, never, true, [{ directive: typeof i1.Tooltip; inputs: {}; outputs: {}; }]>;
}

export { ExtraTooltipDirective };
export type { ExtraTooltipEvent, ExtraTooltipPosition };
