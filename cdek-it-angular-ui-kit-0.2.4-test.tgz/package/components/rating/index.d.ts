import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type ExtraRatingValue = number | null;
declare class ExtraRatingComponent implements ControlValueAccessor {
    stars: number;
    readonly: boolean;
    disabled: boolean;
    autofocus: boolean;
    onRate: EventEmitter<any>;
    onFocus: EventEmitter<FocusEvent>;
    onBlur: EventEmitter<FocusEvent>;
    modelValue: ExtraRatingValue;
    private onChange;
    private onTouched;
    handleChange(value: ExtraRatingValue): void;
    writeValue(value: ExtraRatingValue): void;
    registerOnChange(fn: (value: ExtraRatingValue) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraRatingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraRatingComponent, "extra-rating", never, { "stars": { "alias": "stars"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "autofocus": { "alias": "autofocus"; "required": false; }; }, { "onRate": "onRate"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}

export { ExtraRatingComponent };
export type { ExtraRatingValue };
