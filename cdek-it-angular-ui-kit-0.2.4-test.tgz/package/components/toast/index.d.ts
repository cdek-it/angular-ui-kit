import * as i0 from '@angular/core';
import { EnvironmentProviders } from '@angular/core';
import { MessageService } from 'primeng/api';

type ExtraToastSeverity = 'success' | 'info' | 'warn' | 'error' | 'secondary' | 'contrast';
type ExtraToastPosition = 'top-right' | 'top-left' | 'top-center' | 'bottom-right' | 'bottom-left' | 'bottom-center' | 'center';
declare class ExtraToastComponent {
    position: ExtraToastPosition;
    key: string | undefined;
    life: number;
    pt: Record<string, any> | undefined;
    resolveIcon(message: {
        severity?: string;
        icon?: string;
    }): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraToastComponent, "extra-toast", never, { "position": { "alias": "position"; "required": false; }; "key": { "alias": "key"; "required": false; }; "life": { "alias": "life"; "required": false; }; "pt": { "alias": "pt"; "required": false; }; }, {}, never, never, true, never>;
}

interface ExtraToastMessage {
    key?: string;
    severity?: ExtraToastSeverity;
    summary?: string;
    detail?: string;
    life?: number;
    icon?: string;
    closable?: boolean;
    data?: unknown;
}
declare class ExtraToastService {
    private readonly messageService;
    constructor(messageService: MessageService);
    add(message: ExtraToastMessage): void;
    clear(key?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExtraToastService>;
}

/**
 * Регистрирует зависимости, необходимые для работы `ExtraToastService` и `<extra-toast>`.
 * Вызывать один раз в `ApplicationConfig.providers` или в `bootstrapApplication`.
 *
 * @example
 * // app.config.ts
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideExtraToast()],
 * };
 */
declare function provideExtraToast(): EnvironmentProviders;

export { ExtraToastComponent, ExtraToastService, provideExtraToast };
export type { ExtraToastMessage, ExtraToastPosition, ExtraToastSeverity };
