import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';

declare class ExtraChipComponent {
    label: string;
    icon: string;
    removable: boolean;
    disabled: boolean;
    onRemove: EventEmitter<MouseEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraChipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraChipComponent, "extra-chip", never, { "label": { "alias": "label"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "removable": { "alias": "removable"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "onRemove": "onRemove"; }, never, never, true, never>;
}

export { ExtraChipComponent };
