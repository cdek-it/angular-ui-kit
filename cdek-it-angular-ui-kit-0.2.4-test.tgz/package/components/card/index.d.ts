import * as i0 from '@angular/core';
import { AfterContentInit, QueryList, ChangeDetectorRef } from '@angular/core';
import { PrimeTemplate } from 'primeng/api';

declare class ExtraCardComponent implements AfterContentInit {
    private cdr;
    title: string;
    subtitle: string;
    overlay: boolean;
    templates: QueryList<PrimeTemplate>;
    headerTpl?: PrimeTemplate;
    contentTpl?: PrimeTemplate;
    footerTpl?: PrimeTemplate;
    constructor(cdr: ChangeDetectorRef);
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraCardComponent, "extra-card", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "overlay": { "alias": "overlay"; "required": false; }; }, {}, ["templates"], never, true, never>;
}

export { ExtraCardComponent };
