import * as i0 from '@angular/core';

type ExtraTagSeverity = 'primary' | 'secondary' | 'info' | 'success' | 'warning' | 'danger';
declare class ExtraTagComponent {
    value: string;
    severity: ExtraTagSeverity;
    rounded: boolean;
    icon: string;
    get primeSeverity(): 'secondary' | 'success' | 'info' | 'warn' | 'danger' | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraTagComponent, "extra-tag", never, { "value": { "alias": "value"; "required": false; }; "severity": { "alias": "severity"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraTagComponent };
export type { ExtraTagSeverity };
