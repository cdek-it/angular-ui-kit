import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { PaginatorState } from 'primeng/types/paginator';

type ExtraPaginatorState = PaginatorState;
declare class ExtraPaginatorComponent {
    first: number;
    rows: number;
    totalRecords: number;
    rowsPerPageOptions: any[] | undefined;
    currentPageReportTemplate: string;
    showCurrentPageReport: boolean;
    showFirstLastIcon: boolean;
    showJumpToPageDropdown: boolean;
    showJumpToPageInput: boolean;
    showPageLinks: boolean;
    pageLinkSize: number;
    alwaysShow: boolean;
    onPageChange: EventEmitter<PaginatorState>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraPaginatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraPaginatorComponent, "extra-paginator", never, { "first": { "alias": "first"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "totalRecords": { "alias": "totalRecords"; "required": false; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; }; "showJumpToPageInput": { "alias": "showJumpToPageInput"; "required": false; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; }; "pageLinkSize": { "alias": "pageLinkSize"; "required": false; }; "alwaysShow": { "alias": "alwaysShow"; "required": false; }; }, { "onPageChange": "onPageChange"; }, never, never, true, never>;
}

export { ExtraPaginatorComponent };
export type { ExtraPaginatorState };
