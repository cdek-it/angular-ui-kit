import * as i0 from '@angular/core';
import { TemplateRef, ElementRef, AfterContentInit, AfterViewInit, OnChanges, OnDestroy, EventEmitter, SimpleChanges } from '@angular/core';
import { MenuItem } from 'primeng/api';

type ExtraMenuTemplateName = 'item' | 'submenuHeader' | 'start' | 'end';
/**
 * Именованный шаблон для слотов ExtraMenuComponent.
 *
 * ```html
 * <extra-menu [items]="items">
 *   <ng-template extraMenuTemplate="start">…</ng-template>
 *   <ng-template extraMenuTemplate="item" let-item>…</ng-template>
 *   <ng-template extraMenuTemplate="submenuHeader" let-group>…</ng-template>
 *   <ng-template extraMenuTemplate="end">…</ng-template>
 * </extra-menu>
 * ```
 */
declare class ExtraMenuTemplateDirective {
    template: TemplateRef<unknown>;
    /** Имя слота: item | submenuHeader | start | end. */
    extraMenuTemplate: ExtraMenuTemplateName;
    constructor(template: TemplateRef<unknown>);
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMenuTemplateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraMenuTemplateDirective, "[extraMenuTemplate]", never, { "extraMenuTemplate": { "alias": "extraMenuTemplate"; "required": true; }; }, {}, never, never, true, never>;
}

type ExtraMenuAction = {
    label?: string;
    caption?: string;
    icon?: string;
    iconEnd?: string;
    selected?: boolean;
    disabled?: boolean;
    visible?: boolean;
    href?: string;
    target?: string;
    command?: (event: ExtraMenuItemSelectEvent) => void;
    id?: string;
};
type ExtraMenuGroup = {
    label?: string;
    items: ExtraMenuAction[];
    visible?: boolean;
    id?: string;
};
type ExtraMenuSeparator = {
    separator: true;
};
type ExtraMenuItem = ExtraMenuAction | ExtraMenuGroup | ExtraMenuSeparator;
interface ExtraMenuItemSelectEvent {
    item: ExtraMenuAction;
    originalEvent: unknown;
}
type ExtraMenuElementLike = HTMLElement | ElementRef<HTMLElement>;
type ExtraMenuAppendTo = 'body' | 'self' | ExtraMenuElementLike;
type ExtraMenuAnchorLike = Event | ExtraMenuElementLike | {
    x: number;
    y: number;
};
declare class ExtraMenuComponent implements AfterContentInit, AfterViewInit, OnChanges, OnDestroy {
    items: ExtraMenuItem[];
    popup: boolean;
    open: boolean;
    appendTo: ExtraMenuAppendTo;
    ariaLabel?: string;
    onItemSelect: EventEmitter<ExtraMenuItemSelectEvent>;
    onShow: EventEmitter<void>;
    onHide: EventEmitter<void>;
    private menuRef;
    private templates;
    itemTpl?: ExtraMenuTemplateDirective;
    submenuHeaderTpl?: ExtraMenuTemplateDirective;
    startTpl?: ExtraMenuTemplateDirective;
    endTpl?: ExtraMenuTemplateDirective;
    private readonly elementRef;
    private readonly document;
    private readonly cdr;
    private syntheticAnchor?;
    private suppressOpenSync;
    get resolvedAppendTo(): 'body' | HTMLElement | undefined;
    primeItems: MenuItem[];
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Переключить всплывающее меню. */
    toggle(anchor?: ExtraMenuAnchorLike): void;
    /** Открыть всплывающее меню. При отсутствии anchor используется хост-элемент компонента. */
    show(anchor?: ExtraMenuAnchorLike): void;
    /** Закрыть всплывающее меню. */
    hide(): void;
    handleShow(): void;
    handleHide(): void;
    /**
     * PrimeNG раздаёт `model` через *ngFor без trackBy: новый объект пункта — это пересоздание
     * <li>, вместе с которым обрывается CSS-переход. Поэтому элементы живут между обновлениями
     * `items`, меняются только их поля — это и сохраняет identity для *ngFor.
     *
     * Сам массив-обёртка при этом всегда новый: p-menu — отдельный OnPush-компонент, и если бы
     * [model] получал ту же ссылку, что и в прошлый раз, Angular не гарантирует p-menu корректный
     * повторный проход (наблюдалось состояние, где заголовок группы обновился, а её дети — нет).
     * Одна лишняя аллокация маленького массива несравнимо дешевле такой рассинхронизации.
     */
    private syncPrimeItems;
    private mergePrimeItems;
    /**
     * Object.assign не удаляет поля, которых нет в источнике. Если на том же индексе пункт сменил
     * "вид" (была группа с `items`, стал экшен без него, или наоборот) — старые поля продолжали бы
     * висеть на объекте: например, стейл `items` заставлял бы PrimeNG `hasSubMenu()` и дальше
     * считать пункт группой. Стираем всё, чего нет в новой форме, перед тем как наложить её поля.
     */
    private resetToShapeOf;
    /** Держит [open] в согласии с реальной видимостью после show()/hide() или клика по пункту. */
    private syncOpen;
    /** PrimeNG `show()` вычисляет якорь из `event.currentTarget` — нормализуем под это. */
    private toPrimeAnchorEvent;
    /**
     * Обёртки кита (`<extra-button>`) — инлайновые элементы: их getBoundingClientRect() описывает
     * строку текста, а не отрисованную кнопку, и меню всплывает поверх триггера. Берём из цепочки
     * события ближайший интерактивный элемент — он и есть реальный якорь.
     */
    private resolveEventAnchor;
    /** Координатный якорь: PrimeNG позиционирует меню через getBoundingClientRect() реального элемента. */
    private createCoordinateAnchor;
    private clearSyntheticAnchor;
    private toPrimeItem;
    /**
     * Спека называет поле ссылки `href`, PrimeNG читает `url` для решения "это реальная ссылка,
     * не звать preventDefault()". Кладём оба — `href` остаётся в контексте слота `item` как есть.
     */
    private toPrimeAction;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraMenuComponent, "extra-menu", never, { "items": { "alias": "items"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "open": { "alias": "open"; "required": false; }; "appendTo": { "alias": "appendTo"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "onItemSelect": "onItemSelect"; "onShow": "onShow"; "onHide": "onHide"; }, ["templates"], never, true, never>;
}

export { ExtraMenuComponent, ExtraMenuTemplateDirective };
export type { ExtraMenuAction, ExtraMenuAnchorLike, ExtraMenuAppendTo, ExtraMenuElementLike, ExtraMenuGroup, ExtraMenuItem, ExtraMenuItemSelectEvent, ExtraMenuSeparator, ExtraMenuTemplateName };
