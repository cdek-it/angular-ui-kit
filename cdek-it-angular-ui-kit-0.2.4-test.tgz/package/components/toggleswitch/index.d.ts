import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';

declare class ExtraToggleSwitchComponent implements ControlValueAccessor {
    private ngControl;
    onChange: EventEmitter<unknown>;
    onFocus: EventEmitter<Event>;
    onBlur: EventEmitter<Event>;
    modelValue: boolean;
    private _disabled;
    private _onChange;
    private _onTouched;
    constructor(ngControl: NgControl);
    get isDisabled(): boolean;
    get isInvalid(): boolean;
    handleChange(value: boolean): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraToggleSwitchComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraToggleSwitchComponent, "extra-toggleswitch", never, {}, { "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}

export { ExtraToggleSwitchComponent };
