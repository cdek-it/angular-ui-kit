import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter } from '@angular/core';

interface ExtraGalleriaItem {
    itemImageSrc: string;
    thumbnailImageSrc?: string;
    alt?: string;
    title?: string;
    description?: string;
}
declare class ExtraGalleriaItemDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraGalleriaItemDirective, "[extraGalleriaItem]", never, {}, {}, never, never, true, never>;
}
declare class ExtraGalleriaThumbnailDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaThumbnailDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraGalleriaThumbnailDirective, "[extraGalleriaThumbnail]", never, {}, {}, never, never, true, never>;
}
declare class ExtraGalleriaCaptionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaCaptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraGalleriaCaptionDirective, "[extraGalleriaCaption]", never, {}, {}, never, never, true, never>;
}
declare class ExtraGalleriaIndicatorDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaIndicatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraGalleriaIndicatorDirective, "[extraGalleriaIndicator]", never, {}, {}, never, never, true, never>;
}
declare class ExtraGalleriaHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraGalleriaHeaderDirective, "[extraGalleriaHeader]", never, {}, {}, never, never, true, never>;
}
declare class ExtraGalleriaFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraGalleriaFooterDirective, "[extraGalleriaFooter]", never, {}, {}, never, never, true, never>;
}
declare class ExtraGalleriaComponent {
    value: ExtraGalleriaItem[];
    numVisible: number;
    showItemNavigators: boolean;
    showItemNavigatorsOnHover: boolean;
    showThumbnails: boolean;
    showThumbnailNavigators: boolean;
    showIndicators: boolean;
    showIndicatorsOnItem: boolean;
    circular: boolean;
    autoPlay: boolean;
    transitionInterval: number;
    fullScreen: boolean;
    visible: boolean;
    containerClass: string | undefined;
    containerStyle: Record<string, string> | undefined;
    responsiveOptions: any[] | undefined;
    itemTemplate: TemplateRef<any> | null;
    thumbnailTemplate: TemplateRef<any> | null;
    captionTemplate: TemplateRef<any> | null;
    indicatorTemplate: TemplateRef<any> | null;
    headerTemplate: TemplateRef<any> | null;
    footerTemplate: TemplateRef<any> | null;
    activeIndexChange: EventEmitter<number>;
    visibleChange: EventEmitter<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraGalleriaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraGalleriaComponent, "extra-galleria", never, { "value": { "alias": "value"; "required": false; }; "numVisible": { "alias": "numVisible"; "required": false; }; "showItemNavigators": { "alias": "showItemNavigators"; "required": false; }; "showItemNavigatorsOnHover": { "alias": "showItemNavigatorsOnHover"; "required": false; }; "showThumbnails": { "alias": "showThumbnails"; "required": false; }; "showThumbnailNavigators": { "alias": "showThumbnailNavigators"; "required": false; }; "showIndicators": { "alias": "showIndicators"; "required": false; }; "showIndicatorsOnItem": { "alias": "showIndicatorsOnItem"; "required": false; }; "circular": { "alias": "circular"; "required": false; }; "autoPlay": { "alias": "autoPlay"; "required": false; }; "transitionInterval": { "alias": "transitionInterval"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "containerStyle": { "alias": "containerStyle"; "required": false; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; }; }, { "activeIndexChange": "activeIndexChange"; "visibleChange": "visibleChange"; }, ["itemTemplate", "thumbnailTemplate", "captionTemplate", "indicatorTemplate", "headerTemplate", "footerTemplate"], never, true, never>;
}

export { ExtraGalleriaCaptionDirective, ExtraGalleriaComponent, ExtraGalleriaFooterDirective, ExtraGalleriaHeaderDirective, ExtraGalleriaIndicatorDirective, ExtraGalleriaItemDirective, ExtraGalleriaThumbnailDirective };
export type { ExtraGalleriaItem };
