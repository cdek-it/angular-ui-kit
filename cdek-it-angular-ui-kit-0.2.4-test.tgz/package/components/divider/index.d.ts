import * as i0 from '@angular/core';

type ExtraDividerLayout = 'horizontal' | 'vertical';
type ExtraDividerType = 'solid' | 'dash';
type ExtraDividerAlign = 'left' | 'center' | 'right' | 'top' | 'bottom';
declare class ExtraDividerComponent {
    layout: ExtraDividerLayout;
    type: ExtraDividerType;
    align: ExtraDividerAlign;
    /** Маппинг Figma-значения `dash` на тип линии PrimeNG (`dashed`). */
    get primeType(): 'solid' | 'dashed';
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDividerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraDividerComponent, "extra-divider", never, { "layout": { "alias": "layout"; "required": false; }; "type": { "alias": "type"; "required": false; }; "align": { "alias": "align"; "required": false; }; }, {}, never, ["*"], true, never>;
}

export { ExtraDividerComponent };
export type { ExtraDividerAlign, ExtraDividerLayout, ExtraDividerType };
