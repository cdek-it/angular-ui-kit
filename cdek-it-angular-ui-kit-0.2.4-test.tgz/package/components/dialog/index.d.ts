import * as i0 from '@angular/core';
import { TemplateRef, AfterContentInit, QueryList, EventEmitter, ChangeDetectorRef, Injector, Type } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
export { DynamicDialogRef } from 'primeng/dynamicdialog';

type ExtraDialogTemplateName = 'header' | 'footer';
/**
 * Именованный шаблон для слотов ExtraDialogComponent.
 *
 * ```html
 * <extra-dialog [visible]="visible">
 *   Основное содержимое окна (слот content)
 *   <ng-template extraDialogTemplate="header">…</ng-template>
 *   <ng-template extraDialogTemplate="footer">…</ng-template>
 * </extra-dialog>
 * ```
 */
declare class ExtraDialogTemplateDirective {
    template: TemplateRef<unknown>;
    /** Имя слота: header | footer. */
    extraDialogTemplate: ExtraDialogTemplateName;
    constructor(template: TemplateRef<unknown>);
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDialogTemplateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraDialogTemplateDirective, "[extraDialogTemplate]", never, { "extraDialogTemplate": { "alias": "extraDialogTemplate"; "required": true; }; }, {}, never, never, true, never>;
}

type ExtraDialogSize = 'sm' | 'default' | 'lg' | 'xlg';
declare class ExtraDialogComponent implements AfterContentInit {
    private cdr;
    header: string;
    visible: boolean;
    /** Отображать маску (overlay) поверх интерфейса. */
    showOverlay: boolean;
    /** Кнопка разворота окна на весь экран. */
    showMaximize: boolean;
    /** Кнопка закрытия окна. */
    showClose: boolean;
    size: ExtraDialogSize;
    dismissableMask: boolean;
    closeOnEscape: boolean;
    focusOnShow: boolean;
    appendTo: string;
    templates: QueryList<ExtraDialogTemplateDirective>;
    headerTpl?: ExtraDialogTemplateDirective;
    footerTpl?: ExtraDialogTemplateDirective;
    visibleChange: EventEmitter<boolean>;
    onShow: EventEmitter<void>;
    onHide: EventEmitter<void>;
    onMaximize: EventEmitter<void>;
    constructor(cdr: ChangeDetectorRef);
    ngAfterContentInit(): void;
    get sizeClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraDialogComponent, "extra-dialog", never, { "header": { "alias": "header"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "showOverlay": { "alias": "showOverlay"; "required": false; }; "showMaximize": { "alias": "showMaximize"; "required": false; }; "showClose": { "alias": "showClose"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dismissableMask": { "alias": "dismissableMask"; "required": false; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; }; "focusOnShow": { "alias": "focusOnShow"; "required": false; }; "appendTo": { "alias": "appendTo"; "required": false; }; }, { "visibleChange": "visibleChange"; "onShow": "onShow"; "onHide": "onHide"; "onMaximize": "onMaximize"; }, ["templates"], ["*"], true, never>;
}

type ExtraDynamicDialogConfig<DataType = any> = Omit<DynamicDialogConfig<DataType>, 'styleClass'> & {
    size?: ExtraDialogSize;
    styleClass?: string;
};

/** Тип-алиас для подписей; для инжекта использовать сам класс. */
type ExtraDynamicDialogRef<T = any> = DynamicDialogRef<T>;
declare class ExtraDialogService {
    private readonly injector;
    constructor(injector: Injector);
    open<T>(componentType: Type<T>, config?: ExtraDynamicDialogConfig): DynamicDialogRef<T> | null;
    private toSizeClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExtraDialogService>;
}

export { ExtraDialogComponent, ExtraDialogService, ExtraDialogTemplateDirective };
export type { ExtraDialogSize, ExtraDialogTemplateName, ExtraDynamicDialogConfig, ExtraDynamicDialogRef };
