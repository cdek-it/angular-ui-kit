import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { SelectButtonChangeEvent } from 'primeng/selectbutton';

interface ExtraSelectButtonOption {
    name: string;
    code: string | number;
    icon?: string;
    disabled?: boolean;
}
interface ExtraSelectButtonChangeEvent {
    value: any;
    originalEvent?: Event;
}
type ExtraSelectButtonSize = 'small' | 'base' | 'large' | 'xlarge';
declare class ExtraSelectButtonComponent implements ControlValueAccessor {
    private ngControl;
    options: ExtraSelectButtonOption[] | any[];
    optionLabel: string;
    optionValue: string;
    optionDisabled: string;
    size: ExtraSelectButtonSize;
    multiple: boolean;
    allowEmpty: boolean;
    /** Растягивает группу на всю доступную ширину контейнера, сегменты делят её поровну. */
    fluid: boolean;
    onChange: EventEmitter<ExtraSelectButtonChangeEvent>;
    value: any;
    private _disabled;
    private _onChange;
    private _onTouched;
    constructor(ngControl: NgControl);
    get isDisabled(): boolean;
    get primeSize(): 'small' | 'large' | undefined;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onValueChange(newValue: any): void;
    onChangeHandler(event: SelectButtonChangeEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraSelectButtonComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraSelectButtonComponent, "extra-select-button", never, { "options": { "alias": "options"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "optionValue": { "alias": "optionValue"; "required": false; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}

export { ExtraSelectButtonComponent };
export type { ExtraSelectButtonChangeEvent, ExtraSelectButtonOption, ExtraSelectButtonSize };
