import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type ExtraTextareaSize = 'small' | 'base' | 'large' | 'xlarge';
declare class ExtraTextareaComponent implements ControlValueAccessor, OnInit {
    private readonly _injector;
    private _ngControl;
    ngOnInit(): void;
    placeholder: string;
    size: ExtraTextareaSize;
    readonly: boolean;
    showClear: boolean;
    fluid: boolean;
    autoResize: boolean;
    rows: number;
    cols?: number;
    disabled: boolean;
    get invalid(): boolean;
    onResize: EventEmitter<{} | {
        height: string;
    }>;
    onClear: EventEmitter<void>;
    modelValue: string;
    private _onChange;
    get primeSize(): 'small' | 'large' | never;
    get sizeClass(): Record<string, boolean>;
    onInput(event: Event): void;
    onTouched: () => void;
    clearValue(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraTextareaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraTextareaComponent, "extra-textarea", never, { "placeholder": { "alias": "placeholder"; "required": false; }; "size": { "alias": "size"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "showClear": { "alias": "showClear"; "required": false; }; "fluid": { "alias": "fluid"; "required": false; }; "autoResize": { "alias": "autoResize"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "cols": { "alias": "cols"; "required": false; }; }, { "onResize": "onResize"; "onClear": "onClear"; }, never, never, true, never>;
}

export { ExtraTextareaComponent };
export type { ExtraTextareaSize };
