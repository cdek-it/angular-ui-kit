import * as i0 from '@angular/core';
import { EventEmitter, TemplateRef } from '@angular/core';

declare class ExtraDrawerHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDrawerHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraDrawerHeaderDirective, "[extraDrawerHeader]", never, {}, {}, never, never, true, never>;
}
declare class ExtraDrawerFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDrawerFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraDrawerFooterDirective, "[extraDrawerFooter]", never, {}, {}, never, never, true, never>;
}
declare class ExtraDrawerComponent {
    visible: boolean;
    header: string | undefined;
    position: 'left' | 'right' | 'top' | 'bottom';
    size: 'default' | 'sm' | 'lg' | 'xlg';
    modal: boolean;
    fullScreen: boolean;
    dismissible: boolean;
    showCloseIcon: boolean;
    closeOnEscape: boolean;
    blockScroll: boolean;
    visibleChange: EventEmitter<boolean>;
    onShow: EventEmitter<void>;
    onHide: EventEmitter<void>;
    headerTemplate: TemplateRef<any> | null;
    footerTemplate: TemplateRef<any> | null;
    get sizeClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraDrawerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraDrawerComponent, "extra-drawer", never, { "visible": { "alias": "visible"; "required": false; }; "header": { "alias": "header"; "required": false; }; "position": { "alias": "position"; "required": false; }; "size": { "alias": "size"; "required": false; }; "modal": { "alias": "modal"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; "showCloseIcon": { "alias": "showCloseIcon"; "required": false; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; }; "blockScroll": { "alias": "blockScroll"; "required": false; }; }, { "visibleChange": "visibleChange"; "onShow": "onShow"; "onHide": "onHide"; }, ["headerTemplate", "footerTemplate"], ["*"], true, never>;
}

export { ExtraDrawerComponent, ExtraDrawerFooterDirective, ExtraDrawerHeaderDirective };
