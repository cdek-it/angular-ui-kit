import * as i0 from '@angular/core';

type ExtraProgressBarMode = 'determinate' | 'indeterminate';
declare class ExtraProgressBarComponent {
    value: number;
    mode: ExtraProgressBarMode;
    showValue: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraProgressBarComponent, "extra-progressbar", never, { "value": { "alias": "value"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showValue": { "alias": "showValue"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraProgressBarComponent };
export type { ExtraProgressBarMode };
