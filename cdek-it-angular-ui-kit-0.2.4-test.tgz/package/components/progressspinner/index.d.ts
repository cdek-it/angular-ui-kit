import * as i0 from '@angular/core';

type ExtraProgressSpinnerSize = 'small' | 'base' | 'large' | 'xlarge';
declare class ExtraProgressSpinnerComponent {
    size: ExtraProgressSpinnerSize;
    multicolor: boolean;
    strokeWidth: string;
    fill: string;
    animationDuration: string;
    ariaLabel: string | undefined;
    get primeStyleClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraProgressSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraProgressSpinnerComponent, "extra-progressspinner", never, { "size": { "alias": "size"; "required": false; }; "multicolor": { "alias": "multicolor"; "required": false; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; }; "fill": { "alias": "fill"; "required": false; }; "animationDuration": { "alias": "animationDuration"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, true, never>;
}

export { ExtraProgressSpinnerComponent };
export type { ExtraProgressSpinnerSize };
