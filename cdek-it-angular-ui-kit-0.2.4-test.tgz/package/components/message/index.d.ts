import * as i0 from '@angular/core';
import { TemplateRef, AfterContentInit, OnDestroy, EventEmitter, QueryList, ChangeDetectorRef } from '@angular/core';

type ExtraMessageTemplateName = 'footer';
/**
 * Именованный шаблон для слотов ExtraMessageComponent.
 *
 * ```html
 * <extra-message message="..." caption="...">
 *   Контент после caption
 *   <ng-template extraMessageTemplate="footer">
 *     <extra-button label="Действие" />
 *   </ng-template>
 * </extra-message>
 * ```
 */
declare class ExtraMessageTemplateDirective {
    template: TemplateRef<unknown>;
    /** Имя слота: footer. */
    extraMessageTemplate: ExtraMessageTemplateName;
    constructor(template: TemplateRef<unknown>);
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMessageTemplateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExtraMessageTemplateDirective, "[extraMessageTemplate]", never, { "extraMessageTemplate": { "alias": "extraMessageTemplate"; "required": true; }; }, {}, never, never, true, never>;
}

type ExtraMessageSeverity = 'info' | 'success' | 'warning' | 'danger';
type ExtraMessageSize = 'small' | 'base' | 'large' | 'xlarge' | 'fill';
type PrimeMessageSeverity = 'success' | 'info' | 'warn' | 'error';
declare class ExtraMessageComponent implements AfterContentInit, OnDestroy {
    private cdr;
    severity: ExtraMessageSeverity;
    /** Таймер автоскрытия (3 с). */
    timer: boolean;
    message: string;
    caption: string;
    /** Класс иконки tabler icon; null скрывает иконку; undefined (не задан) — стандартная по severity. */
    icon: string | null | undefined;
    showClose: boolean;
    /** Ширина сообщения; `fill` — на всю ширину контейнера. */
    size: ExtraMessageSize;
    onClose: EventEmitter<void>;
    private primeMessage?;
    templates: QueryList<ExtraMessageTemplateDirective>;
    footerTpl?: ExtraMessageTemplateDirective;
    private closed;
    private timerId?;
    constructor(cdr: ChangeDetectorRef);
    get resolvedIcon(): string | null;
    get sizeClass(): string;
    get primeSeverity(): PrimeMessageSeverity;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** Закрывает сообщение (крестиком, программно или по таймеру) и эмитит onClose. */
    close(event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtraMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExtraMessageComponent, "extra-message", never, { "severity": { "alias": "severity"; "required": false; }; "timer": { "alias": "timer"; "required": false; }; "message": { "alias": "message"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "showClose": { "alias": "showClose"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "onClose": "onClose"; }, ["templates"], ["*"], true, never>;
}

export { ExtraMessageComponent, ExtraMessageTemplateDirective };
export type { ExtraMessageSeverity, ExtraMessageSize, ExtraMessageTemplateName };
