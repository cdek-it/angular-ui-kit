var public_api = {};

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=cdek-it-angular-ui-kit.mjs.map
