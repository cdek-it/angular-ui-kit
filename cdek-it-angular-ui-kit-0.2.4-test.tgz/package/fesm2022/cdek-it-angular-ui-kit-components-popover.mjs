import * as i0 from '@angular/core';
import { ViewChild, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Popover } from 'primeng/popover';
import { SharedModule } from 'primeng/api';

class ExtraPopoverComponent {
    dismissable = true;
    appendTo = 'body';
    op;
    toggle(event) {
        this.op.toggle(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPopoverComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraPopoverComponent, isStandalone: true, selector: "extra-popover", inputs: { dismissable: "dismissable", appendTo: "appendTo" }, host: { styleAttribute: "display: contents" }, viewQueries: [{ propertyName: "op", first: true, predicate: ["op"], descendants: true }], ngImport: i0, template: `
    <p-popover #op [dismissable]="dismissable" [appendTo]="appendTo">
      <ng-content></ng-content>
    </p-popover>
  `, isInline: true, dependencies: [{ kind: "component", type: Popover, selector: "p-popover", inputs: ["ariaLabel", "ariaLabelledBy", "dismissable", "style", "styleClass", "appendTo", "autoZIndex", "ariaCloseLabel", "baseZIndex", "focusOnShow", "showTransitionOptions", "hideTransitionOptions"], outputs: ["onShow", "onHide"] }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPopoverComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-popover',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Popover, SharedModule],
                    host: { style: 'display: contents' },
                    template: `
    <p-popover #op [dismissable]="dismissable" [appendTo]="appendTo">
      <ng-content></ng-content>
    </p-popover>
  `
                }]
        }], propDecorators: { dismissable: [{
                type: Input
            }], appendTo: [{
                type: Input
            }], op: [{
                type: ViewChild,
                args: ['op']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraPopoverComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-popover.mjs.map
