import * as i0 from '@angular/core';
import { Input, Component } from '@angular/core';
import { Tabs, TabList, Tab, TabPanels, TabPanel } from 'primeng/tabs';
import { Badge } from 'primeng/badge';

class ExtraTabsComponent {
    value = '0';
    tabs = [];
    scrollable = false;
    lazy = false;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraTabsComponent, isStandalone: true, selector: "extra-tabs", inputs: { value: "value", tabs: "tabs", scrollable: "scrollable", lazy: "lazy" }, ngImport: i0, template: `
    <p-tabs [value]="value" [scrollable]="scrollable" [lazy]="lazy" (valueChange)="value = $event">
      <p-tablist>
        @for (tab of tabs; track tab.value) {
          <p-tab [value]="tab.value" [disabled]="tab.disabled || false">
            @if (tab.icon) {
              <i class="text-xl" [class]="tab.icon"></i>
            }
            <span>{{ tab.label }}</span>
            @if (tab.badge) {
              <p-badge [value]="tab.badge" [severity]="tab.badgeSeverity || 'success'"></p-badge>
            }
          </p-tab>
        }
      </p-tablist>
      <p-tabpanels>
        @for (tab of tabs; track tab.value) {
          <p-tabpanel [value]="tab.value">
            <p class="m-0">{{ tab.content }}</p>
          </p-tabpanel>
        }
      </p-tabpanels>
    </p-tabs>
  `, isInline: true, dependencies: [{ kind: "component", type: Tabs, selector: "p-tabs", inputs: ["value", "scrollable", "lazy", "selectOnFocus", "showNavigators", "tabindex"], outputs: ["valueChange"] }, { kind: "component", type: TabList, selector: "p-tablist" }, { kind: "component", type: Tab, selector: "p-tab", inputs: ["value", "disabled"], outputs: ["valueChange"] }, { kind: "component", type: TabPanels, selector: "p-tabpanels" }, { kind: "component", type: TabPanel, selector: "p-tabpanel", inputs: ["lazy", "value"], outputs: ["valueChange"] }, { kind: "component", type: Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTabsComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-tabs',
                    standalone: true,
                    imports: [Tabs, TabList, Tab, TabPanels, TabPanel, Badge],
                    template: `
    <p-tabs [value]="value" [scrollable]="scrollable" [lazy]="lazy" (valueChange)="value = $event">
      <p-tablist>
        @for (tab of tabs; track tab.value) {
          <p-tab [value]="tab.value" [disabled]="tab.disabled || false">
            @if (tab.icon) {
              <i class="text-xl" [class]="tab.icon"></i>
            }
            <span>{{ tab.label }}</span>
            @if (tab.badge) {
              <p-badge [value]="tab.badge" [severity]="tab.badgeSeverity || 'success'"></p-badge>
            }
          </p-tab>
        }
      </p-tablist>
      <p-tabpanels>
        @for (tab of tabs; track tab.value) {
          <p-tabpanel [value]="tab.value">
            <p class="m-0">{{ tab.content }}</p>
          </p-tabpanel>
        }
      </p-tabpanels>
    </p-tabs>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], tabs: [{
                type: Input
            }], scrollable: [{
                type: Input
            }], lazy: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraTabsComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-tabs.mjs.map
