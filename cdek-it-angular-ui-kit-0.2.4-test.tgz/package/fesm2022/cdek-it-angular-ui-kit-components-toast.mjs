import * as i0 from '@angular/core';
import { Input, Component, Injectable, makeEnvironmentProviders } from '@angular/core';
import { Toast } from 'primeng/toast';
import * as i1 from 'primeng/api';
import { SharedModule, MessageService } from 'primeng/api';

const SEVERITY_ICONS = {
    info: 'ti ti-info-circle',
    success: 'ti ti-circle-check',
    warn: 'ti ti-alert-triangle',
    error: 'ti ti-alert-circle'
};
class ExtraToastComponent {
    position = 'top-right';
    key = undefined;
    life = 5000;
    pt = undefined;
    resolveIcon(message) {
        return message.icon ?? SEVERITY_ICONS[message.severity ?? 'info'] ?? 'ti ti-info-circle';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToastComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraToastComponent, isStandalone: true, selector: "extra-toast", inputs: { position: "position", key: "key", life: "life", pt: "pt" }, ngImport: i0, template: `
    <p-toast [position]="position" [key]="key" [life]="life" [pt]="pt">
      <ng-template #message let-message>
        <div class="p-toast-accent-line"></div>
        <i [class]="resolveIcon(message) + ' p-toast-message-icon'"></i>
        <div class="p-toast-message-text">
          <span class="p-toast-summary">{{ message.summary }}</span>
          @if (message.detail) {
            <div class="p-toast-detail">{{ message.detail }}</div>
          }
        </div>
      </ng-template>
    </p-toast>
  `, isInline: true, dependencies: [{ kind: "component", type: Toast, selector: "p-toast", inputs: ["key", "autoZIndex", "baseZIndex", "life", "styleClass", "position", "preventOpenDuplicates", "preventDuplicates", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "breakpoints"], outputs: ["onClose"] }, { kind: "ngmodule", type: SharedModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToastComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-toast',
                    standalone: true,
                    imports: [Toast, SharedModule],
                    template: `
    <p-toast [position]="position" [key]="key" [life]="life" [pt]="pt">
      <ng-template #message let-message>
        <div class="p-toast-accent-line"></div>
        <i [class]="resolveIcon(message) + ' p-toast-message-icon'"></i>
        <div class="p-toast-message-text">
          <span class="p-toast-summary">{{ message.summary }}</span>
          @if (message.detail) {
            <div class="p-toast-detail">{{ message.detail }}</div>
          }
        </div>
      </ng-template>
    </p-toast>
  `
                }]
        }], propDecorators: { position: [{
                type: Input
            }], key: [{
                type: Input
            }], life: [{
                type: Input
            }], pt: [{
                type: Input
            }] } });

class ExtraToastService {
    messageService;
    constructor(messageService) {
        this.messageService = messageService;
    }
    add(message) {
        this.messageService.add(message);
    }
    clear(key) {
        this.messageService.clear(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToastService, deps: [{ token: i1.MessageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.MessageService }] });

/**
 * Регистрирует зависимости, необходимые для работы `ExtraToastService` и `<extra-toast>`.
 * Вызывать один раз в `ApplicationConfig.providers` или в `bootstrapApplication`.
 *
 * @example
 * // app.config.ts
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideExtraToast()],
 * };
 */
function provideExtraToast() {
    return makeEnvironmentProviders([MessageService]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraToastComponent, ExtraToastService, provideExtraToast };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-toast.mjs.map
