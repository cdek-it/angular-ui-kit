import * as i0 from '@angular/core';
import { Directive, TemplateRef, ContentChild, HostBinding, Input, Component } from '@angular/core';
import { Timeline } from 'primeng/timeline';
import * as i1 from 'primeng/api';
import { SharedModule } from 'primeng/api';
import { NgTemplateOutlet } from '@angular/common';

class ExtraTimelineContentDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraTimelineContentDirective, isStandalone: true, selector: "[extraTimelineContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineContentDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraTimelineContent]', standalone: true }]
        }] });
class ExtraTimelineOppositeDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineOppositeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraTimelineOppositeDirective, isStandalone: true, selector: "[extraTimelineOpposite]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineOppositeDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraTimelineOpposite]', standalone: true }]
        }] });
class ExtraTimelineMarkerDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineMarkerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraTimelineMarkerDirective, isStandalone: true, selector: "[extraTimelineMarker]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineMarkerDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraTimelineMarker]', standalone: true }]
        }] });
class ExtraTimelineComponent {
    value = [];
    align = 'left';
    layout = 'vertical';
    showCaption = true;
    line = 'solid';
    icon = '';
    markerColor = '';
    get dataLine() {
        return this.line;
    }
    get markerColorVar() {
        return this.markerColor || null;
    }
    contentTemplate;
    oppositeTemplate;
    markerTemplate;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraTimelineComponent, isStandalone: true, selector: "extra-timeline", inputs: { value: "value", align: "align", layout: "layout", showCaption: "showCaption", line: "line", icon: "icon", markerColor: "markerColor" }, host: { properties: { "attr.data-line": "this.dataLine", "style.--timeline-marker-color": "this.markerColorVar" } }, queries: [{ propertyName: "contentTemplate", first: true, predicate: ExtraTimelineContentDirective, descendants: true, read: TemplateRef }, { propertyName: "oppositeTemplate", first: true, predicate: ExtraTimelineOppositeDirective, descendants: true, read: TemplateRef }, { propertyName: "markerTemplate", first: true, predicate: ExtraTimelineMarkerDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-timeline [value]="value" [align]="align" [layout]="layout">
      <ng-template pTemplate="content" let-event>
        <ng-container
          *ngTemplateOutlet="contentTemplate || defaultContent; context: { $implicit: event }"
        ></ng-container>
      </ng-template>

      <ng-template pTemplate="opposite" let-event>
        @if (showCaption) {
          @if (oppositeTemplate) {
            <ng-container *ngTemplateOutlet="oppositeTemplate; context: { $implicit: event }"></ng-container>
          } @else {
            <span>&nbsp;</span>
          }
        }
      </ng-template>

      @if (markerTemplate || icon) {
        <ng-template pTemplate="marker" let-event>
          @if (markerTemplate) {
            <ng-container *ngTemplateOutlet="markerTemplate; context: { $implicit: event }"></ng-container>
          } @else {
            <span class="p-timeline-event-marker">
              <i [class]="icon"></i>
            </span>
          }
        </ng-template>
      }
    </p-timeline>

    <ng-template #defaultContent let-event>
      {{ event }}
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: Timeline, selector: "p-timeline", inputs: ["value", "styleClass", "align", "layout"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTimelineComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-timeline',
                    standalone: true,
                    imports: [Timeline, SharedModule, NgTemplateOutlet],
                    template: `
    <p-timeline [value]="value" [align]="align" [layout]="layout">
      <ng-template pTemplate="content" let-event>
        <ng-container
          *ngTemplateOutlet="contentTemplate || defaultContent; context: { $implicit: event }"
        ></ng-container>
      </ng-template>

      <ng-template pTemplate="opposite" let-event>
        @if (showCaption) {
          @if (oppositeTemplate) {
            <ng-container *ngTemplateOutlet="oppositeTemplate; context: { $implicit: event }"></ng-container>
          } @else {
            <span>&nbsp;</span>
          }
        }
      </ng-template>

      @if (markerTemplate || icon) {
        <ng-template pTemplate="marker" let-event>
          @if (markerTemplate) {
            <ng-container *ngTemplateOutlet="markerTemplate; context: { $implicit: event }"></ng-container>
          } @else {
            <span class="p-timeline-event-marker">
              <i [class]="icon"></i>
            </span>
          }
        </ng-template>
      }
    </p-timeline>

    <ng-template #defaultContent let-event>
      {{ event }}
    </ng-template>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], align: [{
                type: Input
            }], layout: [{
                type: Input
            }], showCaption: [{
                type: Input
            }], line: [{
                type: Input
            }], icon: [{
                type: Input
            }], markerColor: [{
                type: Input
            }], dataLine: [{
                type: HostBinding,
                args: ['attr.data-line']
            }], markerColorVar: [{
                type: HostBinding,
                args: ['style.--timeline-marker-color']
            }], contentTemplate: [{
                type: ContentChild,
                args: [ExtraTimelineContentDirective, { read: TemplateRef }]
            }], oppositeTemplate: [{
                type: ContentChild,
                args: [ExtraTimelineOppositeDirective, { read: TemplateRef }]
            }], markerTemplate: [{
                type: ContentChild,
                args: [ExtraTimelineMarkerDirective, { read: TemplateRef }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraTimelineComponent, ExtraTimelineContentDirective, ExtraTimelineMarkerDirective, ExtraTimelineOppositeDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-timeline.mjs.map
