import * as i0 from '@angular/core';
import { HostBinding, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { MeterGroup } from 'primeng/metergroup';
import { MultiSelect } from 'primeng/multiselect';

class ExtraMeterGroupComponent {
    value = [];
    orientation = 'horizontal';
    labelPosition = 'end';
    labelOrientation = 'horizontal';
    get hostDisplay() {
        return this.orientation === 'vertical' ? 'flex' : null;
    }
    get hostHeight() {
        return this.orientation === 'vertical' ? '100%' : null;
    }
    get hostFlex() {
        return this.orientation === 'vertical' ? '1 1 0%' : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMeterGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraMeterGroupComponent, isStandalone: true, selector: "extra-metergroup", inputs: { value: "value", orientation: "orientation", labelPosition: "labelPosition", labelOrientation: "labelOrientation" }, host: { properties: { "style.display": "this.hostDisplay", "style.height": "this.hostHeight", "style.flex": "this.hostFlex" } }, ngImport: i0, template: `
    <p-metergroup
      [value]="value"
      [orientation]="orientation"
      [labelPosition]="labelPosition"
      [labelOrientation]="labelOrientation"
    ></p-metergroup>
    <p-multiselect></p-multiselect>
  `, isInline: true, dependencies: [{ kind: "component", type: MeterGroup, selector: "p-meterGroup, p-metergroup, p-meter-group", inputs: ["value", "min", "max", "orientation", "labelPosition", "labelOrientation", "styleClass"] }, { kind: "component", type: MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMeterGroupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-metergroup',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [MeterGroup, MultiSelect],
                    template: `
    <p-metergroup
      [value]="value"
      [orientation]="orientation"
      [labelPosition]="labelPosition"
      [labelOrientation]="labelOrientation"
    ></p-metergroup>
    <p-multiselect></p-multiselect>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], orientation: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], labelOrientation: [{
                type: Input
            }], hostDisplay: [{
                type: HostBinding,
                args: ['style.display']
            }], hostHeight: [{
                type: HostBinding,
                args: ['style.height']
            }], hostFlex: [{
                type: HostBinding,
                args: ['style.flex']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraMeterGroupComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-metergroup.mjs.map
