import * as i0 from '@angular/core';
import { inject, ElementRef, ChangeDetectorRef, EventEmitter, forwardRef, Output, Input, ViewChild, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { FileUpload } from 'primeng/fileupload';
import { ProgressBar } from 'primeng/progressbar';
import { Message } from 'primeng/message';
import { PrimeTemplate } from 'primeng/api';
import { ExtraButtonComponent } from '@cdek-it/angular-ui-kit/components/button';

class ExtraFileUploadComponent {
    el = inject(ElementRef);
    cdr = inject(ChangeDetectorRef);
    fuRef;
    name = 'files[]';
    url = '/api/upload';
    multiple = true;
    accept = 'image/*,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    maxFileSize = 1000000;
    fileLimit = undefined;
    disabled = false;
    dropzoneTitle = 'Чтобы загрузить файлы кликните или перетащите их в эту область';
    dropzoneCaption = 'Можно загрузить не более 10 файлов размером 1 MB';
    invalidFileSizeMessageSummary = '{0}: Некорректный размер файла';
    invalidFileSizeMessageDetail = 'Максимальный размер — {0}';
    invalidFileTypeMessageSummary = '{0}: Некорректный тип файла';
    invalidFileTypeMessageDetail = 'Допустимые типы: {0}';
    invalidFileLimitMessageSummary = 'Превышен лимит файлов';
    invalidFileLimitMessageDetail = 'Максимум: {0}';
    onSelectEvent = new EventEmitter();
    onRemoveEvent = new EventEmitter();
    onClearEvent = new EventEmitter();
    onError = new EventEmitter();
    onUpload = new EventEmitter();
    selectedFiles = [];
    uploadedFiles = [];
    totalSize = 0;
    totalSizePercent = 0;
    uploadSuccess = false;
    isUploading = false;
    uploadCbRef = null;
    clearCbRef = null;
    onChange = () => { };
    onTouched = () => { };
    writeValue(files) {
        this.selectedFiles = files ?? [];
        this.cdr.markForCheck();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this.cdr.markForCheck();
    }
    get uploadCb() {
        return this.uploadCbRef;
    }
    storeCallbacks(upload, clear) {
        this.uploadCbRef = upload;
        this.clearCbRef = clear;
        return '';
    }
    onDrop(event) {
        event.preventDefault();
        const files = event.dataTransfer?.files;
        if (!files?.length || this.disabled)
            return;
        const accepted = this.filterFilesByAccept(Array.from(files));
        if (!accepted.length)
            return;
        const dt = new DataTransfer();
        accepted.forEach(f => dt.items.add(f));
        this.fuRef.onFileSelect({ target: { files: dt.files } });
    }
    filterFilesByAccept(files) {
        if (!this.accept)
            return files;
        const types = this.accept.split(',').map(t => t.trim());
        return files.filter(file => types.some(type => {
            if (type.includes('*')) {
                return file.type.startsWith(type.replace('*', ''));
            }
            if (type.startsWith('.')) {
                return file.name.toLowerCase().endsWith(type.toLowerCase());
            }
            return file.type === type;
        }));
    }
    onChooseClick() {
        const input = this.el.nativeElement.querySelector('input[type="file"]');
        input?.click();
    }
    isImage(file) {
        return file.type.startsWith('image/');
    }
    formatSize(bytes) {
        if (bytes === 0)
            return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(3)) + ' ' + sizes[i];
    }
    onSelectedFiles(event) {
        this.selectedFiles = [...(this.fuRef?.files || [])];
        this.totalSize = this.selectedFiles.reduce((acc, f) => acc + f.size, 0);
        this.uploadSuccess = false;
        this.isUploading = this.selectedFiles.length > 0;
        this.totalSizePercent = 0;
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            this.totalSizePercent = Math.min(progress, 100);
            if (progress >= 100)
                clearInterval(interval);
            this.cdr.markForCheck();
        }, 40);
        this.onChange(this.selectedFiles);
        this.onTouched();
        this.cdr.markForCheck();
        this.onSelectEvent.emit(event);
    }
    onUploader(event) {
        setTimeout(() => {
            this.clearCbRef?.();
            this.selectedFiles = [];
            this.uploadedFiles = [...(event.files || [])];
            this.totalSize = 0;
            this.totalSizePercent = 0;
            this.uploadSuccess = true;
            this.isUploading = false;
            this.onChange([]);
            this.cdr.markForCheck();
        }, 1500);
        this.onUpload.emit(event);
    }
    onRemoveFile(file, removeFileCallback, index) {
        removeFileCallback(index);
        this.selectedFiles = [...(this.fuRef?.files || [])];
        this.totalSize -= file.size;
        this.totalSizePercent = Math.min((this.totalSize / (this.maxFileSize || 1000000)) * 100, 100);
        if (this.totalSize <= 0) {
            this.isUploading = false;
        }
        this.onChange(this.selectedFiles);
        this.cdr.markForCheck();
    }
    onClearUpload() {
        this.clearCbRef?.();
        this.selectedFiles = [];
        this.uploadedFiles = [];
        this.totalSize = 0;
        this.totalSizePercent = 0;
        this.uploadSuccess = false;
        this.isUploading = false;
        this.onChange([]);
        this.cdr.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraFileUploadComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraFileUploadComponent, isStandalone: true, selector: "extra-fileupload", inputs: { name: "name", url: "url", multiple: "multiple", accept: "accept", maxFileSize: "maxFileSize", fileLimit: "fileLimit", disabled: "disabled", dropzoneTitle: "dropzoneTitle", dropzoneCaption: "dropzoneCaption", invalidFileSizeMessageSummary: "invalidFileSizeMessageSummary", invalidFileSizeMessageDetail: "invalidFileSizeMessageDetail", invalidFileTypeMessageSummary: "invalidFileTypeMessageSummary", invalidFileTypeMessageDetail: "invalidFileTypeMessageDetail", invalidFileLimitMessageSummary: "invalidFileLimitMessageSummary", invalidFileLimitMessageDetail: "invalidFileLimitMessageDetail" }, outputs: { onSelectEvent: "onSelectEvent", onRemoveEvent: "onRemoveEvent", onClearEvent: "onClearEvent", onError: "onError", onUpload: "onUpload" }, host: { styleAttribute: "display: contents" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ExtraFileUploadComponent), multi: true }], viewQueries: [{ propertyName: "fuRef", first: true, predicate: ["fuRef"], descendants: true }], ngImport: i0, template: `
    <p-fileupload
      #fuRef
      [name]="name"
      [url]="url"
      [multiple]="multiple"
      [accept]="accept"
      [maxFileSize]="maxFileSize"
      [fileLimit]="fileLimit"
      [disabled]="disabled"
      [customUpload]="true"
      [auto]="false"
      [invalidFileSizeMessageSummary]="invalidFileSizeMessageSummary"
      [invalidFileSizeMessageDetail]="invalidFileSizeMessageDetail"
      [invalidFileTypeMessageSummary]="invalidFileTypeMessageSummary"
      [invalidFileTypeMessageDetail]="invalidFileTypeMessageDetail"
      [invalidFileLimitMessageSummary]="invalidFileLimitMessageSummary"
      [invalidFileLimitMessageDetail]="invalidFileLimitMessageDetail"
      (onSelect)="onSelectedFiles($event)"
      (uploadHandler)="onUploader($event)"
      (onRemove)="onRemoveEvent.emit($event)"
      (onClear)="onClearEvent.emit()"
      (onError)="onError.emit($event)"
    >
      <ng-template pTemplate="header" let-uploadCallback="uploadCallback" let-clearCallback="clearCallback">
        <div class="fu-header" [attr.data-ref]="storeCallbacks(uploadCallback, clearCallback)">
          <div class="fu-dropzone"
            [class.fu-dropzone--disabled]="disabled"
            (click)="onChooseClick()"
            (dragover)="$event.preventDefault()"
            (drop)="onDrop($event)">
            <i class="ti ti-upload fu-dropzone__icon"></i>
            <div class="fu-dropzone__info">
              <span class="fu-dropzone__title">{{ dropzoneTitle }}</span>
              <span class="fu-dropzone__caption">
                <i class="ti ti-info-circle"></i>
                {{ dropzoneCaption }}
              </span>
            </div>
          </div>
        </div>
      </ng-template>

      <ng-template pTemplate="content"
        let-removeFileCallback="removeFileCallback" let-removeUploadedFileCallback="removeUploadedFileCallback">
        <div class="fu-content">
          @if (isUploading) {
            <p-progressBar [value]="totalSizePercent" [showValue]="false"></p-progressBar>
          }
          @if (uploadSuccess) {
            <p-message severity="success" icon="ti ti-circle-check" [closable]="true" (onClose)="uploadSuccess = false">
              Файлы успешно загружены
            </p-message>
          }
          @if (selectedFiles.length > 0) {
            <div class="fu-file-list">
              @for (file of selectedFiles; track file.name + file.size; let i = $index) {
                <div class="fu-file-card">
                  <div class="fu-file-card__wrap">
                    @if (isImage(file)) {
                      <img [src]="file.objectURL" [alt]="file.name" class="fu-file-card__thumbnail" />
                    } @else {
                      <i class="ti ti-file fu-file-card__icon"></i>
                    }
                    <div class="fu-file-card__info">
                      <span class="fu-file-card__name">{{ file.name }}</span>
                      <span class="fu-file-card__size">
                        <i class="ti ti-info-circle"></i>
                        {{ formatSize(file.size) }}
                      </span>
                    </div>
                  </div>
                  <extra-button icon="ti ti-trash" variant="text" [rounded]="true" size="small"
                    (click)="onRemoveFile(file, removeFileCallback, i)"></extra-button>
                </div>
              }
            </div>
          }
          @if (uploadedFiles.length > 0) {
            <div class="fu-file-list">
              @for (file of uploadedFiles; track file.name + file.size; let i = $index) {
                <div class="fu-file-card fu-file-card--uploaded">
                  <div class="fu-file-card__wrap">
                    <i class="ti ti-file-check fu-file-card__icon"></i>
                    <div class="fu-file-card__info">
                      <span class="fu-file-card__name">{{ file.name }}</span>
                      <span class="fu-file-card__size">Загружено</span>
                    </div>
                  </div>
                  <extra-button icon="ti ti-trash" variant="text" [rounded]="true" size="small"
                    (click)="removeUploadedFileCallback(i)"></extra-button>
                </div>
              }
            </div>
          }
          @if (selectedFiles.length > 0 || uploadedFiles.length > 0) {
            <div class="fu-footer">
              <extra-button label="Отправить" [disabled]="!selectedFiles.length" (click)="uploadCb?.()"></extra-button>
              <extra-button label="Очистить" severity="danger" variant="text"
                [disabled]="!selectedFiles.length && !uploadedFiles.length" (click)="onClearUpload()"></extra-button>
            </div>
          }
        </div>
      </ng-template>
    </p-fileupload>
  `, isInline: true, dependencies: [{ kind: "component", type: FileUpload, selector: "p-fileupload, p-fileUpload", inputs: ["name", "url", "method", "multiple", "accept", "disabled", "auto", "withCredentials", "maxFileSize", "invalidFileSizeMessageSummary", "invalidFileSizeMessageDetail", "invalidFileTypeMessageSummary", "invalidFileTypeMessageDetail", "invalidFileLimitMessageDetail", "invalidFileLimitMessageSummary", "style", "styleClass", "previewWidth", "chooseLabel", "uploadLabel", "cancelLabel", "chooseIcon", "uploadIcon", "cancelIcon", "showUploadButton", "showCancelButton", "mode", "headers", "customUpload", "fileLimit", "uploadStyleClass", "cancelStyleClass", "removeStyleClass", "chooseStyleClass", "chooseButtonProps", "uploadButtonProps", "cancelButtonProps", "files"], outputs: ["onBeforeUpload", "onSend", "onUpload", "onError", "onClear", "onRemove", "onSelect", "onProgress", "uploadHandler", "onImageError", "onRemoveUploadedFile"] }, { kind: "component", type: ProgressBar, selector: "p-progressBar, p-progressbar, p-progress-bar", inputs: ["value", "showValue", "styleClass", "valueStyleClass", "unit", "mode", "color"] }, { kind: "component", type: Message, selector: "p-message", inputs: ["severity", "text", "escape", "style", "styleClass", "closable", "icon", "closeIcon", "life", "showTransitionOptions", "hideTransitionOptions", "size", "variant"], outputs: ["onClose"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "component", type: ExtraButtonComponent, selector: "extra-button", inputs: ["label", "icon", "iconPosition", "variant", "severity", "size", "rounded", "fluid", "disabled", "loading"], outputs: ["focus", "blur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraFileUploadComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-fileupload',
                    standalone: true,
                    imports: [FileUpload, ProgressBar, Message, PrimeTemplate, ExtraButtonComponent],
                    host: { style: 'display: contents' },
                    providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ExtraFileUploadComponent), multi: true }],
                    template: `
    <p-fileupload
      #fuRef
      [name]="name"
      [url]="url"
      [multiple]="multiple"
      [accept]="accept"
      [maxFileSize]="maxFileSize"
      [fileLimit]="fileLimit"
      [disabled]="disabled"
      [customUpload]="true"
      [auto]="false"
      [invalidFileSizeMessageSummary]="invalidFileSizeMessageSummary"
      [invalidFileSizeMessageDetail]="invalidFileSizeMessageDetail"
      [invalidFileTypeMessageSummary]="invalidFileTypeMessageSummary"
      [invalidFileTypeMessageDetail]="invalidFileTypeMessageDetail"
      [invalidFileLimitMessageSummary]="invalidFileLimitMessageSummary"
      [invalidFileLimitMessageDetail]="invalidFileLimitMessageDetail"
      (onSelect)="onSelectedFiles($event)"
      (uploadHandler)="onUploader($event)"
      (onRemove)="onRemoveEvent.emit($event)"
      (onClear)="onClearEvent.emit()"
      (onError)="onError.emit($event)"
    >
      <ng-template pTemplate="header" let-uploadCallback="uploadCallback" let-clearCallback="clearCallback">
        <div class="fu-header" [attr.data-ref]="storeCallbacks(uploadCallback, clearCallback)">
          <div class="fu-dropzone"
            [class.fu-dropzone--disabled]="disabled"
            (click)="onChooseClick()"
            (dragover)="$event.preventDefault()"
            (drop)="onDrop($event)">
            <i class="ti ti-upload fu-dropzone__icon"></i>
            <div class="fu-dropzone__info">
              <span class="fu-dropzone__title">{{ dropzoneTitle }}</span>
              <span class="fu-dropzone__caption">
                <i class="ti ti-info-circle"></i>
                {{ dropzoneCaption }}
              </span>
            </div>
          </div>
        </div>
      </ng-template>

      <ng-template pTemplate="content"
        let-removeFileCallback="removeFileCallback" let-removeUploadedFileCallback="removeUploadedFileCallback">
        <div class="fu-content">
          @if (isUploading) {
            <p-progressBar [value]="totalSizePercent" [showValue]="false"></p-progressBar>
          }
          @if (uploadSuccess) {
            <p-message severity="success" icon="ti ti-circle-check" [closable]="true" (onClose)="uploadSuccess = false">
              Файлы успешно загружены
            </p-message>
          }
          @if (selectedFiles.length > 0) {
            <div class="fu-file-list">
              @for (file of selectedFiles; track file.name + file.size; let i = $index) {
                <div class="fu-file-card">
                  <div class="fu-file-card__wrap">
                    @if (isImage(file)) {
                      <img [src]="file.objectURL" [alt]="file.name" class="fu-file-card__thumbnail" />
                    } @else {
                      <i class="ti ti-file fu-file-card__icon"></i>
                    }
                    <div class="fu-file-card__info">
                      <span class="fu-file-card__name">{{ file.name }}</span>
                      <span class="fu-file-card__size">
                        <i class="ti ti-info-circle"></i>
                        {{ formatSize(file.size) }}
                      </span>
                    </div>
                  </div>
                  <extra-button icon="ti ti-trash" variant="text" [rounded]="true" size="small"
                    (click)="onRemoveFile(file, removeFileCallback, i)"></extra-button>
                </div>
              }
            </div>
          }
          @if (uploadedFiles.length > 0) {
            <div class="fu-file-list">
              @for (file of uploadedFiles; track file.name + file.size; let i = $index) {
                <div class="fu-file-card fu-file-card--uploaded">
                  <div class="fu-file-card__wrap">
                    <i class="ti ti-file-check fu-file-card__icon"></i>
                    <div class="fu-file-card__info">
                      <span class="fu-file-card__name">{{ file.name }}</span>
                      <span class="fu-file-card__size">Загружено</span>
                    </div>
                  </div>
                  <extra-button icon="ti ti-trash" variant="text" [rounded]="true" size="small"
                    (click)="removeUploadedFileCallback(i)"></extra-button>
                </div>
              }
            </div>
          }
          @if (selectedFiles.length > 0 || uploadedFiles.length > 0) {
            <div class="fu-footer">
              <extra-button label="Отправить" [disabled]="!selectedFiles.length" (click)="uploadCb?.()"></extra-button>
              <extra-button label="Очистить" severity="danger" variant="text"
                [disabled]="!selectedFiles.length && !uploadedFiles.length" (click)="onClearUpload()"></extra-button>
            </div>
          }
        </div>
      </ng-template>
    </p-fileupload>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { fuRef: [{
                type: ViewChild,
                args: ['fuRef']
            }], name: [{
                type: Input
            }], url: [{
                type: Input
            }], multiple: [{
                type: Input
            }], accept: [{
                type: Input
            }], maxFileSize: [{
                type: Input
            }], fileLimit: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dropzoneTitle: [{
                type: Input
            }], dropzoneCaption: [{
                type: Input
            }], invalidFileSizeMessageSummary: [{
                type: Input
            }], invalidFileSizeMessageDetail: [{
                type: Input
            }], invalidFileTypeMessageSummary: [{
                type: Input
            }], invalidFileTypeMessageDetail: [{
                type: Input
            }], invalidFileLimitMessageSummary: [{
                type: Input
            }], invalidFileLimitMessageDetail: [{
                type: Input
            }], onSelectEvent: [{
                type: Output
            }], onRemoveEvent: [{
                type: Output
            }], onClearEvent: [{
                type: Output
            }], onError: [{
                type: Output
            }], onUpload: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraFileUploadComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-fileupload.mjs.map
