import { makeEnvironmentProviders } from '@angular/core';
import { providePrimeNG } from 'primeng/config';
import { definePreset } from '@primeng/themes';
import Aura from '@primeng/themes/aura';

var primitive = {
	colors: {
		alpha: {
			white: {
				"10": "rgba(255, 255, 255, 0.0100)",
				"40": "rgba(255, 255, 255, 0.0400)",
				"50": "rgba(255, 255, 255, 0.0500)",
				"60": "rgba(255, 255, 255, 0.0600)",
				"100": "rgba(255, 255, 255, 0.1000)",
				"160": "rgba(255, 255, 255, 0.1600)",
				"200": "rgba(255, 255, 255, 0.2000)",
				"300": "rgba(255, 255, 255, 0.3000)",
				"400": "rgba(255, 255, 255, 0.4000)",
				"500": "rgba(255, 255, 255, 0.5000)",
				"600": "rgba(255, 255, 255, 0.6000)",
				"700": "rgba(255, 255, 255, 0.7000)",
				"800": "rgba(255, 255, 255, 0.8000)",
				"870": "rgba(255, 255, 255, 0.8700)",
				"900": "rgba(255, 255, 255, 0.9000)",
				"1000": "#ffffff"
			},
			black: {
				"40": "rgba(0, 0, 0, 0.0400)",
				"100": "rgba(0, 0, 0, 0.1000)",
				"200": "rgba(0, 0, 0, 0.2000)",
				"300": "rgba(0, 0, 0, 0.3000)",
				"400": "rgba(0, 0, 0, 0.4000)",
				"500": "rgba(0, 0, 0, 0.5000)",
				"600": "rgba(0, 0, 0, 0.6000)",
				"700": "rgba(0, 0, 0, 0.7000)",
				"800": "rgba(0, 0, 0, 0.8000)",
				"900": "rgba(0, 0, 0, 0.9000)",
				"1000": "#000000"
			},
			green: {
				"40": "rgba(68, 232, 88, 0.04)",
				"100": "rgba(68, 232, 88, 0.1)",
				"200": "rgba(68, 232, 88, 0.2)",
				"400": "rgba(68, 232, 88, 0.4)",
				"600": "rgba(68, 232, 88, 0.6)"
			},
			blue: {
				"40": "rgba(68, 150, 232, 0.04)",
				"100": "rgba(68, 150, 232, 0.1)",
				"200": "rgba(68, 150, 232, 0.2)",
				"400": "rgba(68, 150, 232, 0.4)",
				"600": "rgba(68, 150, 232, 0.6)"
			},
			yellow: {
				"40": "rgba(245, 184, 61, 0.04)",
				"100": "rgba(245, 184, 61, 0.1)",
				"200": "rgba(245, 184, 61, 0.2)",
				"400": "rgba(245, 184, 61, 0.4)",
				"600": "rgba(245, 184, 61, 0.6)"
			},
			red: {
				"40": "rgba(232, 82, 68, 0.04)",
				"100": "rgba(232, 82, 68, 0.1)",
				"200": "rgba(232, 82, 68, 0.2)",
				"400": "rgba(232, 82, 68, 0.4)",
				"600": "rgba(232, 82, 68, 0.6)"
			}
		},
		solid: {
			purple: {
				"50": "#faf5ff",
				"100": "#f3e8ff",
				"200": "#e9d5ff",
				"300": "#d8b4fe",
				"400": "#c084fc",
				"500": "#a855f7",
				"600": "#9333ea",
				"700": "#7e22ce",
				"800": "#6b21a8",
				"900": "#581c87",
				"950": "#3b0764"
			},
			fuchsia: {
				"50": "#fdf4ff",
				"100": "#fae8ff",
				"200": "#f5d0fe",
				"300": "#f0abfc",
				"400": "#e879f9",
				"500": "#d946ef",
				"600": "#c026d3",
				"700": "#a21caf",
				"800": "#86198f",
				"900": "#701a75",
				"950": "#4a044e"
			},
			pink: {
				"50": "#fdf2f8",
				"100": "#fce7f3",
				"200": "#fbcfe8",
				"300": "#f9a8d4",
				"400": "#f472b6",
				"500": "#ec4899",
				"600": "#db2777",
				"700": "#be185d",
				"800": "#9d174d",
				"900": "#831843",
				"950": "#500724"
			},
			rose: {
				"50": "#fff1f2",
				"100": "#ffe4e6",
				"200": "#fecdd3",
				"300": "#fda4af",
				"400": "#fb7185",
				"500": "#f43f5e",
				"600": "#e11d48",
				"700": "#be123c",
				"800": "#9f1239",
				"900": "#881337",
				"950": "#4c0519"
			},
			teal: {
				"50": "#f0fdfa",
				"100": "#ccfbf1",
				"200": "#99f6e4",
				"300": "#5eead4",
				"400": "#2dd4bf",
				"500": "#14b8a6",
				"600": "#0d9488",
				"700": "#0f766e",
				"800": "#115e59",
				"900": "#134e4a",
				"950": "#042f2e"
			},
			cyan: {
				"50": "#ecfeff",
				"100": "#cffafe",
				"200": "#a5f3fc",
				"300": "#67e8f9",
				"400": "#22d3ee",
				"500": "#06b6d4",
				"600": "#0891b2",
				"700": "#0e7490",
				"800": "#155e75",
				"900": "#164e63",
				"950": "#013138"
			},
			sky: {
				"50": "#f0f9ff",
				"100": "#e0f2fe",
				"200": "#bae6fd",
				"300": "#7dd3fc",
				"400": "#38bdf8",
				"500": "#0ea5e9",
				"600": "#0284c7",
				"700": "#0369a1",
				"800": "#075985",
				"900": "#0c4a6e",
				"950": "#082f49"
			},
			blue: {
				"50": "#fafdff",
				"100": "#f0f9ff",
				"200": "#d4ecfe",
				"300": "#aad7fb",
				"400": "#77baf4",
				"500": "#4496e8",
				"600": "#1e76cd",
				"700": "#18538d",
				"800": "#123a61",
				"900": "#0e2a45",
				"950": "#0c243b"
			},
			indigo: {
				"50": "#eef2ff",
				"100": "#e0e7ff",
				"200": "#c7d2fe",
				"300": "#a5b4fc",
				"400": "#818cf8",
				"500": "#6366f1",
				"600": "#4f46e5",
				"700": "#4338ca",
				"800": "#3730a3",
				"900": "#312e81",
				"950": "#1e1b4b"
			},
			violet: {
				"50": "#fcfaff",
				"100": "#f6f0ff",
				"200": "#e5d4fe",
				"300": "#cbaafb",
				"400": "#b284f5",
				"500": "#a265ec",
				"600": "#9457ea",
				"700": "#48188d",
				"800": "#321261",
				"900": "#240e45",
				"950": "#1f0c3b"
			},
			emerald: {
				"50": "#ecfdf5",
				"100": "#d1fae5",
				"200": "#a7f3d0",
				"300": "#6ee7b7",
				"400": "#34d399",
				"500": "#10b981",
				"600": "#059669",
				"700": "#047857",
				"800": "#065f46",
				"900": "#064e3b",
				"950": "#022c22"
			},
			green: {
				"50": "#fafffb",
				"100": "#f0fff3",
				"200": "#d4fedc",
				"300": "#aafbb7",
				"400": "#77f48a",
				"500": "#44e858",
				"600": "#1dc831",
				"700": "#168322",
				"800": "#12611b",
				"900": "#0e4514",
				"950": "#0c3b11"
			},
			lime: {
				"50": "#f7fee7",
				"100": "#ecfccb",
				"200": "#d9f99d",
				"300": "#bef264",
				"400": "#a3e635",
				"500": "#84cc16",
				"600": "#65a30d",
				"700": "#4d7c0f",
				"800": "#3f6212",
				"900": "#365314",
				"950": "#1a2e05"
			},
			red: {
				"50": "#fffafa",
				"100": "#fff0f0",
				"200": "#fed4d4",
				"300": "#fbacaa",
				"400": "#f47f77",
				"500": "#e85244",
				"600": "#db3424",
				"700": "#8d2218",
				"800": "#611912",
				"900": "#45120e",
				"950": "#3b100c"
			},
			orange: {
				"50": "#fffbfa",
				"100": "#fff3f0",
				"200": "#ffddd5",
				"300": "#ffbca9",
				"400": "#ff9273",
				"500": "#fe6434",
				"600": "#d53f0b",
				"700": "#a83107",
				"800": "#752506",
				"900": "#561c05",
				"950": "#4b1905"
			},
			amber: {
				"50": "#fffbeb",
				"100": "#fef3c7",
				"200": "#fde68a",
				"300": "#fcd34d",
				"400": "#fbbf24",
				"500": "#f59e0b",
				"600": "#d97706",
				"700": "#b45309",
				"800": "#92400e",
				"900": "#78350f",
				"950": "#451a03"
			},
			yellow: {
				"50": "#fffdfa",
				"100": "#fff9f0",
				"200": "#ffeed4",
				"300": "#fddeaa",
				"400": "#facb75",
				"500": "#f5b83d",
				"600": "#dc9710",
				"700": "#9d6d0e",
				"800": "#6d4c0b",
				"900": "#4f3709",
				"950": "#453008"
			},
			slate: {
				"50": "#f8fafc",
				"100": "#f1f5f9",
				"200": "#e2e8f0",
				"300": "#cbd5e1",
				"400": "#94a3b8",
				"500": "#64748b",
				"600": "#475569",
				"700": "#334155",
				"800": "#1e293b",
				"900": "#0f172a",
				"950": "#020617"
			},
			gray: {
				"50": "#f9fafb",
				"100": "#f3f4f6",
				"200": "#e5e7eb",
				"300": "#d1d5db",
				"400": "#9ca3af",
				"500": "#6b7280",
				"600": "#4b5563",
				"700": "#374151",
				"800": "#1f2937",
				"900": "#111827",
				"950": "#030712"
			},
			zinc: {
				"50": "#fafafa",
				"100": "#f0f0f1",
				"200": "#e2e2e4",
				"300": "#cecfd2",
				"400": "#a2a5a9",
				"500": "#85888e",
				"600": "#6d7076",
				"700": "#56595f",
				"800": "#404348",
				"900": "#2b2e33",
				"950": "#181a1f"
			},
			neutral: {
				"50": "#fafafa",
				"100": "#f5f5f5",
				"200": "#e5e5e5",
				"300": "#d4d4d4",
				"400": "#a3a3a3",
				"500": "#737373",
				"600": "#525252",
				"700": "#404040",
				"800": "#262626",
				"900": "#171717",
				"950": "#0a0a0a"
			},
			stone: {
				"50": "#fafaf9",
				"100": "#f5f5f4",
				"200": "#e7e5e4",
				"300": "#d6d3d1",
				"400": "#a8a29e",
				"500": "#78716c",
				"600": "#57534e",
				"700": "#44403c",
				"800": "#292524",
				"900": "#1c1917",
				"950": "#0c0a09"
			}
		}
	},
	sizing: {
		none: "0rem",
		"05x": "0.0625rem",
		"1x": "0.125rem",
		"2x": "0.25rem",
		"3x": "0.375rem",
		"4x": "0.5rem",
		"5x": "0.625rem",
		"6x": "0.75rem",
		"7x": "0.875rem",
		"8x": "1rem",
		"9x": "1.125rem",
		"10x": "1.25rem",
		"12x": "1.5rem",
		"13x": "1.625rem",
		"14x": "1.75rem",
		"16x": "2rem",
		"18x": "2.25rem",
		"19x": "2.375rem",
		"21x": "2.625rem",
		"23x": "2.875rem",
		"24x": "3rem",
		"26x": "3.25rem",
		"28x": "3.5rem",
		"30x": "3.75rem",
		"32x": "4rem",
		"33x": "4.125rem",
		"35x": "4.375rem",
		"42x": "5.25rem",
		"49x": "6.125rem",
		"50x": "6.25rem",
		"56x": "7rem",
		"63x": "7.875rem",
		"70x": "8.75rem",
		"77x": "9.625rem",
		"84x": "10.5rem",
		"91x": "11.375rem",
		"98x": "12.25rem",
		"105x": "13.125rem",
		"112x": "14rem",
		"119x": "14.875rem",
		"126x": "15.75rem",
		"133x": "16.625rem",
		"140x": "17.5rem",
		"147x": "18.375rem",
		"154x": "19.25rem",
		"161x": "20.125rem",
		"168x": "21rem",
		"175x": "21.875rem",
		"182x": "22.75rem",
		"189x": "23.625rem",
		"196x": "24.5rem",
		"203x": "25.375rem",
		"210x": "26.25rem",
		"238x": "29.75rem",
		"288x": "36rem",
		"315x": "39.375rem",
		"350x": "43.75rem",
		"378x": "47.25rem",
		"384x": "48rem",
		"406x": "50.75rem",
		"420x": "52.5rem",
		"496x": "62rem",
		"600x": "75rem",
		"700x": "87.5rem",
		max: "100rem",
		"20x": "2.5rem",
		"40x": "5rem",
		"120x": "15rem",
		"136x": "17rem",
		"152x": "19rem",
		"200x": "25rem"
	},
	fonts: {
		fontFamily: {
			base: "Noto Sans",
			heading: "TT Fellows"
		},
		fontWeight: {
			regular: "400",
			medium: "500",
			demibold: "600",
			bold: "700"
		},
		fontSize: {
			"100": "0.75rem",
			"200": "0.875rem",
			"300": "1rem",
			"400": "1.125rem",
			"500": "1.25rem",
			"600": "1.5rem",
			"650": "1.875rem",
			"700": "2.25rem",
			"750": "3rem",
			"800": "3.75rem",
			"900": "4.5rem",
			"1000": "6rem"
		},
		lineHeight: {
			"100": "0.75rem",
			"150": "0.875rem",
			"200": "0.875rem",
			"250": "1rem",
			"300": "1.125rem",
			"350": "1.125rem",
			"400": "1.25rem",
			"450": "1.375rem",
			"500": "1.5rem",
			"550": "1.625rem",
			"600": "1.75rem",
			"700": "1.875rem",
			"800": "2.25rem",
			"850": "2.375rem",
			"900": "2.75rem",
			"1000": "3.375rem",
			none: "1",
			auto: "auto"
		},
		letterSpacing: {
			"200": "-0.02rem",
			"400": "-0.03rem",
			"500": "0rem",
			"600": "0.02rem",
			"700": "0.03rem"
		}
	}
};
var semantic = {
	colorScheme: {
		light: {
			color: {
				fg: {
					"default": "{colors.solid.zinc.900}",
					hover: "{colors.solid.zinc.700}",
					active: "{colors.solid.zinc.950}",
					focus: "{colors.solid.zinc.900}",
					muted: "{colors.solid.zinc.500}",
					subtle: "{colors.solid.zinc.600}",
					brand: {
						"default": "{colors.solid.green.500}",
						hover: "{colors.solid.green.600}",
						active: "{colors.solid.green.700}",
						disabled: "{colors.solid.green.300}",
						visited: "{colors.solid.green.800}",
						muted: "{colors.solid.green.400}"
					},
					inverse: {
						"default": "{colors.alpha.white.1000}",
						hover: "{colors.alpha.white.1000}",
						active: "{colors.alpha.white.1000}",
						focus: "{colors.alpha.white.1000}",
						muted: "{colors.alpha.white.700}"
					},
					status: {
						danger: {
							"default": "{colors.solid.red.500}",
							hover: "{colors.solid.red.600}",
							active: "{colors.solid.red.700}",
							disabled: "{colors.solid.red.300}",
							visited: "{colors.solid.red.800}",
							muted: "{colors.solid.red.400}"
						},
						info: {
							"default": "{colors.solid.blue.500}",
							hover: "{colors.solid.blue.600}",
							active: "{colors.solid.blue.700}",
							disabled: "{colors.solid.blue.300}",
							visited: "{colors.solid.blue.800}",
							muted: "{colors.solid.blue.400}"
						},
						warning: {
							"default": "{colors.solid.yellow.500}",
							hover: "{colors.solid.yellow.600}",
							active: "{colors.solid.yellow.700}",
							disabled: "{colors.solid.yellow.300}",
							visited: "{colors.solid.yellow.800}",
							muted: "{colors.solid.yellow.400}"
						},
						success: {
							"default": "{colors.solid.green.500}",
							hover: "{colors.solid.green.600}",
							active: "{colors.solid.green.700}",
							disabled: "{colors.solid.green.300}",
							visited: "{colors.solid.green.800}",
							muted: "{colors.solid.green.400}"
						},
						help: {
							"default": "{colors.solid.purple.500}",
							hover: "{colors.solid.purple.600}",
							active: "{colors.solid.purple.700}",
							disabled: "{colors.solid.purple.300}",
							visited: "{colors.solid.purple.800}",
							muted: "{colors.solid.purple.400}"
						}
					},
					on: {
						brand: {
							"default": "{colors.solid.zinc.900}",
							hover: "{colors.solid.zinc.900}",
							active: "{colors.solid.zinc.900}"
						},
						fill: {
							"default": "{colors.alpha.white.1000}",
							hover: "{colors.alpha.white.1000}",
							active: "{colors.alpha.white.1000}",
							muted: "{colors.solid.zinc.200}"
						},
						status: {
							danger: {
								"default": "{colors.solid.red.900}",
								hover: "{colors.solid.red.950}"
							},
							info: {
								"default": "{colors.solid.blue.900}",
								hover: "{colors.solid.blue.950}"
							},
							warning: {
								"default": "{colors.solid.yellow.900}",
								hover: "{colors.solid.yellow.950}"
							},
							success: {
								"default": "{colors.solid.green.900}",
								hover: "{colors.solid.green.950}"
							},
							help: {
								"default": "{colors.solid.purple.900}",
								hover: "{colors.solid.purple.950}"
							}
						}
					}
				},
				bg: {
					status: {
						danger: {
							weak: {
								"default": "{colors.solid.red.50}",
								hover: "{colors.solid.red.100}",
								active: "{colors.solid.red.200}"
							},
							strong: {
								"default": "{colors.solid.red.300}",
								hover: "{colors.solid.red.400}",
								active: "{colors.solid.red.500}"
							}
						},
						info: {
							weak: {
								"default": "{colors.solid.blue.50}",
								hover: "{colors.solid.blue.100}",
								active: "{colors.solid.blue.200}"
							},
							strong: {
								"default": "{colors.solid.blue.300}",
								hover: "{colors.solid.blue.400}",
								active: "{colors.solid.blue.500}"
							}
						},
						warning: {
							weak: {
								"default": "{colors.solid.yellow.50}",
								hover: "{colors.solid.yellow.100}",
								active: "{colors.solid.yellow.200}"
							},
							strong: {
								"default": "{colors.solid.yellow.300}",
								hover: "{colors.solid.yellow.400}",
								active: "{colors.solid.yellow.500}"
							}
						},
						success: {
							weak: {
								"default": "{colors.solid.green.50}",
								hover: "{colors.solid.green.100}",
								active: "{colors.solid.green.200}"
							},
							strong: {
								"default": "{colors.solid.green.300}",
								hover: "{colors.solid.green.400}",
								active: "{colors.solid.green.500}"
							}
						},
						help: {
							weak: {
								"default": "{colors.solid.purple.50}",
								hover: "{colors.solid.purple.100}",
								active: "{colors.solid.purple.200}"
							},
							strong: {
								"default": "{colors.solid.purple.300}",
								hover: "{colors.solid.purple.400}",
								active: "{colors.solid.purple.500}"
							}
						}
					},
					brand: {
						weak: {
							hover: "{colors.solid.green.50}",
							active: "{colors.solid.green.100}"
						},
						strong: {
							"default": "{colors.solid.green.500}",
							hover: "{colors.solid.green.600}",
							active: "{colors.solid.green.700}"
						}
					},
					surface: {
						canvas: {
							"default": "{colors.solid.zinc.100}",
							hover: "{colors.solid.zinc.200}",
							active: "{colors.solid.zinc.300}",
							selected: "{colors.solid.zinc.200}"
						},
						"default": {
							"default": "{colors.alpha.white.1000}",
							hover: "{colors.solid.zinc.50}",
							active: "{colors.solid.zinc.100}",
							selected: "{colors.solid.zinc.50}"
						},
						raised: {
							"default": "{colors.alpha.white.1000}",
							hover: "{colors.solid.zinc.50}",
							active: "{colors.solid.zinc.100}",
							selected: "{colors.solid.zinc.50}"
						},
						overlay: {
							"default": "{colors.alpha.white.1000}",
							hover: "{colors.solid.zinc.50}"
						},
						backdrop: "{colors.alpha.black.300}"
					},
					neutral: {
						weak: {
							"default": "{colors.solid.zinc.100}",
							hover: "{colors.solid.zinc.200}",
							active: "{colors.solid.zinc.300}",
							disabled: "{colors.solid.zinc.200}"
						},
						medium: {
							"default": "{colors.solid.zinc.200}",
							hover: "{colors.solid.zinc.300}",
							active: "{colors.solid.zinc.400}",
							strong: "{colors.solid.zinc.500}"
						},
						strong: {
							"default": "{colors.solid.zinc.900}",
							hover: "{colors.solid.zinc.800}",
							active: "{colors.solid.zinc.700}",
							selected: "{colors.solid.zinc.900}"
						}
					}
				},
				border: {
					focus: "{colors.alpha.green.200}",
					neutral: {
						"default": "{colors.solid.zinc.200}",
						strong: "{colors.solid.zinc.300}",
						bold: {
							"default": "{colors.solid.zinc.900}",
							hover: "{colors.solid.zinc.800}"
						},
						inverse: "{colors.alpha.white.1000}"
					},
					brand: {
						subtle: "{colors.solid.green.200}",
						"default": "{colors.solid.green.500}",
						strong: "{colors.solid.green.600}"
					},
					status: {
						danger: {
							subtle: "{colors.solid.red.400}",
							"default": "{colors.solid.red.500}",
							strong: "{colors.solid.red.600}",
							focus: "{colors.alpha.red.200}"
						},
						info: {
							"default": "{colors.solid.blue.500}",
							strong: "{colors.solid.blue.600}"
						},
						warning: {
							"default": "{colors.solid.yellow.500}",
							strong: "{colors.solid.yellow.600}"
						},
						success: {
							"default": "{colors.solid.green.500}",
							strong: "{colors.solid.green.600}"
						},
						help: {
							strong: "{colors.solid.purple.600}"
						}
					}
				}
			}
		},
		dark: {
			color: {
				fg: {
					"default": "{colors.alpha.white.1000}",
					hover: "{colors.solid.zinc.300}",
					active: "{colors.solid.zinc.100}",
					focus: "{colors.alpha.white.1000}",
					muted: "{colors.solid.zinc.400}",
					subtle: "{colors.solid.zinc.400}",
					brand: {
						"default": "{colors.solid.green.400}",
						hover: "{colors.solid.green.300}",
						active: "{colors.solid.green.200}",
						disabled: "{colors.solid.green.700}",
						visited: "{colors.solid.green.300}",
						muted: "{colors.solid.green.500}"
					},
					inverse: {
						"default": "{colors.solid.zinc.900}",
						hover: "{colors.solid.zinc.700}",
						active: "{colors.solid.zinc.950}",
						focus: "{colors.solid.zinc.900}",
						muted: "{colors.solid.zinc.500}"
					},
					status: {
						danger: {
							"default": "{colors.solid.red.400}",
							hover: "{colors.solid.red.300}",
							active: "{colors.solid.red.200}",
							disabled: "{colors.solid.red.700}",
							visited: "{colors.solid.red.300}",
							muted: "{colors.solid.red.500}"
						},
						info: {
							"default": "{colors.solid.blue.400}",
							hover: "{colors.solid.blue.300}",
							active: "{colors.solid.blue.200}",
							disabled: "{colors.solid.blue.700}",
							visited: "{colors.solid.blue.300}",
							muted: "{colors.solid.blue.500}"
						},
						warning: {
							"default": "{colors.solid.yellow.400}",
							hover: "{colors.solid.yellow.300}",
							active: "{colors.solid.yellow.200}",
							disabled: "{colors.solid.yellow.700}",
							visited: "{colors.solid.yellow.300}",
							muted: "{colors.solid.yellow.500}"
						},
						success: {
							"default": "{colors.solid.green.400}",
							hover: "{colors.solid.green.300}",
							active: "{colors.solid.green.200}",
							disabled: "{colors.solid.green.700}",
							visited: "{colors.solid.green.300}",
							muted: "{colors.solid.green.500}"
						},
						help: {
							"default": "{colors.solid.purple.400}",
							hover: "{colors.solid.purple.300}",
							active: "{colors.solid.purple.200}",
							disabled: "{colors.solid.purple.700}",
							visited: "{colors.solid.purple.300}",
							muted: "{colors.solid.purple.500}"
						}
					},
					on: {
						brand: {
							"default": "{colors.solid.zinc.900}",
							hover: "{colors.solid.zinc.900}",
							active: "{colors.solid.zinc.900}"
						},
						fill: {
							"default": "{colors.alpha.white.1000}",
							hover: "{colors.alpha.white.1000}",
							active: "{colors.alpha.white.1000}",
							muted: "{colors.solid.zinc.200}"
						},
						status: {
							danger: {
								"default": "{colors.solid.red.100}",
								hover: "{colors.solid.red.50}"
							},
							info: {
								"default": "{colors.solid.blue.100}",
								hover: "{colors.solid.blue.50}"
							},
							warning: {
								"default": "{colors.solid.yellow.100}",
								hover: "{colors.solid.yellow.50}"
							},
							success: {
								"default": "{colors.solid.green.100}",
								hover: "{colors.solid.green.50}"
							},
							help: {
								"default": "{colors.solid.purple.100}",
								hover: "{colors.solid.purple.50}"
							}
						}
					}
				},
				bg: {
					status: {
						danger: {
							weak: {
								"default": "{colors.solid.red.950}",
								hover: "{colors.solid.red.900}",
								active: "{colors.solid.red.800}"
							},
							strong: {
								"default": "{colors.solid.red.700}",
								hover: "{colors.solid.red.600}",
								active: "{colors.solid.red.500}"
							}
						},
						info: {
							weak: {
								"default": "{colors.solid.blue.950}",
								hover: "{colors.solid.blue.900}",
								active: "{colors.solid.blue.800}"
							},
							strong: {
								"default": "{colors.solid.blue.700}",
								hover: "{colors.solid.blue.600}",
								active: "{colors.solid.blue.500}"
							}
						},
						warning: {
							weak: {
								"default": "{colors.solid.yellow.950}",
								hover: "{colors.solid.yellow.900}",
								active: "{colors.solid.yellow.800}"
							},
							strong: {
								"default": "{colors.solid.yellow.700}",
								hover: "{colors.solid.yellow.600}",
								active: "{colors.solid.yellow.500}"
							}
						},
						success: {
							weak: {
								"default": "{colors.solid.green.950}",
								hover: "{colors.solid.green.900}",
								active: "{colors.solid.green.800}"
							},
							strong: {
								"default": "{colors.solid.green.700}",
								hover: "{colors.solid.green.600}",
								active: "{colors.solid.green.500}"
							}
						},
						help: {
							weak: {
								"default": "{colors.solid.purple.950}",
								hover: "{colors.solid.purple.900}",
								active: "{colors.solid.purple.800}"
							},
							strong: {
								"default": "{colors.solid.purple.700}",
								hover: "{colors.solid.purple.600}",
								active: "{colors.solid.purple.500}"
							}
						}
					},
					brand: {
						weak: {
							hover: "{colors.solid.green.950}",
							active: "{colors.solid.green.900}"
						},
						strong: {
							"default": "{colors.solid.green.500}",
							hover: "{colors.solid.green.400}",
							active: "{colors.solid.green.300}"
						}
					},
					surface: {
						canvas: {
							"default": "{colors.solid.zinc.900}",
							hover: "{colors.solid.zinc.800}",
							active: "{colors.solid.zinc.700}",
							selected: "{colors.solid.zinc.800}"
						},
						"default": {
							"default": "{colors.solid.zinc.800}",
							hover: "{colors.solid.zinc.700}",
							active: "{colors.solid.zinc.600}",
							selected: "{colors.solid.zinc.700}"
						},
						raised: {
							"default": "{colors.solid.zinc.700}",
							hover: "{colors.solid.zinc.600}",
							active: "{colors.solid.zinc.500}",
							selected: "{colors.solid.zinc.600}"
						},
						overlay: {
							"default": "{colors.solid.zinc.800}",
							hover: "{colors.solid.zinc.700}"
						},
						backdrop: "{colors.alpha.black.300}"
					},
					neutral: {
						weak: {
							"default": "{colors.solid.zinc.900}",
							hover: "{colors.solid.zinc.800}",
							active: "{colors.solid.zinc.700}",
							disabled: "{colors.solid.zinc.800}"
						},
						medium: {
							"default": "{colors.solid.zinc.800}",
							hover: "{colors.solid.zinc.700}",
							active: "{colors.solid.zinc.600}",
							strong: "{colors.solid.zinc.500}"
						},
						strong: {
							"default": "{colors.solid.zinc.100}",
							hover: "{colors.solid.zinc.200}",
							active: "{colors.solid.zinc.300}",
							selected: "{colors.solid.zinc.100}"
						}
					}
				},
				border: {
					focus: "{colors.alpha.green.200}",
					neutral: {
						"default": "{colors.solid.zinc.800}",
						strong: "{colors.solid.zinc.700}",
						bold: {
							"default": "{colors.solid.zinc.100}",
							hover: "{colors.solid.zinc.200}"
						},
						inverse: "{colors.solid.zinc.900}"
					},
					brand: {
						subtle: "{colors.solid.green.800}",
						"default": "{colors.solid.green.500}",
						strong: "{colors.solid.green.400}"
					},
					status: {
						danger: {
							subtle: "{colors.solid.red.600}",
							"default": "{colors.solid.red.500}",
							strong: "{colors.solid.red.400}",
							focus: "{colors.alpha.red.200}"
						},
						info: {
							"default": "{colors.solid.blue.500}",
							strong: "{colors.solid.blue.400}"
						},
						warning: {
							"default": "{colors.solid.yellow.500}",
							strong: "{colors.solid.yellow.400}"
						},
						success: {
							"default": "{colors.solid.green.500}",
							strong: "{colors.solid.green.400}"
						},
						help: {
							strong: "{colors.solid.purple.400}"
						}
					}
				}
			}
		}
	},
	dimension: {
		space: {
			"100": "{sizing.2x}",
			"150": "{sizing.3x}",
			"200": "{sizing.4x}",
			"300": "{sizing.5x}",
			"350": "{sizing.6x}",
			"400": "{sizing.7x}",
			"500": "{sizing.9x}",
			"600": "{sizing.10x}",
			"700": "{sizing.12x}",
			"800": "{sizing.14x}",
			none: "{sizing.none}",
			negative: {
				"50": "-0.125rem",
				"200": "-0.5rem",
				"300": "-0.75rem",
				"600": "-1.5rem"
			}
		},
		size: {
			"50": "{sizing.1x}",
			"100": "{sizing.2x}",
			"150": "{sizing.3x}",
			"200": "{sizing.4x}",
			"300": "{sizing.5x}",
			"350": "{sizing.6x}",
			"400": "{sizing.7x}",
			"450": "{sizing.8x}",
			"500": "{sizing.9x}",
			"600": "{sizing.10x}",
			"700": "{sizing.12x}",
			"750": "{sizing.13x}",
			"800": "{sizing.14x}",
			"900": "{sizing.16x}",
			"1000": "{sizing.18x}",
			"1100": "{sizing.20x}",
			"1200": "{sizing.24x}",
			"1300": "{sizing.28x}",
			"1400": "{sizing.32x}",
			"1500": "{sizing.40x}",
			"1600": "{sizing.120x}",
			"1700": "{sizing.136x}",
			"1800": "{sizing.152x}",
			"1900": "{sizing.168x}",
			"2000": "{sizing.200x}",
			"2200": "{sizing.315x}",
			none: "{sizing.none}",
			max: "{sizing.max}"
		},
		borderRadius: {
			"100": "{sizing.2x}",
			"200": "{sizing.4x}",
			"300": "{sizing.5x}",
			"350": "{sizing.6x}",
			"400": "{sizing.7x}",
			"500": "{sizing.10x}",
			none: "{sizing.none}",
			max: "{sizing.max}"
		},
		borderWidth: {
			"100": "{sizing.05x}",
			"200": "{sizing.1x}",
			"300": "{sizing.2x}",
			none: "{sizing.none}"
		},
		focusRing: {
			width: "{sizing.2x}",
			offset: "{sizing.none}"
		},
		depth: {
			"100": "1000",
			"200": "1100",
			"300": "1200",
			"400": "1300",
			"500": "1400",
			"600": "1500",
			"700": "1600"
		},
		viewport: {
			"100": "{sizing.288x}",
			"200": "{sizing.384x}",
			"300": "{sizing.496x}",
			"400": "{sizing.600x}",
			"500": "{sizing.700x}"
		}
	},
	effects: {
		opacity: {
			"0": "0",
			"4": "0.04",
			"8": "0.08",
			"12": "0.12",
			"16": "0.16",
			"20": "0.2",
			"30": "0.3",
			"40": "0.4",
			"50": "0.5",
			"60": "0.6",
			"70": "0.7",
			"80": "0.8",
			"90": "0.9",
			"100": "1"
		},
		blur: {
			"100": "4px",
			"200": "8px",
			"300": "16px",
			"400": "24px",
			none: "0"
		},
		transition: {
			easing: {
				linear: "linear",
				"in": "cubic-bezier(0.55, 0.06, 0.7, 0.2)",
				out: "cubic-bezier(0.2, 0.6, 0.4, 1)",
				inOut: "cubic-bezier(0.65, 0.05, 0.35, 1)",
				standard: "cubic-bezier(0.2, 0, 0, 1)",
				accelerate: "cubic-bezier(0.3, 0, 1, 1)",
				decelerate: "cubic-bezier(0, 0, 0, 1)",
				emphasizedAccelerate: "cubic-bezier(0.3, 0, 0.8, 0.15)",
				emphasizedDecelerate: "cubic-bezier(0.05, 0.7, 0.1, 1)",
				spring: "cubic-bezier(0.34, 1.56, 0.64, 1)"
			},
			duration: {
				"100": "140ms",
				"200": "180ms",
				"300": "240ms",
				"400": "320ms",
				"500": "400ms"
			}
		},
		elevation: {
			"100": "0 0 2px {colors.alpha.black.200}",
			"200": "0 0 4px {colors.alpha.black.200}",
			"300": "0 2px 4px {colors.alpha.black.200}",
			"400": "0 4px 8px {colors.alpha.black.200}",
			"500": "0 8px 16px 0 {colors.alpha.black.200}",
			none: "none",
			status: {
				info: "0px 4px 8px 0px {colors.alpha.blue.40}",
				success: "0px 4px 8px 0px {colors.alpha.green.40}",
				warning: "0px 4px 8px 0px {colors.alpha.yellow.40}",
				danger: "0px 4px 8px 0px {colors.alpha.red.40}",
				secondary: "0px 4px 8px 0px {colors.alpha.black.40}",
				contrast: "0px 4px 8px 0px {colors.alpha.black.40}"
			}
		},
		focusRing: {
			shadow: "inset 0 0 0 {dimension.focusRing.width} {colors.solid.green.200}"
		}
	}
};
var components = {
	accordion: {
		extend: {
			extHeader: {
				iconSize: "{dimension.size.600}",
				gap: "{dimension.space.200}"
			}
		},
		colorScheme: {
			light: {
				header: {
					background: "transparent",
					hoverBackground: "transparent",
					activeBackground: "transparent",
					activeHoverBackground: "transparent"
				}
			},
			dark: {
				header: {
					activeBackground: "transparent",
					activeHoverBackground: "transparent",
					background: "transparent",
					hoverBackground: "transparent"
				}
			}
		},
		header: {
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			activeColor: "{color.fg.default}",
			activeHoverColor: "{color.fg.hover}",
			borderColor: "transparent",
			padding: "{dimension.space.400} {dimension.space.none} {dimension.space.400} {dimension.space.none}",
			fontWeight: "{fonts.fontWeight.bold}",
			borderRadius: "{dimension.borderRadius.none}",
			borderWidth: "{dimension.borderWidth.none}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.focusRing.shadow}"
			},
			toggleIcon: {
				color: "{color.fg.default}",
				hoverColor: "{color.fg.hover}",
				activeColor: "{color.fg.default}",
				activeHoverColor: "{color.fg.hover}"
			},
			last: {
				bottomBorderRadius: "{dimension.borderRadius.none}",
				activeBottomBorderRadius: "{dimension.borderRadius.none}"
			},
			first: {
				borderWidth: "{dimension.borderWidth.none}",
				topBorderRadius: "{dimension.borderRadius.none}"
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		panel: {
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.300} {dimension.borderWidth.none}",
			borderColor: "{color.border.neutral.strong}"
		},
		content: {
			borderWidth: "{dimension.borderWidth.100} {dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.none}",
			borderColor: "transparent",
			background: "transparent",
			color: "{color.fg.default}",
			padding: "{dimension.space.none} {dimension.space.700} {dimension.space.400} {dimension.space.700}"
		}
	},
	autocomplete: {
		extend: {
			checkmarkSize: "{dimension.size.600}",
			extOption: {
				gap: "{dimension.space.200}"
			},
			extOptionGroup: {
				gap: "{dimension.space.200}"
			}
		},
		colorScheme: {
			light: {
				chip: {
					focusBackground: "{color.bg.neutral.medium.default}",
					focusColor: "{color.fg.default}"
				},
				extend: {
					option: {
						background: "{color.bg.surface.default.default}"
					}
				},
				dropdown: {
					background: "{color.bg.surface.default.default}",
					hoverBackground: "{color.bg.surface.default.default}",
					activeBackground: "{color.bg.surface.default.default}",
					color: "{color.fg.muted}",
					hoverColor: "{color.fg.muted}",
					activeColor: "{color.fg.muted}"
				}
			},
			dark: {
				chip: {
					focusBackground: "{color.bg.neutral.medium.default}",
					focusColor: "{color.fg.default}"
				},
				dropdown: {
					activeBackground: "{color.bg.surface.default.default}",
					activeColor: "{color.fg.inverse.muted}",
					background: "{color.bg.surface.default.default}",
					color: "{color.fg.inverse.muted}",
					hoverBackground: "{color.bg.surface.default.default}",
					hoverColor: "{color.fg.inverse.muted}"
				},
				extend: {
					option: {
						background: "{color.bg.surface.canvas.default}"
					}
				},
				option: {
					focusBackground: "{color.bg.surface.canvas.hover}"
				},
				optionGroup: {
					background: "{color.bg.surface.canvas.default}",
					color: "{color.fg.inverse.muted}"
				},
				overlay: {
					background: "{color.bg.surface.canvas.default}"
				}
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			filledBackground: "{color.bg.surface.default.default}",
			filledHoverBackground: "{color.bg.surface.default.default}",
			filledFocusBackground: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.brand.strong}",
			focusBorderColor: "{color.border.brand.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			color: "{color.fg.active}",
			disabledColor: "{color.fg.muted}",
			placeholderColor: "{color.fg.muted}",
			invalidPlaceholderColor: "{color.fg.status.danger.hover}",
			shadow: "{effects.elevation.none}",
			paddingX: "{dimension.space.400}",
			paddingY: "{dimension.space.400}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}"
			}
		},
		overlay: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.350}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.400}"
		},
		list: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}"
		},
		option: {
			focusBackground: "{color.bg.neutral.weak.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			selectedFocusBackground: "{color.bg.neutral.strong.active}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			selectedColor: "{color.fg.inverse.default}",
			selectedFocusColor: "{color.fg.on.fill.active}",
			padding: "{dimension.space.200} {dimension.space.350}",
			borderRadius: "{dimension.borderRadius.200}"
		},
		optionGroup: {
			background: "{color.bg.surface.raised.default}",
			color: "{color.fg.muted}",
			fontWeight: "{fonts.fontWeight.demibold}",
			padding: "{dimension.space.200} {dimension.space.400}"
		},
		dropdown: {
			width: "{dimension.size.1700}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.brand.strong}",
			activeBorderColor: "{color.border.brand.strong}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}"
			},
			sm: {
				width: "{dimension.size.1600}"
			},
			lg: {
				width: "{dimension.size.1800}"
			}
		},
		chip: {
			borderRadius: "{dimension.borderRadius.200}"
		},
		emptyMessage: {
			padding: "{dimension.space.200} {dimension.space.400}"
		}
	},
	avatar: {
		extend: {
			borderColor: "{color.border.neutral.strong}",
			circle: {
				borderRadius: "{dimension.borderRadius.max}"
			}
		},
		root: {
			width: "{dimension.size.900}",
			height: "{dimension.size.900}",
			fontSize: "{fonts.fontSize.300}",
			color: "{color.fg.on.brand.default}",
			background: "{color.bg.brand.strong.default}",
			borderRadius: "{dimension.borderRadius.400}"
		},
		icon: {
			size: "{dimension.size.450}"
		},
		group: {
			borderColor: "{color.border.neutral.inverse}",
			offset: "{dimension.space.negative.300}"
		},
		lg: {
			width: "{dimension.size.1100}",
			height: "{dimension.size.1100}",
			fontSize: "{fonts.fontSize.300}",
			icon: {
				size: "{dimension.size.450}"
			},
			group: {
				offset: "{dimension.space.negative.300}"
			}
		},
		xl: {
			width: "{dimension.size.1300}",
			height: "{dimension.size.1300}",
			icon: {
				size: "{dimension.size.700}"
			},
			group: {
				offset: "{dimension.space.negative.600}"
			},
			fontSize: "{fonts.fontSize.300}"
		}
	},
	badge: {
		extend: {
			extDot: {
				success: {
					background: "{color.bg.status.success.strong.hover}"
				},
				info: {
					background: "{color.bg.status.info.strong.hover}"
				},
				warn: {
					background: "{color.bg.status.warning.strong.hover}"
				},
				danger: {
					background: "{color.bg.status.danger.strong.hover}"
				},
				lg: {
					size: "{dimension.size.350}"
				},
				xlg: {
					size: "{dimension.size.450}"
				}
			},
			ext: {
				padding: "{dimension.space.none}"
			}
		},
		colorScheme: {
			light: {
				primary: {
					color: "{color.fg.default}",
					background: "{color.bg.brand.strong.default}"
				},
				secondary: {
					color: "{color.fg.on.fill.default}",
					background: "{color.bg.neutral.strong.default}"
				},
				success: {
					color: "{color.fg.on.status.success.default}",
					background: "{color.bg.status.success.strong.default}"
				},
				info: {
					color: "{color.fg.on.status.info.default}",
					background: "{color.bg.status.info.strong.default}"
				},
				warn: {
					color: "{color.fg.on.status.warning.default}",
					background: "{color.bg.status.warning.strong.default}"
				},
				danger: {
					color: "{color.fg.on.status.danger.default}",
					background: "{color.bg.status.danger.strong.default}"
				},
				contrast: {
					background: "{color.bg.neutral.strong.default}",
					color: "{color.fg.on.fill.default}"
				}
			},
			dark: {
				contrast: {
					background: "{color.bg.surface.canvas.default}",
					color: "{color.fg.default}"
				},
				danger: {
					background: "{color.bg.status.danger.strong.default}",
					color: "{color.fg.on.status.danger.default}"
				},
				info: {
					background: "{color.bg.status.info.strong.default}",
					color: "{color.fg.on.status.info.default}"
				},
				primary: {
					background: "{color.bg.brand.strong.default}",
					color: "{color.fg.inverse.default}"
				},
				secondary: {
					background: "{color.bg.surface.canvas.default}",
					color: "{color.fg.default}"
				},
				success: {
					background: "{color.bg.status.success.strong.default}",
					color: "{color.fg.on.status.success.default}"
				},
				warn: {
					background: "{color.bg.status.warning.strong.default}",
					color: "{color.fg.on.status.warning.default}"
				}
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.200}",
			padding: "{dimension.space.200}",
			fontSize: "{fonts.fontSize.100}",
			fontWeight: "{fonts.fontWeight.regular}",
			minWidth: "{dimension.size.700}",
			height: "{dimension.size.700}"
		},
		dot: {
			size: "{dimension.size.200}"
		},
		sm: {
			fontSize: "{fonts.fontSize.100}",
			minWidth: "{dimension.size.none}",
			height: "{dimension.size.none}"
		},
		lg: {
			fontSize: "{fonts.fontSize.100}",
			minWidth: "{dimension.size.800}",
			height: "{dimension.size.800}"
		},
		xl: {
			fontSize: "{fonts.fontSize.100}",
			minWidth: "{dimension.size.900}",
			height: "{dimension.size.900}"
		}
	},
	breadcrumb: {
		extend: {
			hoverBackground: "{color.bg.neutral.weak.default}",
			iconSize: "{dimension.size.600}",
			extItem: {
				padding: "{dimension.space.100}"
			}
		},
		root: {
			padding: "{dimension.space.none}",
			background: "transparent",
			gap: "{dimension.space.none}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		focusRing: {
			width: "{dimension.focusRing.width}",
			style: "none",
			color: "{color.border.focus}",
			offset: "{dimension.focusRing.offset}",
			shadow: "{effects.elevation.200}"
		},
		item: {
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			borderRadius: "{dimension.borderRadius.100}",
			gap: "{dimension.space.200}",
			icon: {
				color: "{color.fg.default}",
				hoverColor: "{color.fg.hover}"
			},
			focusRing: {
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				style: "none",
				width: "{dimension.focusRing.width}"
			}
		},
		separator: {
			color: "{color.fg.default}"
		}
	},
	button: {
		extend: {
			disabledBackground: "{color.bg.neutral.weak.disabled}",
			extOutlined: {
				danger: {
					focusBackground: "transparent"
				},
				warn: {
					focusBackground: "transparent"
				},
				info: {
					focusBackground: "transparent"
				},
				help: {
					focusBackground: "transparent"
				},
				success: {
					focusBackground: "transparent"
				}
			},
			disabledColor: "{color.fg.muted}",
			extText: {
				danger: {
					focusBackground: "transparent"
				},
				warn: {
					focusBackground: "transparent"
				},
				info: {
					focusBackground: "transparent"
				},
				help: {
					focusBackground: "transparent"
				},
				success: {
					focusBackground: "transparent"
				}
			},
			extLink: {
				background: "transparent",
				colorHover: "{color.fg.hover}",
				paddingX: "{dimension.space.none}",
				paddingY: "{dimension.space.100}",
				sm: {
					iconOnlyWidth: "{dimension.size.450}"
				},
				base: {
					iconOnlyWidth: "{dimension.size.700}"
				},
				lg: {
					iconOnlyWidth: "{dimension.size.800}"
				},
				xlg: {
					iconOnlyWidth: "{dimension.size.900}"
				}
			},
			extSm: {
				borderRadius: "{dimension.borderRadius.400}",
				gap: "{dimension.space.200}",
				height: "{dimension.size.800}"
			},
			extLg: {
				borderRadius: "{dimension.borderRadius.400}",
				gap: "{dimension.space.400}",
				height: "{dimension.size.1200}"
			},
			extXlg: {
				borderRadius: "{dimension.borderRadius.400}",
				gap: "{dimension.space.400}",
				iconOnlyWidth: "{dimension.size.1300}",
				paddingX: "{dimension.space.700}",
				paddingY: "{dimension.space.600}",
				height: "{dimension.size.1300}"
			},
			borderWidth: "{dimension.borderWidth.100}",
			iconSize: {
				sm: "{dimension.size.450}",
				md: "{dimension.size.600}",
				lg: "{dimension.size.700}"
			}
		},
		colorScheme: {
			light: {
				root: {
					primary: {
						background: "{color.bg.brand.strong.default}",
						hoverBackground: "{color.bg.brand.strong.hover}",
						activeBackground: "{color.bg.brand.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.default}",
						hoverColor: "{color.fg.default}",
						activeColor: "{color.fg.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					secondary: {
						background: "{color.bg.neutral.strong.default}",
						hoverBackground: "{color.bg.neutral.strong.hover}",
						activeBackground: "{color.bg.neutral.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.on.fill.default}",
						hoverColor: "{color.fg.on.fill.hover}",
						activeColor: "{color.fg.on.fill.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					contrast: {
						background: "{color.bg.surface.canvas.hover}",
						hoverBackground: "{color.bg.surface.canvas.active}",
						activeBackground: "{color.bg.neutral.medium.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.default}",
						hoverColor: "{color.fg.default}",
						activeColor: "{color.fg.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					info: {
						background: "{color.bg.status.info.strong.default}",
						hoverBackground: "{color.bg.status.info.strong.hover}",
						activeBackground: "{color.bg.status.info.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.on.status.info.default}",
						hoverColor: "{color.fg.on.status.info.hover}",
						activeColor: "{color.fg.on.status.info.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						}
					},
					success: {
						background: "{color.bg.status.success.strong.default}",
						hoverBackground: "{color.bg.status.success.strong.hover}",
						activeBackground: "{color.bg.status.success.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.on.status.success.default}",
						hoverColor: "{color.fg.on.status.success.hover}",
						activeColor: "{color.fg.on.status.success.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						}
					},
					warn: {
						background: "{color.bg.status.warning.strong.default}",
						hoverBackground: "{color.bg.status.warning.strong.hover}",
						activeBackground: "{color.bg.status.warning.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.on.status.warning.default}",
						hoverColor: "{color.fg.on.status.warning.hover}",
						activeColor: "{color.fg.on.status.warning.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						}
					},
					help: {
						background: "{color.bg.status.help.strong.default}",
						hoverBackground: "{color.bg.status.help.strong.hover}",
						activeBackground: "{color.bg.status.help.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.on.status.help.default}",
						hoverColor: "{color.fg.on.status.help.hover}",
						activeColor: "{color.fg.on.status.help.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						}
					},
					danger: {
						background: "{color.bg.status.danger.strong.default}",
						hoverBackground: "{color.bg.status.danger.strong.hover}",
						activeBackground: "{color.bg.status.danger.strong.active}",
						borderColor: "transparent",
						hoverBorderColor: "transparent",
						activeBorderColor: "transparent",
						color: "{color.fg.on.status.danger.default}",
						hoverColor: "{color.fg.on.status.danger.hover}",
						activeColor: "{color.fg.on.status.danger.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						}
					}
				},
				outlined: {
					primary: {
						hoverBackground: "{color.bg.brand.weak.hover}",
						activeBackground: "{color.bg.brand.weak.active}",
						borderColor: "{color.border.focus}",
						color: "{color.fg.brand.default}"
					},
					success: {
						hoverBackground: "{color.bg.status.success.weak.hover}",
						activeBackground: "{color.bg.status.success.weak.active}",
						borderColor: "{color.border.brand.strong}",
						color: "{color.fg.status.success.hover}"
					},
					info: {
						hoverBackground: "{color.bg.status.info.weak.hover}",
						activeBackground: "{color.bg.status.info.weak.active}",
						borderColor: "{color.border.status.info.strong}",
						color: "{color.fg.status.info.hover}"
					},
					warn: {
						hoverBackground: "{color.bg.status.warning.weak.hover}",
						activeBackground: "{color.bg.status.warning.weak.active}",
						borderColor: "{color.border.status.warning.strong}",
						color: "{color.fg.status.warning.hover}"
					},
					help: {
						hoverBackground: "{color.bg.status.help.weak.hover}",
						activeBackground: "{color.bg.status.help.weak.active}",
						borderColor: "{color.border.status.help.strong}",
						color: "{color.fg.status.help.hover}"
					},
					danger: {
						hoverBackground: "{color.bg.status.danger.weak.hover}",
						activeBackground: "{color.bg.status.danger.weak.active}",
						borderColor: "{color.border.status.danger.strong}",
						color: "{color.fg.status.danger.hover}"
					},
					contrast: {
						activeBackground: "{color.bg.neutral.strong.active}",
						borderColor: "{color.border.neutral.bold.default}",
						color: "{color.fg.on.fill.default}",
						hoverBackground: "{color.bg.neutral.strong.hover}"
					},
					plain: {
						activeBackground: "{color.bg.neutral.medium.default}",
						borderColor: "{color.border.neutral.strong}",
						color: "{color.fg.default}",
						hoverBackground: "{color.bg.neutral.weak.default}"
					},
					secondary: {
						activeBackground: "{color.bg.neutral.medium.default}",
						borderColor: "{color.border.neutral.strong}",
						color: "{color.fg.default}",
						hoverBackground: "{color.bg.neutral.weak.default}"
					}
				},
				text: {
					primary: {
						hoverBackground: "{color.bg.neutral.weak.default}",
						activeBackground: "{color.bg.neutral.medium.default}",
						color: "{color.fg.default}"
					},
					success: {
						hoverBackground: "{color.bg.status.success.weak.hover}",
						activeBackground: "{color.bg.status.success.weak.active}",
						color: "{color.fg.status.success.hover}"
					},
					info: {
						hoverBackground: "{color.bg.status.info.weak.hover}",
						activeBackground: "{color.bg.status.info.weak.active}",
						color: "{color.fg.status.info.hover}"
					},
					warn: {
						hoverBackground: "{color.bg.status.warning.weak.hover}",
						activeBackground: "{color.bg.status.warning.weak.active}",
						color: "{color.fg.status.warning.hover}"
					},
					help: {
						hoverBackground: "{color.bg.status.help.weak.hover}",
						activeBackground: "{color.bg.status.help.weak.active}",
						color: "{color.fg.status.help.hover}"
					},
					danger: {
						hoverBackground: "{color.bg.status.danger.weak.hover}",
						activeBackground: "{color.bg.status.danger.weak.active}",
						color: "{color.fg.status.danger.hover}"
					},
					contrast: {
						activeBackground: "{color.bg.neutral.strong.active}",
						color: "{color.fg.on.fill.default}",
						hoverBackground: "{color.bg.neutral.strong.hover}"
					},
					plain: {
						activeBackground: "{color.bg.neutral.medium.default}",
						color: "{color.fg.default}",
						hoverBackground: "{color.bg.neutral.weak.default}"
					},
					secondary: {
						activeBackground: "{color.bg.neutral.medium.default}",
						color: "{color.fg.default}",
						hoverBackground: "{color.bg.neutral.weak.default}"
					}
				},
				link: {
					color: "{color.fg.default}",
					hoverColor: "{color.fg.hover}",
					activeColor: "{color.fg.muted}"
				}
			},
			dark: {
				link: {
					activeColor: "{color.fg.inverse.muted}",
					color: "{color.fg.inverse.default}",
					hoverColor: "{color.fg.inverse.hover}"
				},
				outlined: {
					contrast: {
						activeBackground: "{color.bg.surface.canvas.active}",
						borderColor: "{color.border.neutral.inverse}",
						color: "{color.fg.default}",
						hoverBackground: "{color.bg.surface.canvas.hover}"
					},
					danger: {
						activeBackground: "{color.bg.status.danger.weak.active}",
						borderColor: "{color.border.status.danger.subtle}",
						color: "{color.fg.status.danger.hover}",
						hoverBackground: "{color.bg.status.danger.weak.hover}"
					},
					help: {
						activeBackground: "{color.bg.status.help.weak.active}",
						borderColor: "{color.border.status.help.strong}",
						color: "{color.fg.status.help.hover}",
						hoverBackground: "{color.bg.status.help.weak.hover}"
					},
					info: {
						activeBackground: "{color.bg.status.info.weak.active}",
						borderColor: "{color.border.status.info.strong}",
						color: "{color.fg.status.info.hover}",
						hoverBackground: "{color.bg.status.info.weak.hover}"
					},
					plain: {
						activeBackground: "{color.bg.neutral.strong.hover}",
						borderColor: "{color.border.neutral.strong}",
						color: "{color.fg.inverse.default}",
						hoverBackground: "{color.bg.neutral.strong.selected}"
					},
					primary: {
						activeBackground: "{color.bg.brand.weak.active}",
						borderColor: "{color.border.focus}",
						color: "{color.fg.brand.muted}",
						hoverBackground: "{color.bg.brand.weak.hover}"
					},
					secondary: {
						activeBackground: "{color.bg.neutral.strong.hover}",
						borderColor: "{color.border.neutral.strong}",
						color: "{color.fg.inverse.default}",
						hoverBackground: "{color.bg.neutral.strong.selected}"
					},
					success: {
						activeBackground: "{color.bg.status.success.weak.active}",
						borderColor: "{color.border.brand.strong}",
						color: "{color.fg.status.success.hover}",
						hoverBackground: "{color.bg.status.success.weak.hover}"
					},
					warn: {
						activeBackground: "{color.bg.status.warning.weak.active}",
						borderColor: "{color.border.status.warning.strong}",
						color: "{color.fg.status.warning.hover}",
						hoverBackground: "{color.bg.status.warning.weak.hover}"
					}
				},
				root: {
					contrast: {
						activeBackground: "{color.bg.neutral.medium.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.brand.active}",
						background: "{color.bg.neutral.strong.hover}",
						borderColor: "transparent",
						color: "{color.fg.inverse.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.neutral.strong.active}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.brand.hover}"
					},
					danger: {
						activeBackground: "{color.bg.status.danger.strong.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.status.danger.default}",
						background: "{color.bg.status.danger.strong.default}",
						borderColor: "transparent",
						color: "{color.fg.on.status.danger.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.status.danger.strong.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.status.danger.hover}"
					},
					help: {
						activeBackground: "{color.bg.status.help.strong.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.status.help.default}",
						background: "{color.bg.status.help.strong.default}",
						borderColor: "transparent",
						color: "{color.fg.on.status.help.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.status.help.strong.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.status.help.hover}"
					},
					info: {
						activeBackground: "{color.bg.status.info.strong.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.status.info.default}",
						background: "{color.bg.status.info.strong.default}",
						borderColor: "transparent",
						color: "{color.fg.on.status.info.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.status.info.strong.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.status.info.hover}"
					},
					primary: {
						activeBackground: "{color.bg.status.success.strong.default}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.brand.active}",
						background: "{color.bg.brand.strong.default}",
						borderColor: "transparent",
						color: "{color.fg.inverse.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.success.strong.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.brand.hover}"
					},
					secondary: {
						activeBackground: "{color.bg.surface.canvas.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.fill.active}",
						background: "{color.bg.surface.canvas.default}",
						borderColor: "transparent",
						color: "{color.fg.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.surface.canvas.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.fill.hover}"
					},
					success: {
						activeBackground: "{color.bg.status.success.strong.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.status.success.default}",
						background: "{color.bg.brand.strong.active}",
						borderColor: "transparent",
						color: "{color.fg.on.status.success.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.brand.strong.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.status.success.hover}"
					},
					warn: {
						activeBackground: "{color.bg.status.warning.strong.active}",
						activeBorderColor: "transparent",
						activeColor: "{color.fg.on.status.warning.default}",
						background: "{color.bg.status.warning.strong.default}",
						borderColor: "transparent",
						color: "{color.fg.on.status.warning.default}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.status.warning.strong.hover}",
						hoverBorderColor: "transparent",
						hoverColor: "{color.fg.on.status.warning.hover}"
					}
				},
				text: {
					contrast: {
						activeBackground: "{color.bg.surface.canvas.active}",
						color: "{color.fg.default}",
						hoverBackground: "{color.bg.surface.canvas.hover}"
					},
					danger: {
						activeBackground: "{color.bg.status.danger.weak.active}",
						color: "{color.fg.status.danger.hover}",
						hoverBackground: "{color.bg.status.danger.weak.hover}"
					},
					help: {
						activeBackground: "{color.bg.status.help.weak.active}",
						color: "{color.fg.status.help.hover}",
						hoverBackground: "{color.bg.status.help.weak.hover}"
					},
					info: {
						activeBackground: "{color.bg.status.info.weak.active}",
						color: "{color.fg.status.info.hover}",
						hoverBackground: "{color.bg.status.info.weak.hover}"
					},
					plain: {
						activeBackground: "{color.bg.neutral.strong.hover}",
						color: "{color.fg.inverse.default}",
						hoverBackground: "{color.bg.neutral.strong.selected}"
					},
					primary: {
						activeBackground: "{color.bg.neutral.strong.hover}",
						color: "{color.fg.inverse.default}",
						hoverBackground: "{color.bg.neutral.strong.selected}"
					},
					secondary: {
						activeBackground: "{color.bg.neutral.strong.hover}",
						color: "{color.fg.inverse.default}",
						hoverBackground: "{color.bg.neutral.strong.selected}"
					},
					success: {
						activeBackground: "{color.bg.status.success.weak.active}",
						color: "{color.fg.status.success.hover}",
						hoverBackground: "{color.bg.status.success.weak.hover}"
					},
					warn: {
						activeBackground: "{color.bg.status.warning.weak.active}",
						color: "{color.fg.status.warning.hover}",
						hoverBackground: "{color.bg.status.warning.weak.hover}"
					}
				}
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.400}",
			roundedBorderRadius: "{dimension.borderRadius.max}",
			gap: "{dimension.space.200}",
			paddingX: "{dimension.space.400}",
			paddingY: "{dimension.space.200}",
			height: "{dimension.size.1000}",
			iconOnlyWidth: "{dimension.size.1000}",
			raisedShadow: "none",
			badgeSize: "{dimension.size.450}",
			transitionDuration: "{effects.transition.duration.200}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				offset: "{dimension.focusRing.offset}"
			},
			sm: {
				fontSize: "{fonts.fontSize.200}",
				iconOnlyWidth: "{dimension.size.800}",
				paddingX: "{dimension.space.400}",
				paddingY: "{dimension.space.200}"
			},
			lg: {
				fontSize: "{fonts.fontSize.500}",
				iconOnlyWidth: "{dimension.size.1200}",
				paddingX: "{dimension.space.700}",
				paddingY: "{dimension.space.400}"
			},
			label: {
				fontWeight: "{fonts.fontWeight.demibold}"
			}
		}
	},
	card: {
		extend: {
			borderColor: "{color.border.neutral.default}",
			borderWidth: "{dimension.borderWidth.100}"
		},
		root: {
			background: "{color.bg.surface.default.default}",
			borderRadius: "{dimension.borderRadius.400}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.none}"
		},
		body: {
			padding: "{dimension.space.400}",
			gap: "{dimension.space.400}"
		},
		caption: {
			gap: "{dimension.space.100}"
		},
		title: {
			fontSize: "{fonts.fontSize.400}",
			fontWeight: "{fonts.fontWeight.demibold}"
		},
		subtitle: {
			color: "{color.fg.muted}"
		},
		overlay: {
			shadow: "{effects.elevation.300}"
		}
	},
	carousel: {
		colorScheme: {
			light: {
				indicator: {
					background: "{color.bg.neutral.weak.active}",
					hoverBackground: "{color.bg.neutral.medium.active}",
					activeBackground: "{color.bg.neutral.strong.default}"
				}
			},
			dark: {
				indicator: {
					activeBackground: "{color.bg.neutral.strong.default}",
					background: "{color.bg.neutral.weak.active}",
					hoverBackground: "{color.bg.neutral.medium.active}"
				}
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		content: {
			gap: "{dimension.space.200}"
		},
		indicatorList: {
			padding: "{dimension.space.400}",
			gap: "{dimension.space.200}"
		},
		indicator: {
			width: "{dimension.size.200}",
			height: "{dimension.size.200}",
			borderRadius: "{dimension.borderRadius.max}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		}
	},
	checkbox: {
		root: {
			borderRadius: "{dimension.borderRadius.200}",
			extend: {
				borderWidth: "{dimension.borderWidth.100}"
			},
			width: "{dimension.size.700}",
			height: "{dimension.size.700}",
			background: "{color.bg.surface.default.default}",
			checkedBackground: "{color.bg.neutral.strong.default}",
			checkedHoverBackground: "{color.bg.neutral.strong.hover}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			filledBackground: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.neutral.bold.default}",
			focusBorderColor: "{color.border.neutral.bold.default}",
			checkedBorderColor: "{color.border.neutral.bold.default}",
			checkedHoverBorderColor: "{color.border.neutral.bold.hover}",
			checkedFocusBorderColor: "{color.border.brand.default}",
			checkedDisabledBorderColor: "{color.border.neutral.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			shadow: "{effects.elevation.none}",
			focusRing: {
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}",
				width: "{dimension.focusRing.width}"
			},
			sm: {
				width: "{dimension.size.200}",
				height: "{dimension.size.200}"
			},
			lg: {
				width: "{dimension.size.600}",
				height: "{dimension.size.600}"
			},
			transitionDuration: "{effects.transition.duration.200}"
		},
		icon: {
			size: "{dimension.size.450}",
			color: "{color.fg.active}",
			checkedColor: "{color.fg.on.fill.default}",
			checkedHoverColor: "{color.fg.on.fill.hover}",
			disabledColor: "{color.fg.muted}",
			sm: {
				size: "{dimension.size.350}"
			},
			lg: {
				size: "{dimension.size.600}"
			}
		}
	},
	chip: {
		extend: {
			borderColor: "transparent",
			borderWidth: "{dimension.borderWidth.100}"
		},
		root: {
			borderRadius: "{dimension.borderRadius.200}",
			paddingX: "{dimension.space.200}",
			paddingY: "{dimension.space.100}",
			gap: "{dimension.space.200}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		colorScheme: {
			light: {
				root: {
					background: "{color.bg.surface.canvas.hover}",
					color: "{color.fg.default}"
				},
				icon: {
					color: "{color.fg.default}"
				},
				removeIcon: {
					color: "{color.fg.default}"
				}
			},
			dark: {
				icon: {
					color: "{color.fg.inverse.default}"
				},
				removeIcon: {
					color: "{color.fg.inverse.default}"
				},
				root: {
					background: "{color.bg.neutral.strong.hover}",
					color: "{color.fg.inverse.default}"
				}
			}
		},
		image: {
			width: "{dimension.size.none}",
			height: "{dimension.size.none}"
		},
		icon: {
			size: "{dimension.size.450}"
		},
		removeIcon: {
			size: "{dimension.size.450}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		}
	},
	confirmdialog: {
		extend: {
			extIcon: {
				success: "{color.fg.status.success.default}",
				info: "{color.fg.status.info.default}",
				help: "{color.fg.status.help.default}",
				warn: "{color.fg.status.warning.default}",
				danger: "{color.fg.status.danger.default}"
			}
		},
		icon: {
			size: "{dimension.size.700}",
			color: "{color.fg.default}"
		},
		content: {
			gap: "{dimension.space.none}"
		}
	},
	confirmpopup: {
		root: {
			background: "{color.bg.surface.default.default}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.400}",
			gutter: "{dimension.space.400}",
			arrowOffset: "{dimension.space.600}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.400}"
		},
		content: {
			padding: "{dimension.space.400}",
			gap: "{dimension.space.400}"
		},
		icon: {
			size: "{dimension.size.700}",
			color: "{color.fg.default}"
		},
		footer: {
			gap: "{dimension.space.200}",
			padding: "{dimension.space.none} {dimension.space.700} {dimension.space.700} {dimension.space.700}"
		}
	},
	contextmenu: {
		root: {
			background: "{color.bg.surface.default.default}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.400}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		list: {
			padding: "{dimension.space.200} {dimension.space.none}",
			gap: "{dimension.space.100}"
		},
		item: {
			padding: "{dimension.space.200} {dimension.space.400}",
			gap: "{dimension.space.200}",
			activeBackground: "{color.bg.neutral.medium.default}",
			activeColor: "{color.fg.hover}",
			borderRadius: "{dimension.borderRadius.400}",
			color: "{color.fg.default}",
			focusBackground: "{color.bg.neutral.weak.default}",
			focusColor: "{color.fg.hover}",
			icon: {
				activeColor: "{color.fg.hover}",
				color: "{color.fg.default}",
				focusColor: "{color.fg.hover}"
			}
		},
		submenu: {
			mobileIndent: "{dimension.space.600}"
		},
		separator: {
			borderColor: "{color.border.neutral.default}"
		},
		submenuIcon: {
			activeColor: "{color.fg.hover}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.hover}",
			size: "{dimension.size.400}"
		}
	},
	datatable: {
		colorScheme: {
			light: {
				root: {
					color: "{color.fg.default}",
					borderColor: "{color.border.neutral.default}"
				},
				header: {
					background: "{color.bg.surface.default.hover}",
					color: "{color.fg.default}"
				},
				headerCell: {
					background: "{color.bg.surface.raised.selected}",
					hoverBackground: "{color.bg.neutral.weak.default}",
					color: "{color.fg.default}"
				},
				footer: {
					background: "{color.bg.surface.canvas.default}",
					color: "{color.fg.default}"
				},
				footerCell: {
					background: "{color.bg.neutral.weak.default}",
					color: "{color.fg.default}"
				},
				row: {
					stripedBackground: "{color.bg.neutral.weak.default}"
				},
				bodyCell: {
					selectedBorderColor: "{color.border.neutral.default}"
				}
			},
			dark: {
				bodyCell: {
					selectedBorderColor: "{color.border.neutral.bold.hover}"
				},
				footer: {
					background: "{color.bg.neutral.strong.default}",
					color: "{color.fg.inverse.default}"
				},
				footerCell: {
					background: "{color.bg.neutral.strong.default}",
					color: "{color.fg.inverse.default}"
				},
				header: {
					background: "{color.bg.surface.default.hover}",
					color: "{color.fg.inverse.default}"
				},
				headerCell: {
					background: "{color.bg.surface.raised.selected}",
					color: "{color.fg.inverse.default}",
					hoverBackground: "{color.bg.neutral.strong.selected}"
				},
				root: {
					borderColor: "{color.border.neutral.bold.hover}",
					color: "{color.fg.inverse.default}"
				},
				row: {
					stripedBackground: "{color.bg.neutral.strong.default}"
				}
			}
		},
		extended: {
			extHeaderCell: {
				selectedHoverBackground: "{color.bg.neutral.strong.hover}"
			},
			extRow: {
				selectedHoverBackground: "{color.bg.neutral.strong.hover}",
				stripedHoverBackground: "{color.bg.neutral.weak.default}",
				iconSize: "{dimension.size.600}"
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		header: {
			borderColor: "{color.border.neutral.default}",
			borderWidth: "{dimension.borderWidth.100} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}",
			padding: "{dimension.space.400}",
			sm: {
				padding: "{dimension.space.200}"
			},
			lg: {
				padding: "{dimension.space.600}"
			}
		},
		headerCell: {
			selectedBackground: "{color.bg.neutral.strong.selected}",
			borderColor: "{color.border.neutral.default}",
			hoverColor: "{color.fg.hover}",
			selectedColor: "{color.fg.on.fill.default}",
			gap: "{dimension.space.200}",
			padding: "{dimension.space.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.focusRing.shadow}"
			},
			sm: {
				padding: "{dimension.space.200}"
			},
			lg: {
				padding: "{dimension.space.600}"
			}
		},
		columnTitle: {
			fontWeight: "{fonts.fontWeight.bold}"
		},
		row: {
			background: "{color.bg.surface.raised.default}",
			hoverBackground: "{color.bg.neutral.weak.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			selectedColor: "{color.fg.on.fill.default}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.focusRing.shadow}"
			}
		},
		bodyCell: {
			borderColor: "{color.border.neutral.default}",
			padding: "{dimension.space.400}",
			sm: {
				padding: "{dimension.space.200}"
			},
			lg: {
				padding: "{dimension.space.600}"
			}
		},
		footerCell: {
			borderColor: "{color.border.neutral.default}",
			padding: "{dimension.space.400}",
			sm: {
				padding: "{dimension.space.200}"
			},
			lg: {
				padding: "{dimension.space.600}"
			}
		},
		columnFooter: {
			fontWeight: "{fonts.fontWeight.bold}"
		},
		dropPoint: {
			color: "{color.fg.default}"
		},
		footer: {
			borderColor: "{color.border.neutral.default}",
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}",
			padding: "{dimension.space.400}",
			sm: {
				padding: "{dimension.space.200}"
			},
			lg: {
				padding: "{dimension.space.600}"
			}
		},
		columnResizer: {
			width: "{dimension.size.200}"
		},
		resizeIndicator: {
			width: "{dimension.borderWidth.100}",
			color: "{color.fg.default}"
		},
		sortIcon: {
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			size: "{dimension.size.450}"
		},
		loadingIcon: {
			size: "{dimension.size.900}"
		},
		rowToggleButton: {
			hoverBackground: "{color.bg.neutral.weak.default}",
			selectedHoverBackground: "{color.bg.neutral.weak.default}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.default}",
			selectedHoverColor: "{color.fg.default}",
			size: "{dimension.size.900}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		filter: {
			inlineGap: "{dimension.space.200}",
			rule: {
				borderColor: "{color.border.neutral.default}"
			},
			constraintList: {
				padding: "{dimension.space.100}",
				gap: "{dimension.space.100}"
			},
			constraint: {
				focusBackground: "{color.bg.neutral.weak.default}",
				selectedBackground: "{color.bg.neutral.strong.selected}",
				selectedFocusBackground: "{color.bg.neutral.strong.active}",
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}",
				selectedColor: "{color.fg.on.fill.default}",
				selectedFocusColor: "{color.fg.on.fill.active}",
				padding: "{dimension.space.200} {dimension.space.400}",
				borderRadius: "{dimension.borderRadius.200}",
				separator: {
					borderColor: "{color.border.neutral.default}"
				}
			},
			overlaySelect: {
				background: "{color.bg.surface.raised.default}",
				color: "{color.fg.default}",
				borderColor: "{color.border.neutral.default}",
				borderRadius: "{dimension.borderRadius.400}",
				shadow: "{effects.elevation.400}"
			},
			overlayPopover: {
				background: "{color.bg.surface.raised.default}",
				color: "{color.fg.default}",
				borderColor: "{color.border.neutral.default}",
				borderRadius: "{dimension.borderRadius.400}",
				shadow: "{effects.elevation.400}",
				padding: "{dimension.space.400}",
				gap: "{dimension.space.100}"
			}
		},
		paginatorTop: {
			borderColor: "{color.border.neutral.strong}",
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}"
		},
		paginatorBottom: {
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}",
			borderColor: "{color.border.neutral.default}"
		}
	},
	dataview: {
		root: {
			borderWidth: "{dimension.borderWidth.100}",
			borderRadius: "{dimension.borderRadius.100}",
			padding: "{dimension.space.none}",
			borderColor: "{color.border.neutral.default}"
		},
		header: {
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.none} {dimension.borderRadius.none} {dimension.borderRadius.none} {dimension.borderRadius.none}",
			color: "{color.fg.default}",
			borderColor: "{color.border.neutral.default}"
		},
		content: {
			background: "{color.bg.surface.default.default}",
			color: "{color.fg.default}",
			borderColor: "{color.border.neutral.default}",
			borderWidth: "{dimension.borderWidth.none}",
			padding: "{dimension.space.none}",
			borderRadius: "{dimension.borderRadius.none}"
		},
		footer: {
			background: "{color.bg.surface.canvas.default}",
			color: "{color.fg.default}",
			borderWidth: "{dimension.borderWidth.100} {dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.none}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.none} {dimension.borderRadius.none} {dimension.borderRadius.none} {dimension.borderRadius.none}",
			borderColor: "{color.border.neutral.default}"
		},
		paginatorTop: {
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}",
			borderColor: "{color.border.neutral.default}"
		},
		paginatorBottom: {
			borderWidth: "{dimension.borderWidth.100} {dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.none}",
			borderColor: "{color.border.neutral.default}"
		},
		colorScheme: {
			dark: {
				header: {
					background: "{color.bg.surface.default.default}",
					color: "{color.fg.inverse.default}"
				}
			},
			light: {
				header: {
					background: "{color.bg.surface.default.default}",
					color: "{color.fg.default}"
				}
			}
		}
	},
	datepicker: {
		extend: {
			extDate: {
				selectedHoverBackground: "{color.bg.neutral.strong.hover}"
			},
			extToday: {
				hoverBackground: "{color.bg.neutral.weak.default}",
				borderColor: "{color.border.neutral.bold.hover}"
			},
			extTitle: {
				width: "{dimension.size.1900}"
			},
			extTimePicker: {
				minWidth: "{dimension.size.1800}",
				color: "{color.fg.default}"
			}
		},
		colorScheme: {
			light: {
				dropdown: {
					background: "{color.bg.surface.default.default}",
					hoverBackground: "{color.bg.surface.canvas.default}",
					activeBackground: "{color.bg.neutral.strong.default}",
					color: "{color.fg.default}",
					hoverColor: "{color.fg.default}",
					activeColor: "{color.fg.inverse.active}"
				},
				today: {
					background: "transparent",
					color: "{color.fg.default}"
				}
			},
			dark: {
				dropdown: {
					activeBackground: "{color.bg.surface.canvas.default}",
					activeColor: "{color.fg.on.fill.active}",
					background: "{color.bg.surface.default.default}",
					color: "{color.fg.inverse.default}",
					hoverBackground: "{color.bg.neutral.strong.selected}",
					hoverColor: "{color.fg.on.brand.hover}"
				},
				today: {
					background: "transparent",
					color: "{color.fg.inverse.default}"
				}
			}
		},
		panel: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}",
			borderRadius: "{dimension.borderRadius.400}",
			shadow: "{effects.elevation.400}",
			padding: "{dimension.space.none}"
		},
		header: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}",
			padding: "{dimension.space.400}"
		},
		title: {
			gap: "{dimension.space.200}",
			fontWeight: "{fonts.fontWeight.bold}"
		},
		selectMonth: {
			hoverBackground: "{color.bg.neutral.weak.default}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			borderRadius: "{dimension.borderRadius.400}",
			padding: "{dimension.space.200}"
		},
		inputIcon: {
			color: "{color.fg.muted}"
		},
		dropdown: {
			width: "{dimension.size.1700}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.neutral.strong}",
			activeBorderColor: "{color.border.neutral.strong}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			},
			sm: {
				width: "{dimension.size.none}"
			},
			lg: {
				width: "{dimension.size.none}"
			}
		},
		group: {
			borderColor: "{color.border.neutral.default}",
			gap: "{dimension.space.400}"
		},
		selectYear: {
			hoverBackground: "{color.bg.neutral.weak.default}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			borderRadius: "{dimension.borderRadius.400}",
			padding: "{dimension.space.100}"
		},
		dayView: {
			margin: "{dimension.space.400}"
		},
		weekDay: {
			padding: "{dimension.space.100}",
			fontWeight: "{fonts.fontWeight.bold}",
			color: "{color.fg.default}"
		},
		date: {
			hoverBackground: "{color.bg.neutral.weak.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			rangeSelectedBackground: "{color.bg.neutral.weak.default}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.default}",
			selectedColor: "{color.fg.on.fill.default}",
			rangeSelectedColor: "{color.fg.default}",
			width: "{dimension.size.900}",
			height: "{dimension.size.900}",
			borderRadius: "{dimension.borderRadius.200}",
			padding: "{dimension.space.100}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		monthView: {
			margin: "{dimension.space.none} {dimension.space.none} {dimension.space.none} {dimension.space.none}"
		},
		month: {
			padding: "{dimension.space.none}",
			borderRadius: "{dimension.borderRadius.none}"
		},
		yearView: {
			margin: "{dimension.space.none} {dimension.space.none} {dimension.space.none} {dimension.space.none}"
		},
		year: {
			padding: "{dimension.space.none}",
			borderRadius: "{dimension.borderRadius.none}"
		},
		buttonbar: {
			padding: "{dimension.space.400}",
			borderColor: "{color.border.neutral.default}"
		},
		timePicker: {
			padding: "{dimension.space.400}",
			borderColor: "{color.border.neutral.default}",
			gap: "{dimension.space.200}",
			buttonGap: "{dimension.space.100}"
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		}
	},
	dialog: {
		extend: {
			borderWidth: "{dimension.borderWidth.100}",
			backdrop: "{color.bg.surface.backdrop}"
		},
		root: {
			background: "{color.bg.surface.raised.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}",
			borderRadius: "{dimension.size.700}",
			shadow: "{effects.elevation.400}"
		},
		header: {
			padding: "{dimension.space.700} {dimension.space.700} {dimension.space.400} {dimension.space.700}",
			gap: "{dimension.space.200}"
		},
		title: {
			fontSize: "{fonts.fontSize.500}",
			fontWeight: "{fonts.fontWeight.demibold}"
		},
		content: {
			padding: "{dimension.space.700}"
		},
		footer: {
			padding: "{dimension.space.none} {dimension.space.700} {dimension.space.700} {dimension.space.700}",
			gap: "{dimension.space.200}"
		},
		colorScheme: {
			dark: {
				root: {
					background: "{color.bg.surface.canvas.default}"
				}
			}
		}
	},
	divider: {
		extend: {
			content: {
				gap: "{dimension.space.200}"
			},
			iconSize: "{dimension.size.450}"
		},
		horizontal: {
			margin: "{dimension.space.400} {dimension.space.none}",
			padding: "{dimension.space.none} {dimension.space.400}",
			content: {
				padding: "{dimension.space.none} {dimension.space.200}"
			}
		},
		vertical: {
			margin: "{dimension.space.none} {dimension.space.400}",
			padding: "{dimension.space.400} {dimension.space.none}",
			content: {
				padding: "{dimension.space.200} {dimension.space.none}"
			}
		},
		content: {
			background: "{color.bg.surface.default.default}",
			color: "{color.fg.default}"
		},
		root: {
			borderColor: "{color.border.neutral.default}"
		}
	},
	drawer: {
		extend: {
			borderRadius: "{dimension.borderRadius.200}",
			borderWidth: "{dimension.borderWidth.100}",
			width: "{dimension.size.2000}",
			overlayWidth: {
				sm: "{dimension.size.1700}",
				base: "{dimension.size.1900}",
				lg: "{dimension.size.2000}",
				xlg: "{dimension.size.2200}"
			},
			extHeader: {
				gap: "{dimension.space.200}",
				borderColor: "{color.border.neutral.strong}"
			},
			margin: "{dimension.space.200}",
			scale: "{dimension.size.50}",
			backdrop: "{color.bg.surface.backdrop}"
		},
		root: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.200}"
		},
		header: {
			padding: "{dimension.space.700} {dimension.space.700} {dimension.space.400} {dimension.space.700}"
		},
		title: {
			fontSize: "{fonts.fontSize.500}",
			fontWeight: "{fonts.fontWeight.demibold}"
		},
		content: {
			padding: "{dimension.space.700}"
		},
		footer: {
			padding: "{dimension.space.none} {dimension.space.700} {dimension.space.700} {dimension.space.700}"
		}
	},
	fileupload: {
		extend: {
			extDragNdrop: {
				background: "{color.bg.surface.raised.default}",
				borderRadius: "{dimension.borderRadius.400}",
				iconSize: "{dimension.size.900}",
				padding: "{dimension.space.400}",
				info: {
					gap: "{dimension.space.100}"
				}
			},
			extFile: {
				iconSize: "{dimension.size.600}"
			},
			extContent: {
				borderRadius: "{dimension.borderRadius.400}",
				highlightBorderDefault: "{color.border.neutral.strong}"
			}
		},
		colorScheme: {
			light: {
				header: {
					background: "{color.bg.surface.default.default}",
					color: "{color.fg.default}"
				}
			},
			dark: {
				header: {
					background: "{color.bg.surface.default.default}",
					color: "{color.fg.inverse.default}"
				}
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		header: {
			borderColor: "{color.border.neutral.default}",
			borderWidth: "{dimension.borderWidth.none}",
			padding: "{dimension.space.none}",
			borderRadius: "{dimension.borderRadius.none}",
			gap: "{dimension.space.200}"
		},
		content: {
			highlightBorderColor: "{color.border.neutral.bold.default}",
			padding: "{dimension.space.none}",
			gap: "{dimension.space.200}"
		},
		file: {
			padding: "{dimension.space.200}",
			gap: "{dimension.space.200}",
			borderColor: "{color.border.neutral.strong}",
			info: {
				gap: "{dimension.space.100}"
			}
		},
		fileList: {
			gap: "{dimension.space.200}"
		},
		progressbar: {
			height: "{dimension.size.200}"
		},
		basic: {
			gap: "{dimension.space.200}"
		}
	},
	floatlabel: {
		extend: {
			height: "{dimension.size.1400}",
			iconSize: "{dimension.size.600}"
		},
		root: {
			color: "{color.fg.muted}",
			focusColor: "{color.fg.muted}",
			activeColor: "{color.fg.muted}",
			invalidColor: "{color.fg.status.danger.hover}",
			transitionDuration: "{effects.transition.duration.200}",
			positionX: "{dimension.space.400}",
			positionY: "{dimension.space.400}",
			fontWeight: "{fonts.fontWeight.regular}",
			active: {
				fontSize: "{fonts.fontSize.100}",
				fontWeight: "{fonts.fontWeight.regular}"
			}
		},
		over: {
			active: {
				top: "{dimension.space.400}"
			}
		},
		inside: {
			input: {
				paddingTop: "{dimension.space.800}",
				paddingBottom: "{dimension.space.400}"
			},
			active: {
				top: "{dimension.space.400}"
			}
		},
		on: {
			borderRadius: "{dimension.borderRadius.none}",
			active: {
				padding: "{dimension.space.none} {dimension.space.100}",
				background: "{color.bg.surface.raised.default}"
			}
		}
	},
	galleria: {
		extend: {
			backdrop: "{color.bg.surface.backdrop}"
		},
		colorScheme: {
			light: {
				thumbnailContent: {
					background: "{color.bg.neutral.weak.default}"
				},
				thumbnailNavButton: {
					hoverBackground: "{color.bg.neutral.medium.default}",
					color: "{color.fg.default}",
					hoverColor: "{color.fg.hover}"
				},
				indicatorButton: {
					background: "{color.bg.neutral.weak.active}",
					hoverBackground: "{color.bg.neutral.medium.active}"
				},
				thumbnailsContent: {
					background: "{color.bg.neutral.medium.default}"
				}
			},
			dark: {
				indicatorButton: {
					background: "{color.bg.neutral.strong.active}",
					hoverBackground: "{color.bg.neutral.medium.active}"
				},
				thumbnailNavButton: {
					color: "{color.fg.inverse.default}",
					hoverBackground: "{color.bg.neutral.medium.default}",
					hoverColor: "{color.fg.inverse.hover}"
				},
				thumbnailsContent: {
					background: "{color.bg.neutral.medium.default}"
				},
				thumbnailContent: {
					background: "{color.bg.neutral.strong.default}"
				}
			}
		},
		root: {
			borderWidth: "{dimension.borderWidth.100}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		navButton: {
			background: "transparent",
			hoverBackground: "{color.bg.neutral.medium.default}",
			color: "{color.fg.inverse.default}",
			hoverColor: "{color.fg.inverse.hover}",
			size: "{dimension.size.1400}",
			gutter: "{dimension.space.200}",
			prev: {
				borderRadius: "{dimension.borderRadius.200}"
			},
			next: {
				borderRadius: "{dimension.borderRadius.200}"
			},
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		navIcon: {
			size: "{dimension.size.900}"
		},
		thumbnailsContent: {
			padding: "{dimension.space.100}"
		},
		thumbnailNavButton: {
			size: "{dimension.size.900}",
			borderRadius: "{dimension.borderRadius.400}",
			gutter: "{dimension.space.200}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		thumbnailNavButtonIcon: {
			size: "{dimension.size.450}"
		},
		caption: {
			background: "{color.bg.neutral.medium.default}",
			color: "{color.fg.default}",
			padding: "{dimension.space.200}"
		},
		indicatorList: {
			gap: "{dimension.space.200}",
			padding: "{dimension.space.400}"
		},
		indicatorButton: {
			width: "{dimension.size.200}",
			height: "{dimension.size.200}",
			activeBackground: "{color.bg.neutral.strong.default}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		insetIndicatorList: {
			background: "{color.bg.surface.backdrop}"
		},
		insetIndicatorButton: {
			background: "{color.bg.neutral.medium.default}",
			hoverBackground: "{color.bg.neutral.medium.default}",
			activeBackground: "{color.bg.neutral.medium.default}"
		},
		closeButton: {
			size: "{dimension.size.1400}",
			gutter: "{dimension.space.200}",
			background: "{color.bg.neutral.medium.default}",
			hoverBackground: "{color.bg.neutral.medium.default}",
			color: "{color.fg.inverse.default}",
			hoverColor: "{color.fg.inverse.hover}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		closeButtonIcon: {
			size: "{dimension.size.900}"
		}
	},
	inputgroup: {
		extend: {
			borderWidth: "{dimension.borderWidth.100}",
			iconSize: "{dimension.size.450}"
		},
		colorScheme: {
			light: {
				addon: {
					background: "{color.bg.surface.raised.default}",
					borderColor: "{color.border.neutral.strong}",
					color: "{color.fg.muted}"
				}
			},
			dark: {
				addon: {
					background: "{color.bg.surface.raised.default}",
					borderColor: "{color.border.neutral.strong}",
					color: "{color.fg.inverse.muted}"
				}
			}
		},
		addon: {
			borderRadius: "{dimension.borderRadius.400}",
			padding: "{dimension.space.400}",
			minWidth: "{dimension.size.1700}"
		}
	},
	inputnumber: {
		extend: {
			borderWidth: "{dimension.borderWidth.100}",
			extButton: {
				height: "{dimension.size.1100}",
				iconSize: "{dimension.size.450}"
			}
		},
		colorScheme: {
			light: {
				button: {
					background: "{color.bg.surface.raised.default}",
					hoverBackground: "{color.bg.neutral.weak.default}",
					activeBackground: "transparent",
					borderColor: "{color.border.neutral.strong}",
					hoverBorderColor: "{color.border.neutral.strong}",
					activeBorderColor: "{color.border.neutral.strong}",
					color: "{color.fg.default}",
					hoverColor: "{color.fg.hover}",
					activeColor: "{color.fg.default}"
				}
			},
			dark: {
				button: {
					activeBackground: "transparent",
					activeBorderColor: "{color.border.neutral.strong}",
					activeColor: "{color.fg.on.brand.active}",
					background: "{color.bg.surface.raised.default}",
					borderColor: "{color.border.neutral.strong}",
					color: "{color.fg.inverse.default}",
					hoverBackground: "{color.bg.neutral.strong.selected}",
					hoverBorderColor: "{color.border.neutral.strong}",
					hoverColor: "{color.fg.inverse.hover}"
				}
			}
		},
		transitionDuration: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		button: {
			width: "{dimension.size.1100}",
			borderRadius: "{dimension.borderRadius.400}",
			verticalPadding: "{dimension.space.400}"
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		}
	},
	inputotp: {
		extend: {
			height: "{dimension.size.1100}",
			borderWidth: "{dimension.borderWidth.100}",
			extSm: {
				height: "{dimension.size.800}",
				borderRadius: "{dimension.borderRadius.200}"
			},
			extLg: {
				height: "{dimension.size.1200}"
			}
		},
		root: {
			gap: "{dimension.space.200}"
		},
		input: {
			width: "{dimension.size.1100}",
			lg: {
				width: "{dimension.size.1200}"
			},
			sm: {
				width: "{dimension.size.800}"
			}
		}
	},
	inputtext: {
		extend: {
			readonlyBackground: "{color.bg.neutral.weak.default}",
			iconSize: "{dimension.size.450}",
			borderWidth: "{dimension.borderWidth.100}",
			extXlg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.600}"
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			filledBackground: "{color.bg.surface.default.default}",
			filledHoverBackground: "{color.bg.surface.default.default}",
			filledFocusBackground: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.brand.strong}",
			focusBorderColor: "{color.border.brand.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			color: "{color.fg.default}",
			disabledColor: "{color.fg.muted}",
			placeholderColor: "{color.fg.muted}",
			invalidPlaceholderColor: "{color.fg.status.danger.hover}",
			shadow: "{effects.elevation.none}",
			paddingX: "{dimension.space.300}",
			paddingY: "{dimension.space.300}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}",
			sm: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.200}"
			},
			lg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.400}"
			},
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}"
			}
		}
	},
	listbox: {
		extend: {
			extOption: {
				label: {
					gap: "{dimension.space.100}"
				},
				caption: {
					color: "{color.fg.muted}",
					stripedColor: "{color.fg.muted}"
				},
				gap: "{dimension.space.200}"
			}
		},
		colorScheme: {
			light: {
				option: {
					stripedBackground: "{color.bg.surface.raised.selected}"
				}
			},
			dark: {
				option: {
					stripedBackground: "{color.bg.surface.raised.selected}"
				}
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			borderColor: "{color.border.neutral.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			color: "{color.fg.active}",
			disabledColor: "{color.fg.muted}",
			shadow: "{effects.elevation.none}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		list: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}",
			header: {
				padding: "{dimension.space.400} {dimension.space.400} {dimension.space.none} {dimension.space.400}"
			}
		},
		option: {
			focusBackground: "{color.bg.neutral.weak.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			selectedFocusBackground: "{color.bg.neutral.strong.active}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			selectedColor: "{color.fg.on.fill.default}",
			selectedFocusColor: "{color.fg.on.fill.active}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}"
		},
		optionGroup: {
			background: "{color.bg.surface.raised.default}",
			color: "{color.fg.muted}",
			fontWeight: "{fonts.fontWeight.regular}",
			padding: "{dimension.space.200} {dimension.space.400}"
		},
		checkmark: {
			color: "{color.fg.default}",
			gutterStart: "{dimension.space.negative.200}",
			gutterEnd: "{dimension.space.200}"
		},
		emptyMessage: {
			padding: "{dimension.space.200} {dimension.space.400}"
		}
	},
	megamenu: {
		extend: {
			extItem: {
				caption: {
					color: "{color.fg.muted}",
					gap: "{dimension.space.100}"
				}
			},
			iconSize: "{dimension.size.600}"
		},
		colorScheme: {
			light: {
				root: {
					background: "transparent"
				}
			},
			dark: {
				root: {
					background: "transparent"
				}
			}
		},
		root: {
			borderColor: "transparent",
			borderRadius: "{dimension.borderRadius.400}",
			color: "{color.fg.default}",
			gap: "{dimension.space.100}",
			transitionDuration: "{effects.transition.duration.200}",
			verticalOrientation: {
				padding: "{dimension.space.100}",
				gap: "{dimension.space.100}"
			},
			horizontalOrientation: {
				padding: "{dimension.space.100}",
				gap: "{dimension.space.100}"
			}
		},
		baseItem: {
			borderRadius: "{dimension.borderRadius.400}",
			padding: "{dimension.space.200} {dimension.space.400}"
		},
		item: {
			focusBackground: "{color.bg.neutral.weak.default}",
			activeBackground: "{color.bg.neutral.strong.default}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			activeColor: "{color.fg.inverse.active}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}",
			gap: "{dimension.space.200}",
			icon: {
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}",
				activeColor: "{color.fg.inverse.active}"
			}
		},
		overlay: {
			padding: "{dimension.space.100}",
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.400}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.400}",
			gap: "{dimension.space.none}"
		},
		submenu: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}"
		},
		submenuLabel: {
			padding: "{dimension.space.200} {dimension.space.400}",
			background: "transparent",
			color: "{color.fg.muted}",
			fontWeight: "{fonts.fontWeight.regular}"
		},
		submenuIcon: {
			size: "{dimension.size.600}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			activeColor: "{color.fg.inverse.active}"
		},
		separator: {
			borderColor: "{color.border.neutral.default}"
		},
		mobileButton: {
			borderRadius: "{dimension.borderRadius.200}",
			size: "{dimension.size.900}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			hoverBackground: "{color.bg.neutral.weak.default}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		}
	},
	menu: {
		extend: {
			paddingX: "{dimension.space.100}",
			iconSize: "{dimension.size.600}",
			paddingY: "{dimension.space.100}",
			extItem: {
				caption: {
					gap: "{dimension.space.100}",
					color: "{color.fg.muted}"
				},
				activeBackground: "{color.bg.neutral.strong.default}",
				activeColor: "{color.fg.inverse.active}",
				icon: {
					activeColor: "{color.fg.inverse.active}"
				}
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.400}",
			shadow: "{effects.elevation.400}",
			transitionDuration: "{effects.transition.duration.200}",
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}"
		},
		list: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}"
		},
		submenuLabel: {
			padding: "{dimension.space.200} {dimension.space.400}",
			fontWeight: "{fonts.fontWeight.regular}",
			background: "transparent",
			color: "{color.fg.muted}"
		},
		separator: {
			borderColor: "{color.border.neutral.default}"
		},
		item: {
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}",
			gap: "{dimension.space.200}",
			color: "{color.fg.default}",
			focusBackground: "{color.bg.surface.canvas.default}",
			focusColor: "{color.fg.default}",
			icon: {
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}"
			}
		}
	},
	menubar: {
		extend: {
			iconSize: "{dimension.size.600}",
			extItem: {
				caption: {
					color: "{color.fg.muted}",
					gap: "{dimension.space.100}"
				}
			},
			extSubmenuLabel: {
				padding: "{dimension.space.200} {dimension.space.400}",
				fontWeight: "{fonts.fontWeight.regular}",
				background: "transparent",
				color: "{color.fg.muted}"
			}
		},
		colorScheme: {
			light: {
				root: {
					background: "transparent"
				}
			},
			dark: {
				root: {
					background: "transparent"
				}
			}
		},
		root: {
			borderColor: "transparent",
			borderRadius: "{dimension.borderRadius.200}",
			color: "{color.fg.default}",
			gap: "{dimension.space.100}",
			padding: "{dimension.space.100}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		baseItem: {
			borderRadius: "{dimension.borderRadius.200}",
			padding: "{dimension.space.200} {dimension.space.400}"
		},
		item: {
			focusBackground: "{color.bg.neutral.weak.default}",
			activeBackground: "{color.bg.neutral.strong.default}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			activeColor: "{color.fg.inverse.active}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}",
			gap: "{dimension.space.200}",
			icon: {
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}",
				activeColor: "{color.fg.inverse.active}"
			}
		},
		submenu: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}",
			background: "{color.bg.surface.raised.default}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.400}",
			shadow: "{effects.elevation.400}",
			mobileIndent: "{dimension.space.400}",
			icon: {
				size: "{dimension.size.600}",
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}",
				activeColor: "{color.fg.inverse.active}"
			}
		},
		separator: {
			borderColor: "{color.border.neutral.default}"
		},
		mobileButton: {
			borderRadius: "{dimension.borderRadius.200}",
			size: "{dimension.size.900}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			hoverBackground: "{color.bg.neutral.weak.default}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		}
	},
	message: {
		extend: {
			width: "{dimension.size.2000}",
			overlayWidth: {
				small: "{dimension.size.1700}",
				base: "{dimension.size.1900}",
				large: "{dimension.size.2000}",
				xlarge: "{dimension.size.2200}"
			},
			extText: {
				gap: "{dimension.space.100}"
			},
			extInfo: {
				color: "{color.fg.status.info.default}",
				closeButton: {
					color: "{color.fg.status.info.default}",
					borderColor: "{color.border.status.info.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			},
			extAccentLine: {
				width: "{dimension.size.100}"
			},
			extCloseButton: {
				width: "{dimension.borderWidth.100}"
			},
			extSuccess: {
				color: "{color.fg.status.success.default}",
				closeButton: {
					color: "{color.fg.status.success.default}",
					borderColor: "{color.border.brand.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			},
			extWarn: {
				color: "{color.fg.status.warning.default}",
				closeButton: {
					color: "{color.fg.status.warning.default}",
					borderColor: "{color.border.status.warning.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			},
			extError: {
				color: "{color.fg.status.danger.default}",
				closeButton: {
					color: "{color.fg.status.danger.default}",
					borderColor: "{color.border.status.danger.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			}
		},
		colorScheme: {
			light: {
				success: {
					background: "{color.bg.status.success.weak.default}",
					borderColor: "{color.border.brand.default}",
					color: "{color.fg.default}",
					shadow: "none",
					outlined: {
						color: "{color.fg.default}",
						borderColor: "{color.border.brand.default}"
					},
					closeButton: {
						hoverBackground: "{color.bg.status.success.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					simple: {
						color: "{color.fg.default}"
					}
				},
				outlined: {
					root: {
						borderWidth: "{dimension.borderWidth.none}"
					},
					closeButton: {
						hoverBackground: "transparent",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					outlined: {
						color: "transparent",
						borderColor: "transparent"
					},
					simple: {
						color: "transparent"
					}
				},
				simple: {
					content: {
						padding: "{dimension.space.none}"
					}
				},
				warn: {
					background: "{color.bg.status.warning.weak.default}",
					borderColor: "{color.border.status.warning.default}",
					color: "{color.fg.default}",
					shadow: "none",
					outlined: {
						color: "{color.fg.default}",
						borderColor: "{color.border.status.warning.default}"
					},
					closeButton: {
						hoverBackground: "{color.bg.status.warning.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					simple: {
						color: "{color.fg.default}"
					}
				},
				error: {
					background: "{color.bg.status.danger.weak.default}",
					borderColor: "{color.border.status.danger.default}",
					color: "{color.fg.default}",
					shadow: "none",
					outlined: {
						color: "{color.fg.default}",
						borderColor: "{color.border.status.danger.default}"
					},
					closeButton: {
						hoverBackground: "{color.bg.status.danger.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					simple: {
						color: "{color.fg.default}"
					}
				},
				secondary: {
					borderColor: "transparent",
					shadow: "none",
					closeButton: {
						hoverBackground: "transparent",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					simple: {
						color: "transparent"
					},
					outlined: {
						color: "transparent",
						borderColor: "transparent"
					},
					background: "{color.bg.neutral.weak.default}",
					color: "{color.fg.default}"
				},
				contrast: {
					borderColor: "transparent",
					shadow: "none",
					closeButton: {
						hoverBackground: "transparent",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					simple: {
						color: "transparent"
					},
					outlined: {
						color: "transparent",
						borderColor: "transparent"
					},
					background: "{color.bg.neutral.strong.default}",
					color: "{color.fg.on.fill.default}"
				},
				info: {
					background: "{color.bg.status.info.weak.default}",
					borderColor: "{color.border.status.info.default}",
					color: "{color.fg.default}",
					shadow: "none",
					closeButton: {
						hoverBackground: "{color.bg.status.info.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					outlined: {
						color: "{color.fg.default}",
						borderColor: "{color.border.status.info.default}"
					},
					simple: {
						color: "{color.fg.default}"
					}
				}
			},
			dark: {
				contrast: {
					background: "{color.bg.surface.canvas.default}",
					borderColor: "transparent",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "transparent"
					},
					color: "{color.fg.default}",
					outlined: {
						borderColor: "transparent",
						color: "transparent"
					},
					shadow: "none",
					simple: {
						color: "transparent"
					}
				},
				error: {
					background: "{color.bg.status.danger.weak.default}",
					borderColor: "{color.border.status.danger.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.danger.weak.active}"
					},
					color: "{color.fg.default}",
					outlined: {
						borderColor: "{color.border.status.danger.default}",
						color: "{color.fg.inverse.default}"
					},
					shadow: "none",
					simple: {
						color: "{color.fg.inverse.default}"
					}
				},
				info: {
					background: "{color.bg.status.info.weak.default}",
					borderColor: "{color.border.status.info.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.info.weak.active}"
					},
					color: "{color.fg.default}",
					outlined: {
						borderColor: "{color.border.status.info.default}",
						color: "{color.fg.inverse.default}"
					},
					shadow: "none",
					simple: {
						color: "{color.fg.inverse.default}"
					}
				},
				secondary: {
					background: "{color.bg.neutral.strong.default}",
					borderColor: "transparent",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "transparent"
					},
					color: "{color.fg.inverse.default}",
					outlined: {
						borderColor: "transparent",
						color: "transparent"
					},
					shadow: "none",
					simple: {
						color: "transparent"
					}
				},
				success: {
					background: "{color.bg.status.success.weak.default}",
					borderColor: "{color.border.brand.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.success.weak.active}"
					},
					color: "{color.fg.default}",
					outlined: {
						borderColor: "{color.border.brand.default}",
						color: "{color.fg.inverse.default}"
					},
					shadow: "none",
					simple: {
						color: "{color.fg.inverse.default}"
					}
				},
				warn: {
					background: "{color.bg.status.warning.weak.default}",
					borderColor: "{color.border.status.warning.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.warning.weak.active}"
					},
					color: "{color.fg.default}",
					outlined: {
						borderColor: "{color.border.status.warning.default}",
						color: "{color.fg.inverse.default}"
					},
					shadow: "none",
					simple: {
						color: "{color.fg.inverse.default}"
					}
				},
				outlined: {
					root: {
						borderWidth: "{dimension.borderWidth.none}"
					},
					closeButton: {
						hoverBackground: "transparent",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					},
					outlined: {
						color: "transparent",
						borderColor: "transparent"
					},
					simple: {
						color: "transparent"
					}
				},
				simple: {
					content: {
						padding: "{dimension.space.none}"
					}
				}
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.400}",
			borderWidth: "{dimension.borderWidth.100}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		content: {
			padding: "{dimension.space.400}",
			gap: "{dimension.space.400}",
			sm: {
				padding: "{dimension.space.400}"
			},
			lg: {
				padding: "{dimension.space.400}"
			}
		},
		text: {
			fontSize: "{fonts.fontSize.300}",
			fontWeight: "{fonts.fontWeight.bold}",
			sm: {
				fontSize: "{fonts.fontSize.300}"
			},
			lg: {
				fontSize: "{fonts.fontSize.300}"
			}
		},
		icon: {
			size: "{dimension.size.1000}",
			sm: {
				size: "{dimension.size.1000}"
			},
			lg: {
				size: "{dimension.size.1000}"
			}
		},
		closeButton: {
			width: "{dimension.size.900}",
			height: "{dimension.size.900}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				offset: "{dimension.focusRing.offset}"
			}
		},
		closeIcon: {
			size: "{dimension.size.450}",
			sm: {
				size: "{dimension.size.450}"
			},
			lg: {
				size: "{dimension.size.450}"
			}
		},
		outlined: {
			root: {
				borderWidth: "{dimension.borderWidth.100}"
			}
		},
		simple: {
			content: {
				padding: "{dimension.space.none}"
			}
		}
	},
	metergroup: {
		extend: {
			extLabel: {
				color: "{color.fg.muted}"
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.400}",
			gap: "{dimension.space.400}"
		},
		meters: {
			size: "{dimension.size.200}",
			background: "{color.bg.neutral.medium.default}"
		},
		label: {
			gap: "{dimension.space.100}"
		},
		labelMarker: {
			size: "{dimension.size.200}"
		},
		labelIcon: {
			size: "{dimension.size.450}"
		},
		labelList: {
			verticalGap: "{dimension.space.200}",
			horizontalGap: "{dimension.space.400}"
		}
	},
	multiselect: {
		extend: {
			paddingX: "{dimension.space.150}",
			paddingY: "{dimension.space.150}",
			borderWidth: "{dimension.borderWidth.100}",
			iconSize: "{dimension.size.450}",
			width: "{dimension.size.1700}",
			readonlyBackground: "{color.bg.neutral.weak.default}"
		},
		root: {
			shadow: "{effects.elevation.none}",
			paddingX: "{dimension.space.400}",
			paddingY: "{dimension.space.400}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}",
			sm: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.200}",
				paddingY: "{dimension.space.200}"
			},
			lg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.400}",
				paddingY: "{dimension.space.400}"
			},
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				color: "{color.border.focus}"
			},
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			color: "{color.fg.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			disabledColor: "{color.fg.muted}",
			filledBackground: "{color.bg.surface.default.default}",
			filledFocusBackground: "{color.bg.surface.default.default}",
			filledHoverBackground: "{color.bg.surface.default.default}",
			focusBorderColor: "{color.border.brand.strong}",
			hoverBorderColor: "{color.border.brand.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			invalidPlaceholderColor: "{color.fg.status.danger.hover}",
			placeholderColor: "{color.fg.muted}"
		},
		dropdown: {
			width: "{dimension.size.1700}",
			color: "{color.fg.active}"
		},
		overlay: {
			borderRadius: "{dimension.borderRadius.400}",
			shadow: "{effects.elevation.400}",
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}"
		},
		list: {
			padding: "{dimension.space.100}",
			header: {
				padding: "{dimension.space.400} {dimension.space.400} {dimension.space.none} {dimension.space.400}"
			},
			gap: "{dimension.space.100}"
		},
		chip: {
			borderRadius: "{dimension.borderRadius.200}"
		},
		option: {
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}",
			gap: "{dimension.space.200}",
			color: "{color.fg.default}",
			focusBackground: "{color.bg.neutral.weak.default}",
			focusColor: "{color.fg.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			selectedColor: "{color.fg.on.fill.default}",
			selectedFocusBackground: "{color.bg.neutral.strong.active}",
			selectedFocusColor: "{color.fg.on.fill.active}"
		},
		optionGroup: {
			fontWeight: "{fonts.fontWeight.demibold}",
			padding: "{dimension.space.200} {dimension.space.400}",
			background: "{color.bg.surface.raised.default}",
			color: "{color.fg.muted}"
		},
		emptyMessage: {
			padding: "{dimension.space.200} {dimension.space.400}"
		},
		clearIcon: {
			color: "{color.fg.active}"
		}
	},
	paginator: {
		root: {
			padding: "{dimension.space.none} {dimension.space.200}",
			gap: "{dimension.space.200}",
			borderRadius: "{dimension.borderRadius.400}",
			background: "transparent",
			color: "{color.fg.default}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		currentPageReport: {
			color: "{color.fg.muted}"
		},
		navButton: {
			background: "transparent",
			hoverBackground: "{color.bg.neutral.weak.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			selectedColor: "{color.fg.on.fill.default}",
			width: "{dimension.size.1100}",
			height: "{dimension.size.1100}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				focus: "{effects.elevation.200}",
				shadow: "{effects.elevation.none}"
			}
		},
		jumpToPageInput: {
			maxWidth: "{dimension.size.1500}"
		}
	},
	panelmenu: {
		extend: {
			iconSize: "{dimension.size.600}",
			extPanel: {
				gap: "{dimension.space.100}"
			},
			extItem: {
				activeBackground: "{color.bg.neutral.strong.default}",
				activeColor: "{color.fg.inverse.active}",
				caption: {
					color: "{color.fg.muted}",
					gap: "{dimension.space.100}"
				}
			}
		},
		root: {
			gap: "{dimension.space.100}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		panel: {
			background: "transparent",
			borderColor: "transparent",
			borderWidth: "{dimension.borderWidth.100}",
			color: "{color.fg.default}",
			padding: "{dimension.space.100}",
			borderRadius: "{dimension.borderRadius.400}",
			first: {
				borderWidth: "{dimension.borderWidth.100} {dimension.borderWidth.100} {dimension.borderWidth.none} {dimension.borderWidth.100}",
				topBorderRadius: "{dimension.borderRadius.400}"
			},
			last: {
				borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.100} {dimension.borderWidth.100}",
				topBorderRadius: "{dimension.borderRadius.400}",
				bottomBorderRadius: "{dimension.borderRadius.400}"
			}
		},
		item: {
			focusBackground: "{color.bg.neutral.weak.default}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			gap: "{dimension.space.200}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}",
			icon: {
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}"
			}
		},
		submenu: {
			indent: "{dimension.space.700}"
		},
		separator: {
			borderColor: "{color.border.neutral.default}"
		},
		submenuIcon: {
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}"
		}
	},
	password: {
		extend: {
			borderWidth: "{dimension.borderWidth.100}"
		},
		colorScheme: {
			light: {
				strength: {
					weakBackground: "{color.bg.status.danger.strong.active}",
					mediumBackground: "{color.bg.status.warning.strong.active}",
					strongBackground: "{color.bg.brand.strong.hover}"
				},
				icon: {
					color: "{color.fg.muted}"
				}
			},
			dark: {
				strength: {
					mediumBackground: "{color.bg.status.warning.strong.active}",
					strongBackground: "{color.bg.status.success.strong.hover}",
					weakBackground: "{color.bg.status.danger.strong.active}"
				},
				icon: {
					color: "{color.fg.inverse.muted}"
				}
			}
		},
		meter: {
			background: "{color.bg.neutral.medium.default}",
			borderRadius: "{dimension.borderRadius.400}",
			height: "{dimension.size.200}"
		},
		overlay: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			borderRadius: "{dimension.borderRadius.200}",
			color: "{color.fg.default}",
			padding: "{dimension.space.400}",
			shadow: "{effects.elevation.400}"
		},
		content: {
			gap: "{dimension.space.200}"
		},
		icon: {
			color: "{color.fg.default}"
		}
	},
	popover: {
		extend: {
			borderWidth: "{dimension.borderWidth.100}",
			arrow: {
				width: "{dimension.size.350}",
				height: "{dimension.size.200}"
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			color: "{color.fg.default}",
			borderRadius: "{dimension.borderRadius.200}",
			shadow: "{effects.elevation.400}",
			gutter: "{dimension.space.100}",
			arrowOffset: "{dimension.space.600}"
		},
		content: {
			padding: "{dimension.space.400}"
		}
	},
	progressbar: {
		label: {
			color: "{color.fg.default}",
			fontSize: "{fonts.fontSize.100}",
			fontWeight: "{fonts.fontWeight.regular}"
		},
		root: {
			background: "{color.bg.surface.canvas.hover}",
			borderRadius: "{dimension.borderRadius.400}",
			height: "{dimension.size.450}"
		},
		value: {
			background: "{color.bg.brand.strong.default}"
		}
	},
	progressspinner: {
		extend: {
			small: "{dimension.size.450}",
			medium: "{dimension.size.900}",
			large: "{dimension.size.1200}",
			xlarge: "{dimension.size.1300}"
		},
		colorScheme: {
			light: {
				root: {
					colorOne: "{color.fg.brand.default}",
					colorTwo: "{color.fg.status.info.default}",
					colorThree: "{color.fg.status.danger.default}",
					colorFour: "{color.fg.status.warning.default}"
				}
			},
			dark: {
				root: {
					colorFour: "{color.fg.status.warning.muted}",
					colorOne: "{color.fg.brand.muted}",
					colorThree: "{color.fg.status.danger.muted}",
					colorTwo: "{color.fg.status.info.muted}"
				}
			}
		},
		root: {
			borderWidth: "{dimension.borderWidth.300}"
		}
	},
	radiobutton: {
		root: {
			width: "{dimension.size.700}",
			height: "{dimension.size.700}",
			background: "{color.bg.surface.default.default}",
			checkedBackground: "{color.bg.neutral.strong.default}",
			checkedHoverBackground: "{color.bg.neutral.strong.hover}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			filledBackground: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.neutral.bold.default}",
			focusBorderColor: "{color.border.neutral.strong}",
			checkedBorderColor: "{color.border.neutral.bold.default}",
			checkedHoverBorderColor: "{color.border.neutral.bold.default}",
			checkedFocusBorderColor: "{color.border.neutral.bold.default}",
			checkedDisabledBorderColor: "{color.border.neutral.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			shadow: "{effects.elevation.none}",
			transitionDuration: "{effects.transition.duration.200}",
			focusRing: {
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				style: "none",
				width: "{dimension.focusRing.width}"
			},
			lg: {
				height: "{dimension.size.600}",
				width: "{dimension.size.600}"
			},
			sm: {
				height: "{dimension.size.200}",
				width: "{dimension.size.200}"
			}
		},
		focusRing: {
			width: "{dimension.focusRing.width}",
			style: "none",
			color: "{color.border.focus}",
			offset: "{dimension.focusRing.offset}",
			shadow: "{effects.elevation.200}"
		},
		sm: {
			width: "{dimension.size.450}",
			height: "{dimension.size.450}"
		},
		lg: {
			width: "{dimension.size.600}",
			height: "{dimension.size.600}"
		},
		icon: {
			size: "{dimension.size.350}",
			checkedColor: "{color.fg.on.fill.default}",
			checkedHoverColor: "{color.fg.on.fill.hover}",
			disabledColor: "{color.fg.muted}",
			sm: {
				size: "{dimension.size.200}"
			},
			lg: {
				size: "{dimension.size.450}"
			}
		}
	},
	rating: {
		root: {
			gap: "{dimension.space.200}",
			transitionDuration: "{effects.transition.duration.200}",
			focusRing: {
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				style: "none",
				width: "{dimension.focusRing.width}"
			}
		},
		focusRing: {
			width: "{dimension.focusRing.width}",
			style: "none",
			color: "{color.border.focus}",
			offset: "{dimension.focusRing.offset}",
			shadow: "{effects.elevation.200}"
		},
		icon: {
			size: "{dimension.size.700}",
			color: "{color.fg.muted}",
			hoverColor: "{color.fg.status.warning.default}",
			activeColor: "{color.fg.status.warning.default}"
		}
	},
	ripple: {
		colorScheme: {
			light: {
				root: {
					background: "{color.bg.neutral.medium.default}"
				}
			},
			dark: {
				root: {
					background: "{color.bg.neutral.medium.default}"
				}
			}
		}
	},
	scrollpanel: {
		colorScheme: {
			light: {
				bar: {
					background: "{color.bg.neutral.weak.active}"
				}
			},
			dark: {
				bar: {
					background: "{color.bg.neutral.strong.active}"
				}
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		bar: {
			size: "{dimension.size.200}",
			borderRadius: "{dimension.borderRadius.200}",
			focusRing: {
				width: "{dimension.size.none}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		}
	},
	select: {
		extend: {
			extOption: {
				background: "{color.bg.surface.raised.default}",
				gap: "{dimension.space.200}"
			},
			extOptionGroup: {
				gap: "{dimension.space.200}"
			},
			readonlyBackground: "{color.bg.neutral.weak.default}",
			borderWidth: "{dimension.borderWidth.100}",
			iconSize: "{dimension.size.450}",
			extXlg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.600}"
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			filledBackground: "{color.bg.surface.default.default}",
			filledHoverBackground: "{color.bg.surface.default.default}",
			filledFocusBackground: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.brand.strong}",
			focusBorderColor: "{color.border.brand.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			color: "{color.fg.default}",
			disabledColor: "{color.fg.muted}",
			placeholderColor: "{color.fg.muted}",
			invalidPlaceholderColor: "{color.fg.status.danger.hover}",
			shadow: "{effects.elevation.none}",
			paddingX: "{dimension.space.400}",
			paddingY: "{dimension.space.400}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}",
			sm: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.400}",
				paddingY: "{dimension.space.400}"
			},
			lg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.400}",
				paddingY: "{dimension.space.400}"
			},
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}"
			}
		},
		dropdown: {
			width: "{dimension.size.1700}",
			color: "{color.fg.active}"
		},
		overlay: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			borderRadius: "{dimension.borderRadius.400}",
			color: "{color.fg.default}",
			shadow: "{effects.elevation.400}"
		},
		list: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}",
			header: {
				padding: "{dimension.space.400} {dimension.space.400} {dimension.space.none} {dimension.space.400}"
			}
		},
		option: {
			focusBackground: "{color.bg.neutral.weak.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}",
			selectedFocusBackground: "{color.bg.neutral.strong.active}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			selectedColor: "{color.fg.on.fill.default}",
			selectedFocusColor: "{color.fg.on.fill.active}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}"
		},
		optionGroup: {
			background: "{color.bg.surface.raised.default}",
			color: "{color.fg.muted}",
			fontWeight: "{fonts.fontWeight.demibold}",
			padding: "{dimension.space.200} {dimension.space.400}"
		},
		clearIcon: {
			color: "{color.fg.active}"
		},
		checkmark: {
			color: "{color.fg.default}",
			gutterStart: "{dimension.space.negative.200}",
			gutterEnd: "{dimension.space.200}"
		},
		emptyMessage: {
			padding: "{dimension.space.200} {dimension.space.400}"
		}
	},
	selectbutton: {
		extend: {
			gap: "{dimension.space.100}",
			paddingX: "{dimension.space.100}",
			paddingY: "{dimension.space.100}",
			iconSize: {
				sm: "{dimension.size.450}",
				md: "{dimension.size.600}",
				lg: "{dimension.size.700}",
				xlg: "{dimension.size.800}"
			},
			checkedBackground: "{color.bg.surface.raised.default}",
			checkedBorderColor: "{color.border.neutral.inverse}",
			checkedColor: "{color.fg.active}",
			ext: {
				borderRadius: "{dimension.borderRadius.200}"
			}
		},
		colorScheme: {
			light: {
				root: {
					invalidBorderColor: "{color.border.status.danger.subtle}"
				},
				extend: {
					background: "{color.bg.neutral.medium.default}"
				}
			},
			dark: {
				root: {
					invalidBorderColor: "{color.border.status.danger.strong}"
				},
				extend: {
					background: "{color.bg.neutral.strong.hover}"
				}
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.350}"
		}
	},
	skeleton: {
		extend: {
			minWidth: "{dimension.size.900}",
			height: "{dimension.size.900}"
		},
		colorScheme: {
			light: {
				root: {
					background: "{color.bg.surface.canvas.hover}",
					animationBackground: "{color.bg.surface.canvas.default}"
				}
			},
			dark: {
				root: {
					background: "{color.bg.surface.raised.default}",
					animationBackground: "{color.bg.surface.raised.selected}"
				}
			}
		},
		root: {
			borderRadius: "{dimension.borderRadius.400}"
		}
	},
	slider: {
		colorScheme: {
			light: {
				handle: {
					content: {
						background: "{color.bg.surface.default.default}"
					}
				}
			},
			dark: {
				handle: {
					content: {
						background: "{color.bg.surface.canvas.default}"
					}
				}
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		track: {
			background: "{color.bg.neutral.medium.default}",
			borderRadius: "{dimension.borderRadius.350}",
			size: "{dimension.size.100}"
		},
		range: {
			background: "{color.bg.neutral.strong.default}"
		},
		handle: {
			width: "{dimension.size.600}",
			height: "{dimension.size.600}",
			borderRadius: "{dimension.borderRadius.max}",
			background: "{color.bg.neutral.strong.default}",
			hoverBackground: "{color.bg.neutral.strong.default}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			},
			content: {
				borderRadius: "{dimension.borderRadius.max}",
				hoverBackground: "{color.bg.neutral.strong.default}",
				width: "{dimension.size.350}",
				height: "{dimension.size.350}",
				shadow: "none"
			},
			extend: {
				hoverRing: "0 0 0 {dimension.focusRing.width} rgba(206, 207, 210, 0.5000)"
			}
		}
	},
	splitter: {
		colorScheme: {
			light: {
				handle: {
					background: "{color.bg.neutral.strong.default}"
				}
			},
			dark: {
				handle: {
					background: "{color.bg.surface.canvas.default}"
				}
			}
		},
		gutter: {
			background: "{color.bg.neutral.weak.default}"
		},
		root: {
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		handle: {
			size: "{dimension.size.100}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		}
	},
	stepper: {
		extend: {
			extCaption: {
				gap: "{dimension.space.100}"
			},
			extStepNumber: {
				invalidBackground: "{color.bg.status.danger.strong.hover}",
				invalidColor: "{color.fg.on.status.danger.default}",
				invalidBorderColor: "{color.border.status.danger.subtle}",
				borderWidth: "{dimension.borderWidth.100}",
				iconSize: "{dimension.size.700}"
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		separator: {
			background: "{color.bg.neutral.medium.default}",
			activeBackground: "{color.bg.neutral.strong.default}",
			margin: "{dimension.space.none} {dimension.space.none} {dimension.space.none} {dimension.space.700}",
			size: "{dimension.borderWidth.100}"
		},
		step: {
			padding: "{dimension.space.200}",
			gap: "{dimension.space.200}"
		},
		stepHeader: {
			padding: "{dimension.space.none}",
			borderRadius: "{dimension.borderRadius.none}",
			gap: "{dimension.space.200}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		stepTitle: {
			color: "{color.fg.default}",
			activeColor: "{color.fg.default}",
			fontWeight: "{fonts.fontWeight.regular}"
		},
		stepNumber: {
			background: "{color.bg.surface.raised.default}",
			activeBackground: "{color.bg.brand.strong.default}",
			borderColor: "{color.border.neutral.default}",
			activeBorderColor: "{color.border.brand.default}",
			color: "{color.fg.default}",
			activeColor: "{color.fg.default}",
			size: "{dimension.size.700}",
			fontSize: "{fonts.fontSize.300}",
			fontWeight: "{fonts.fontWeight.regular}",
			borderRadius: "{dimension.borderRadius.max}",
			shadow: "none"
		},
		steppanels: {
			padding: "{dimension.space.400}"
		},
		steppanel: {
			background: "{color.bg.surface.raised.default}",
			color: "{color.fg.default}",
			padding: "{dimension.space.none}",
			indent: "{dimension.space.none}"
		}
	},
	steps: {
		itemLink: {
			gap: "{dimension.space.200}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				style: "none",
				width: "{dimension.focusRing.width}"
			}
		},
		itemLabel: {
			fontWeight: "{fonts.fontWeight.regular}",
			activeColor: "{color.fg.hover}",
			color: "{color.fg.default}"
		},
		itemNumber: {
			background: "{color.bg.surface.raised.default}",
			size: "{dimension.size.900}",
			fontSize: "{fonts.fontSize.300}",
			fontWeight: "{fonts.fontWeight.bold}",
			borderRadius: "{dimension.borderRadius.max}",
			shadow: "none",
			activeBackground: "{color.bg.surface.raised.default}",
			activeBorderColor: "{color.border.neutral.default}",
			activeColor: "{color.fg.hover}",
			borderColor: "{color.border.neutral.default}",
			color: "{color.fg.default}"
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		separator: {
			background: "{color.bg.neutral.medium.default}"
		}
	},
	tabs: {
		colorScheme: {
			light: {
				navButton: {
					shadow: "none"
				},
				tab: {
					background: "transparent",
					hoverBackground: "transparent",
					activeBackground: "transparent"
				}
			},
			dark: {
				navButton: {
					shadow: "none"
				},
				tab: {
					activeBackground: "transparent",
					background: "transparent",
					hoverBackground: "transparent"
				}
			}
		},
		root: {
			transitionDuration: "{effects.transition.duration.200}"
		},
		tablist: {
			borderWidth: "{dimension.borderWidth.none} {dimension.borderWidth.none} {dimension.borderWidth.100} {dimension.borderWidth.none}",
			background: "transparent",
			borderColor: "{color.border.neutral.default}"
		},
		tab: {
			borderWidth: "{dimension.borderWidth.none}",
			borderColor: "{color.border.neutral.default}",
			hoverBorderColor: "{color.border.neutral.default}",
			activeBorderColor: "{color.border.neutral.bold.hover}",
			color: "{color.fg.muted}",
			hoverColor: "{color.fg.default}",
			activeColor: "{color.fg.default}",
			padding: "{dimension.space.400}",
			fontWeight: "{fonts.fontWeight.demibold}",
			margin: "{dimension.space.none}",
			gap: "{dimension.space.200}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		tabpanel: {
			background: "transparent",
			color: "{color.fg.default}",
			padding: "{dimension.space.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		navButton: {
			background: "{color.bg.surface.raised.default}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}",
			width: "{dimension.size.700}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			}
		},
		activeBar: {
			height: "{dimension.size.50}",
			bottom: "{dimension.space.negative.50}",
			background: "{color.bg.neutral.strong.default}"
		}
	},
	toast: {
		extend: {
			extInfo: {
				color: "{color.fg.status.info.default}",
				closeButton: {
					color: "{color.fg.status.info.default}",
					borderColor: "{color.border.status.info.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			},
			extAccentLine: {
				width: "{dimension.size.100}"
			},
			extCloseButton: {
				width: "{dimension.borderWidth.100}"
			},
			extSuccess: {
				color: "{color.fg.status.success.default}",
				closeButton: {
					color: "{color.fg.status.success.default}",
					borderColor: "{color.border.brand.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			},
			extWarn: {
				color: "{color.fg.status.warning.default}",
				closeButton: {
					color: "{color.fg.status.warning.default}",
					borderColor: "{color.border.status.warning.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			},
			extError: {
				color: "{color.fg.status.danger.default}",
				closeButton: {
					color: "{color.fg.status.danger.default}",
					borderColor: "{color.border.status.danger.default}"
				},
				caption: {
					color: "{color.fg.default}"
				}
			}
		},
		colorScheme: {
			light: {
				info: {
					background: "{color.bg.status.info.weak.default}",
					borderColor: "{color.border.status.info.default}",
					color: "{color.fg.default}",
					detailColor: "{color.fg.default}",
					shadow: "{effects.elevation.400}",
					closeButton: {
						hoverBackground: "{color.bg.status.info.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					}
				},
				success: {
					background: "{color.bg.status.success.weak.default}",
					borderColor: "{color.border.brand.default}",
					color: "{color.fg.default}",
					detailColor: "{color.fg.default}",
					shadow: "{effects.elevation.400}",
					closeButton: {
						hoverBackground: "{color.bg.status.success.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					}
				},
				warn: {
					background: "{color.bg.status.warning.weak.default}",
					borderColor: "{color.border.status.warning.default}",
					color: "{color.fg.default}",
					detailColor: "{color.fg.default}",
					shadow: "{effects.elevation.400}",
					closeButton: {
						hoverBackground: "{color.bg.status.warning.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "none"
						}
					}
				},
				error: {
					background: "{color.bg.status.danger.weak.default}",
					borderColor: "{color.border.status.danger.default}",
					color: "{color.fg.default}",
					detailColor: "{color.fg.default}",
					shadow: "{effects.elevation.400}",
					closeButton: {
						hoverBackground: "{color.bg.status.danger.weak.active}",
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						}
					}
				},
				secondary: {
					shadow: "{effects.elevation.400}",
					background: "{color.bg.neutral.weak.default}",
					borderColor: "{color.border.neutral.strong}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.neutral.weak.default}"
					},
					color: "{color.fg.default}",
					detailColor: "{color.fg.subtle}"
				},
				contrast: {
					shadow: "{effects.elevation.400}",
					background: "{color.bg.neutral.strong.default}",
					borderColor: "{color.border.neutral.bold.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.neutral.strong.hover}"
					},
					color: "{color.fg.on.fill.default}",
					detailColor: "{color.fg.on.fill.muted}"
				},
				root: {
					blur: "{effects.blur.none}"
				}
			},
			dark: {
				contrast: {
					background: "{color.bg.surface.canvas.default}",
					borderColor: "{color.border.neutral.inverse}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.surface.canvas.hover}"
					},
					color: "{color.fg.default}",
					detailColor: "{color.fg.on.fill.muted}",
					shadow: "{effects.elevation.400}"
				},
				error: {
					background: "{color.bg.status.danger.weak.default}",
					borderColor: "{color.border.status.danger.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.danger.weak.active}"
					},
					color: "{color.fg.inverse.default}",
					detailColor: "{color.fg.inverse.default}",
					shadow: "{effects.elevation.400}"
				},
				info: {
					background: "{color.bg.status.info.weak.default}",
					borderColor: "{color.border.status.info.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.info.weak.active}"
					},
					color: "{color.fg.inverse.default}",
					detailColor: "{color.fg.inverse.default}",
					shadow: "{effects.elevation.400}"
				},
				root: {
					blur: "{effects.blur.none}"
				},
				secondary: {
					background: "{color.bg.neutral.strong.default}",
					borderColor: "{color.border.neutral.strong}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.none}"
						},
						hoverBackground: "{color.bg.neutral.strong.selected}"
					},
					color: "{color.fg.inverse.default}",
					detailColor: "{color.fg.subtle}",
					shadow: "{effects.elevation.400}"
				},
				success: {
					background: "{color.bg.status.success.weak.default}",
					borderColor: "{color.border.brand.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "{effects.elevation.200}"
						},
						hoverBackground: "{color.bg.status.success.weak.active}"
					},
					color: "{color.fg.inverse.default}",
					detailColor: "{color.fg.inverse.default}",
					shadow: "{effects.elevation.400}"
				},
				warn: {
					background: "{color.bg.status.warning.weak.default}",
					borderColor: "{color.border.status.warning.default}",
					closeButton: {
						focusRing: {
							color: "{color.border.focus}",
							shadow: "none"
						},
						hoverBackground: "{color.bg.status.warning.weak.active}"
					},
					color: "{color.fg.inverse.default}",
					detailColor: "{color.fg.inverse.default}",
					shadow: "{effects.elevation.400}"
				}
			}
		},
		root: {
			width: "{dimension.size.2000}",
			borderWidth: "{dimension.borderWidth.100}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		icon: {
			size: "{dimension.size.1000}"
		},
		content: {
			padding: "{dimension.space.400}",
			gap: "{dimension.space.400}"
		},
		text: {
			gap: "{dimension.space.100}"
		},
		summary: {
			fontWeight: "{fonts.fontWeight.bold}",
			fontSize: "{fonts.fontSize.300}"
		},
		detail: {
			fontWeight: "{fonts.fontWeight.regular}",
			fontSize: "{fonts.fontSize.200}"
		},
		closeButton: {
			width: "{dimension.size.900}",
			height: "{dimension.size.900}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				offset: "{dimension.focusRing.offset}"
			}
		},
		closeIcon: {
			size: "{dimension.size.450}"
		}
	},
	tag: {
		colorScheme: {
			light: {
				primary: {
					background: "{color.bg.brand.strong.default}",
					color: "{color.fg.default}"
				},
				secondary: {
					background: "{color.bg.neutral.medium.default}",
					color: "{color.fg.default}"
				},
				success: {
					background: "{color.bg.status.success.strong.hover}",
					color: "{color.fg.on.status.success.default}"
				},
				info: {
					background: "{color.bg.status.info.strong.default}",
					color: "{color.fg.on.status.info.default}"
				},
				warn: {
					background: "{color.bg.status.warning.strong.default}",
					color: "{color.fg.on.status.warning.default}"
				},
				danger: {
					background: "{color.bg.status.danger.strong.default}",
					color: "{color.fg.on.status.danger.default}"
				},
				contrast: {
					background: "{color.bg.neutral.strong.default}",
					color: "{color.fg.on.fill.default}"
				}
			},
			dark: {
				contrast: {
					background: "{color.bg.surface.canvas.default}",
					color: "{color.fg.default}"
				},
				danger: {
					background: "{color.bg.status.danger.strong.default}",
					color: "{color.fg.on.status.danger.default}"
				},
				info: {
					background: "{color.bg.status.info.strong.default}",
					color: "{color.fg.on.status.info.default}"
				},
				primary: {
					background: "{color.bg.brand.strong.default}",
					color: "{color.fg.inverse.default}"
				},
				secondary: {
					background: "{color.bg.neutral.strong.hover}",
					color: "{color.fg.inverse.default}"
				},
				success: {
					background: "{color.bg.brand.strong.hover}",
					color: "{color.fg.on.status.success.default}"
				},
				warn: {
					background: "{color.bg.status.warning.strong.default}",
					color: "{color.fg.on.status.warning.default}"
				}
			}
		},
		root: {
			fontSize: "{fonts.fontSize.100}",
			fontWeight: "{fonts.fontWeight.regular}",
			padding: "{dimension.space.100} {dimension.space.200}",
			gap: "{dimension.space.100}",
			borderRadius: "{dimension.borderRadius.200}",
			roundedBorderRadius: "{dimension.borderRadius.max}"
		},
		icon: {
			size: "{dimension.size.450}"
		}
	},
	textarea: {
		extend: {
			readonlyBackground: "{color.bg.neutral.weak.default}",
			borderWidth: "{dimension.borderWidth.100}",
			iconSize: "{dimension.size.450}",
			minHeight: "{dimension.size.1500}",
			extXlg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.500}"
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			filledBackground: "{color.bg.surface.default.default}",
			filledHoverBackground: "{color.bg.surface.default.default}",
			filledFocusBackground: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.strong}",
			hoverBorderColor: "{color.border.brand.strong}",
			focusBorderColor: "{color.border.brand.strong}",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			color: "{color.fg.active}",
			disabledColor: "{color.fg.muted}",
			placeholderColor: "{color.fg.muted}",
			invalidPlaceholderColor: "{color.fg.status.danger.hover}",
			shadow: "{effects.elevation.none}",
			paddingX: "{dimension.space.300}",
			paddingY: "{dimension.space.300}",
			borderRadius: "{dimension.borderRadius.400}",
			transitionDuration: "{effects.transition.duration.200}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}"
			},
			lg: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.400}"
			},
			sm: {
				fontSize: "{fonts.fontSize.300}",
				paddingX: "{dimension.space.300}",
				paddingY: "{dimension.space.200}"
			}
		}
	},
	tieredmenu: {
		extend: {
			iconSize: "{dimension.size.600}",
			extSubmenu: {
				borderColor: "{color.border.neutral.default}",
				background: "{color.bg.surface.raised.default}"
			},
			extItem: {
				caption: {
					gap: "{dimension.space.100}",
					color: "{color.fg.muted}"
				}
			}
		},
		root: {
			background: "{color.bg.surface.default.default}",
			borderColor: "transparent",
			color: "{color.fg.default}",
			borderRadius: "{dimension.borderRadius.400}",
			shadow: "{effects.elevation.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		list: {
			padding: "{dimension.space.100}",
			gap: "{dimension.space.100}"
		},
		item: {
			focusBackground: "{color.bg.neutral.weak.default}",
			activeBackground: "{color.bg.neutral.strong.default}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			activeColor: "{color.fg.inverse.active}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}",
			gap: "{dimension.space.200}",
			icon: {
				color: "{color.fg.default}",
				focusColor: "{color.fg.default}",
				activeColor: "{color.fg.inverse.active}"
			}
		},
		submenu: {
			mobileIndent: "{dimension.space.400}"
		},
		separator: {
			borderColor: "{color.border.neutral.default}"
		},
		submenuIcon: {
			activeColor: "{color.fg.inverse.active}",
			color: "{color.fg.default}",
			focusColor: "{color.fg.default}",
			size: "{dimension.size.400}"
		}
	},
	timeline: {
		extend: {
			extEvent: {
				gap: "{dimension.space.100}"
			}
		},
		event: {
			minHeight: "{dimension.size.1400}"
		},
		vertical: {
			eventContent: {
				padding: "{dimension.space.none} {dimension.space.600}"
			}
		},
		horizontal: {
			eventContent: {
				padding: "{dimension.space.600} {dimension.space.none}"
			}
		},
		eventMarker: {
			size: "{dimension.size.450}",
			borderRadius: "{dimension.borderRadius.400}",
			borderWidth: "{dimension.borderWidth.300}",
			background: "{color.bg.surface.raised.default}",
			borderColor: "{color.border.brand.default}",
			content: {
				borderRadius: "{dimension.borderRadius.400}",
				size: "{dimension.size.350}",
				background: "transparent",
				insetShadow: "none"
			}
		},
		eventConnector: {
			color: "{color.border.neutral.default}",
			size: "{dimension.borderWidth.100}"
		}
	},
	togglebutton: {
		extend: {
			ext: {
				gap: "{dimension.space.400}"
			},
			iconSize: {
				sm: "{dimension.size.450}",
				md: "{dimension.size.600}",
				lg: "{dimension.size.700}"
			},
			iconOnlyWidth: "{dimension.size.1100}",
			hoverBorderColor: "{color.border.neutral.strong}",
			checkedHoverColor: "{color.fg.inverse.default}",
			checkedHoverBackground: "{color.bg.neutral.strong.hover}",
			checkedHoverBorderColor: "{color.border.neutral.bold.hover}",
			extXlg: {
				padding: "{dimension.space.600} {dimension.space.700}",
				iconOnlyWidth: "{dimension.size.1400}"
			},
			extSm: {
				iconOnlyWidth: "{dimension.size.900}"
			},
			extLg: {
				iconOnlyWidth: "{dimension.size.1300}"
			}
		},
		colorScheme: {
			light: {
				root: {
					background: "{color.bg.surface.canvas.hover}",
					hoverBackground: "{color.bg.surface.canvas.active}",
					borderColor: "{color.border.neutral.default}",
					color: "{color.fg.default}",
					hoverColor: "{color.fg.default}",
					checkedBackground: "{color.bg.neutral.strong.default}",
					checkedColor: "{color.fg.on.fill.default}",
					checkedBorderColor: "{color.border.neutral.bold.default}",
					disabledBackground: "{color.bg.surface.canvas.hover}",
					disabledBorderColor: "{color.border.neutral.default}",
					disabledColor: "{color.fg.muted}",
					invalidBorderColor: "{color.border.status.danger.subtle}"
				},
				icon: {
					color: "{color.fg.default}",
					hoverColor: "{color.fg.default}",
					checkedColor: "{color.fg.on.fill.default}",
					disabledColor: "{color.fg.muted}"
				},
				content: {
					checkedBackground: "transparent"
				}
			},
			dark: {
				root: {
					hoverBackground: "{color.bg.surface.canvas.active}",
					background: "{color.bg.surface.canvas.hover}",
					borderColor: "{color.border.neutral.default}",
					color: "{color.fg.default}",
					hoverColor: "{color.fg.default}",
					checkedBackground: "{color.bg.neutral.strong.default}",
					checkedColor: "{color.fg.inverse.default}",
					checkedBorderColor: "{color.border.neutral.bold.default}",
					disabledBackground: "{color.bg.surface.canvas.hover}",
					disabledBorderColor: "{color.border.neutral.default}",
					disabledColor: "{color.fg.inverse.muted}",
					invalidBorderColor: "{color.border.status.danger.strong}"
				},
				icon: {
					color: "{color.fg.default}",
					hoverColor: "{color.fg.default}",
					checkedColor: "{color.fg.inverse.default}",
					disabledColor: "{color.fg.inverse.muted}"
				},
				content: {
					checkedBackground: "transparent"
				}
			}
		},
		root: {
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.max}",
			gap: "{dimension.space.200}",
			fontWeight: "{fonts.fontWeight.demibold}",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.200}"
			},
			sm: {
				fontSize: "{fonts.fontSize.200}",
				padding: "{dimension.space.100} {dimension.space.400}"
			},
			lg: {
				fontSize: "{fonts.fontSize.500}",
				padding: "{dimension.space.400} {dimension.space.700}"
			},
			transitionDuration: "{effects.transition.duration.200}",
			background: "{color.bg.surface.default.default}",
			borderColor: "{color.border.neutral.default}",
			checkedBackground: "{color.bg.surface.default.default}",
			checkedBorderColor: "{color.border.neutral.default}",
			checkedColor: "{color.fg.default}",
			color: "{color.fg.default}",
			disabledBackground: "{color.bg.surface.canvas.hover}",
			disabledBorderColor: "{color.border.neutral.default}",
			disabledColor: "{color.fg.muted}",
			hoverColor: "{color.fg.hover}",
			invalidBorderColor: "{color.border.status.danger.subtle}"
		},
		content: {
			checkedShadow: "none",
			padding: "{dimension.space.none}",
			borderRadius: "{dimension.borderRadius.none}",
			sm: {
				padding: "{dimension.space.none}"
			},
			lg: {
				padding: "{dimension.space.none}"
			},
			checkedBackground: "{color.bg.surface.default.default}"
		},
		icon: {
			checkedColor: "{color.fg.default}",
			color: "{color.fg.default}",
			disabledColor: "{color.fg.muted}",
			hoverColor: "{color.fg.hover}"
		}
	},
	toggleswitch: {
		colorScheme: {
			light: {
				root: {
					background: "{color.bg.neutral.medium.active}",
					hoverBackground: "{color.bg.neutral.medium.strong}",
					disabledBackground: "{color.bg.surface.canvas.hover}",
					checkedBackground: "{color.bg.neutral.strong.default}",
					checkedHoverBackground: "{color.bg.neutral.strong.hover}"
				},
				handle: {
					background: "{color.bg.surface.raised.default}",
					hoverBackground: "{color.bg.surface.raised.default}",
					disabledBackground: "{color.bg.neutral.medium.strong}",
					checkedBackground: "{color.bg.surface.raised.default}",
					checkedHoverBackground: "{color.bg.surface.raised.default}",
					color: "{color.fg.default}",
					hoverColor: "{color.fg.default}",
					checkedColor: "{color.fg.default}",
					checkedHoverColor: "{color.fg.default}"
				}
			},
			dark: {
				handle: {
					background: "{color.bg.surface.raised.default}",
					checkedBackground: "{color.bg.surface.raised.default}",
					checkedColor: "{color.fg.inverse.focus}",
					checkedHoverBackground: "{color.bg.surface.raised.default}",
					checkedHoverColor: "{color.fg.on.brand.hover}",
					color: "{color.fg.inverse.default}",
					disabledBackground: "{color.bg.surface.raised.active}",
					hoverBackground: "{color.bg.surface.raised.default}",
					hoverColor: "{color.fg.on.brand.hover}"
				},
				root: {
					background: "{color.bg.neutral.medium.active}",
					checkedBackground: "{color.bg.surface.canvas.default}",
					checkedHoverBackground: "{color.bg.surface.canvas.hover}",
					disabledBackground: "{color.bg.neutral.strong.hover}",
					hoverBackground: "{color.bg.surface.raised.active}"
				}
			}
		},
		root: {
			width: "{dimension.size.1100}",
			height: "{dimension.size.700}",
			borderRadius: "{dimension.borderRadius.max}",
			gap: "{dimension.space.100}",
			borderWidth: "{dimension.borderWidth.100}",
			shadow: "none",
			focusRing: {
				width: "{dimension.focusRing.width}",
				style: "none",
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}"
			},
			borderColor: "transparent",
			hoverBorderColor: "transparent",
			checkedBorderColor: "transparent",
			checkedHoverBorderColor: "transparent",
			invalidBorderColor: "{color.border.status.danger.subtle}",
			transitionDuration: "{effects.transition.duration.200}",
			slideDuration: "{effects.transition.duration.200}"
		},
		handle: {
			borderRadius: "{dimension.borderRadius.max}",
			size: "{dimension.size.450}"
		}
	},
	tooltip: {
		colorScheme: {
			light: {
				root: {
					background: "{color.bg.neutral.strong.default}",
					color: "{color.fg.inverse.default}"
				}
			},
			dark: {
				root: {
					background: "{color.bg.surface.canvas.default}",
					color: "{color.fg.default}"
				}
			}
		},
		root: {
			maxWidth: "{dimension.size.2000}",
			gutter: "{dimension.space.100}",
			shadow: "{effects.elevation.400}",
			padding: "{dimension.space.200} {dimension.space.400}",
			borderRadius: "{dimension.borderRadius.200}"
		}
	},
	tree: {
		root: {
			background: "{color.bg.surface.default.default}",
			color: "{color.fg.default}",
			padding: "{dimension.space.400}",
			gap: "{dimension.space.100}",
			indent: "{dimension.space.400}",
			transitionDuration: "{effects.transition.duration.200}"
		},
		node: {
			padding: "{dimension.space.200} {dimension.space.400}",
			color: "{color.fg.default}",
			selectedColor: "{color.fg.on.fill.default}",
			gap: "{dimension.space.100}",
			borderRadius: "{dimension.borderRadius.400}",
			focusRing: {
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				style: "none",
				width: "{dimension.focusRing.width}"
			},
			hoverBackground: "{color.bg.neutral.weak.default}",
			hoverColor: "{color.fg.default}",
			selectedBackground: "{color.bg.neutral.strong.selected}"
		},
		nodeIcon: {
			selectedColor: "{color.fg.on.fill.default}",
			color: "{color.fg.default}",
			hoverColor: "{color.fg.hover}"
		},
		nodeToggleButton: {
			borderRadius: "{dimension.borderRadius.100}",
			size: "{dimension.size.800}",
			selectedHoverBackground: "{color.bg.neutral.strong.default}",
			color: "{color.fg.default}",
			focusRing: {
				color: "{color.border.focus}",
				offset: "{dimension.focusRing.offset}",
				shadow: "{effects.elevation.none}",
				style: "none",
				width: "{dimension.focusRing.width}"
			},
			hoverBackground: "{color.bg.neutral.weak.default}",
			hoverColor: "{color.fg.hover}",
			selectedHoverColor: "{color.fg.hover}"
		},
		loadingIcon: {
			size: "{dimension.size.450}"
		},
		filter: {
			margin: "{dimension.space.none} {dimension.space.none} {dimension.space.200} {dimension.space.none}"
		}
	},
	overlaybadge: {
		root: {
			outline: {
				width: "{dimension.size.none}",
				color: "transparent"
			}
		}
	}
};
var tokens = {
	primitive: primitive,
	semantic: semantic,
	components: components
};

const avatarCss = ({ dt }) => `
.p-avatar-group .ui-avatar + .ui-avatar {
  margin-inline-start: ${dt('avatar.group.offset')};
}

.p-avatar-group .ui-avatar-lg + .ui-avatar-lg {
  margin-inline-start: ${dt('avatar.lg.group.offset')};
}

.p-avatar-group .ui-avatar-xl + .ui-avatar-xl {
  margin-inline-start: ${dt('avatar.xl.group.offset')};
}

.p-avatar.p-avatar-circle {
  border-radius: ${dt('avatar.extend.circle.borderRadius')};
  overflow: hidden;
}

.p-overlaybadge.p-overlaybadge {
  width: fit-content;
}
`;

/**
 * Кастомная CSS-стилизация для компонента p-button.
 * Подключается в map-tokens.ts: `import { buttonCss } from './tokens/components/button'`
 *
 * Все значения берутся через dt() — PrimeUIX сам выпускает CSS-переменную для каждого токена
 * пресета, поэтому объявлять их повторно в :root не нужно.
 */
const buttonCss = ({ dt }) => `
  /* ─── Шрифт для текста кнопки ─── */
  .p-button.p-component .p-button-label {
    font-family: ${dt('fonts.fontFamily.heading')}, sans-serif;
    font-weight: ${dt('button.root.label.fontWeight')};
  }

  /* ─── Рамка ─── */
  .p-button {
    border-width: ${dt('button.extend.borderWidth')};
  }

  /* ─── Button badge ─── */
  .p-button, .p-ripple.p-button {
    position: relative;
    overflow: visible;
  }

  .p-button .p-badge {
      position: absolute;
      inset-block-start: 0;
      inset-inline-end: 0;
      transform: translate(50%, -50%);
      transform-origin: 100% 0;
      margin: 0;
  }

  /* ─── Размеры иконок ─── */
  .p-button .p-button-icon {
    font-size: ${dt('button.extend.iconSize.md')};
  }
  .p-button.p-button-sm .p-button-icon {
    font-size: ${dt('button.extend.iconSize.sm')};
  }
  .p-button.p-button-lg .p-button-icon {
    font-size: ${dt('button.extend.iconSize.lg')};
  }
  .p-button-xlg.p-button .p-button-icon,
  .p-button-link.p-button-xlg .p-button-icon {
    font-size: ${dt('button.extend.iconSize.lg')};
  }

  /* ─── Disabled / loading ─── */
  .p-button:is(.p-disabled, :disabled, .p-button-loading) {
    mix-blend-mode: inherit;
    opacity: ${dt('effects.opacity.100')};
    color: ${dt('button.extend.disabledColor')};
    background: ${dt('button.extend.disabledBackground')};
    border-color: ${dt('button.extend.disabledBackground')};
  }
  .p-button.p-button-outlined:is(.p-disabled, :disabled, .p-button-loading) {
    color: ${dt('button.extend.disabledColor')};
    background: transparent;
    border-color: transparent;
  }
  .p-button.p-button-text:is(.p-disabled, :disabled, .p-button-loading) {
    color: ${dt('button.extend.disabledColor')};
    background: transparent;
    border-color: transparent;
  }
  .p-button.p-button-link:is(.p-disabled, :disabled, .p-button-loading) {
    color: ${dt('button.extend.disabledColor')};
    background: transparent;
    border-color: transparent;
  }

  /* ─── Link кнопки ─── */
  .p-button-link.p-button:is(.p-button, .p-button-xlg) {
    padding: ${dt('button.extend.extLink.paddingY')} ${dt('button.extend.extLink.paddingX')};
  }
  .p-button-link.p-button {
    width: min-content;
    height: auto;
    background: ${dt('button.extend.extLink.background')};
  }
  .p-button-link.p-button.p-button-xlg {
    font-size: ${dt('fonts.fontSize.600')};
  }
  .p-button.p-button-link:not(:disabled):hover {
    color: ${dt('button.extend.extLink.colorHover')};
  }
  .p-button.p-button-link:not(:disabled):hover .p-button-label {
    text-decoration: none;
  }

  /* ─── Icon-only link кнопки ─── */
  .p-button-link.p-button-icon-only {
    width: ${dt('button.extend.extLink.base.iconOnlyWidth')};
    height: ${dt('button.extend.extLink.base.iconOnlyWidth')};
  }
  .p-button-link.p-button-icon-only.p-button-sm {
    width: ${dt('button.extend.extLink.sm.iconOnlyWidth')};
    height: ${dt('button.extend.extLink.sm.iconOnlyWidth')};
  }
  .p-button-link.p-button-icon-only.p-button-lg {
    width: ${dt('button.extend.extLink.lg.iconOnlyWidth')};
    height: ${dt('button.extend.extLink.lg.iconOnlyWidth')};
  }
  .p-button-link.p-button-icon-only.p-button-xlg {
    width: ${dt('button.extend.extLink.xlg.iconOnlyWidth')};
    height: ${dt('button.extend.extLink.xlg.iconOnlyWidth')};
  }

  /* ─── Line-height ─── */
  .p-button-sm {
    line-height: ${dt('fonts.lineHeight.250')};
  }
  .p-button:is(.p-button-lg, .p-button-xlg) {
    line-height: ${dt('fonts.lineHeight.550')};
  }

  /* ─── Border-radius / gap для sm / lg / xlg ─── */
  .p-button.p-button-sm:not(.p-button-rounded) {
    border-radius: ${dt('button.extend.extSm.borderRadius')};
  }
  .p-button.p-button-sm {
    gap: ${dt('button.extend.extSm.gap')};
  }
  .p-button:is(.p-button-lg, .p-button-xlg):not(.p-button-rounded) {
    border-radius: ${dt('button.extend.extLg.borderRadius')};
  }
  .p-button.p-button-lg {
    gap: ${dt('button.extend.extLg.gap')};
  }
  .p-button.p-button-xlg {
    gap: ${dt('button.extend.extXlg.gap')};
  }
  .p-button-xlg.p-button:not(.p-button-rounded) {
    border-radius: ${dt('button.extend.extXlg.borderRadius')};
  }

  /* ─── Высота по размерам (base/sm задаются токенами дизайна) ─── */
  .p-button:not(.p-button-link) {
    height: ${dt('button.root.height')};
  }
  .p-button.p-button-sm:not(.p-button-link) {
    height: ${dt('button.extend.extSm.height')};
  }

  /* ─── Padding / font-size / height для lg ─── */
  .p-button-lg.p-button:not(.p-button-icon-only):not(.p-button-link) {
    padding: ${dt('button.root.lg.paddingY')} ${dt('button.root.lg.paddingX')};
    font-size: ${dt('button.root.lg.fontSize')};
    height: ${dt('button.extend.extLg.height')};
  }

  /* ─── Padding / font-size / height для xlg ─── */
  .p-button-xlg.p-button:not(.p-button-icon-only):not(.p-button-link) {
    padding: ${dt('button.extend.extXlg.paddingY')} ${dt('button.extend.extXlg.paddingX')};
    font-size: ${dt('fonts.fontSize.500')};
    height: ${dt('button.extend.extXlg.height')};
  }

  /* ─── Icon-only размеры ─── */
  .p-button-icon-only {
    width: ${dt('button.root.iconOnlyWidth')};
    height: ${dt('button.root.iconOnlyWidth')};
  }
  .p-button-sm.p-button-icon-only {
    width: ${dt('button.root.sm.iconOnlyWidth')};
    height: ${dt('button.root.sm.iconOnlyWidth')};
  }
  .p-button-lg.p-button-icon-only {
    width: ${dt('button.root.lg.iconOnlyWidth')};
    height: ${dt('button.root.lg.iconOnlyWidth')};
  }
  .p-button-xlg.p-button-icon-only {
    width: ${dt('button.extend.extXlg.iconOnlyWidth')};
    height: ${dt('button.extend.extXlg.iconOnlyWidth')};
  }

  /* ─── Icon-only: центрирование иконки для sm / lg / xlg ───
     PrimeNG-размеры (.p-button-sm / .p-button-lg) возвращают горизонтальный
     padding, а кастомный gap для sm/lg/xlg перекрывает базовый сброс
     .p-button-icon-only { padding-inline: 0; gap: 0 }. Из-за этого иконка
     съезжает влево. Возвращаем сброс с более высокой специфичностью. */
  .p-button-icon-only:is(.p-button-sm, .p-button-lg, .p-button-xlg) {
    padding-inline-start: 0;
    padding-inline-end: 0;
    gap: 0;
  }

  /* ─── Фон в фокусе для severity (outlined / text) ─── */
  .p-button.p-button-outlined.p-button-danger:focus-visible {
    background: ${dt('button.extend.extOutlined.danger.focusBackground')};
  }
  .p-button.p-button-outlined.p-button-warn:focus-visible {
    background: ${dt('button.extend.extOutlined.warn.focusBackground')};
  }
  .p-button.p-button-outlined.p-button-info:focus-visible {
    background: ${dt('button.extend.extOutlined.info.focusBackground')};
  }
  .p-button.p-button-outlined.p-button-help:focus-visible {
    background: ${dt('button.extend.extOutlined.help.focusBackground')};
  }
  .p-button.p-button-outlined.p-button-success:focus-visible {
    background: ${dt('button.extend.extOutlined.success.focusBackground')};
  }
  .p-button.p-button-text.p-button-danger:focus-visible {
    background: ${dt('button.extend.extText.danger.focusBackground')};
  }
  .p-button.p-button-text.p-button-warn:focus-visible {
    background: ${dt('button.extend.extText.warn.focusBackground')};
  }
  .p-button.p-button-text.p-button-info:focus-visible {
    background: ${dt('button.extend.extText.info.focusBackground')};
  }
  .p-button.p-button-text.p-button-help:focus-visible {
    background: ${dt('button.extend.extText.help.focusBackground')};
  }
  .p-button.p-button-text.p-button-success:focus-visible {
    background: ${dt('button.extend.extText.success.focusBackground')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-card.
 * Подключается в map-tokens.ts: `import { cardCss } from './tokens/components/card'`
 *
 * Все значения берутся через dt() — PrimeUIX сам выпускает CSS-переменную для каждого токена
 * пресета, поэтому объявлять их повторно в :root не нужно.
 */
const cardCss = ({ dt }) => `
  /* ─── Рамка и базовое состояние ─── */
  .p-card.p-component {
    border: ${dt('card.extend.borderWidth')} solid ${dt('card.extend.borderColor')};
    overflow: hidden;
    box-shadow: ${dt('card.root.shadow')};
  }

  /* ─── Overlay: тень задаётся токеном карточки, а не общей шкалой ─── */
  .p-card.p-component.shadow-md {
    box-shadow: ${dt('card.overlay.shadow')};
  }

  /* ─── Caption: обёртка заголовка и подзаголовка ─── */
  .p-card-caption {
    display: flex;
    flex-direction: column;
    gap: ${dt('card.caption.gap')};
  }

  /* ─── Типографика подзаголовка ─── */
  .p-card-subtitle {
    font-family: ${dt('fonts.fontFamily.heading')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-checkbox.
 * Подключается в map-tokens.ts: `import { checkboxCss } from './tokens/components/checkbox'`
 *
 * Размеры бокса и цвета приходят токенами пресета (checkbox.root.*): их применяет сам PrimeNG.
 * Здесь — типографика подписей, толщина рамки, indeterminate и кольцо фокуса: ни того, ни другого
 * у Aura нет (indeterminate не покрашен, толщина рамки зашита сырым 1px).
 */
const checkboxCss = ({ dt }) => `
/* ─── Раскладка: бокс и текст в строку, по центру ─── */
.extra-checkbox {
  display: flex;
  align-items: center;
  gap: ${dt('dimension.space.200')};
}

.extra-checkbox--left {
  flex-direction: row-reverse;
  justify-content: flex-end;
}

/* ─── Label типографика ─── */
.checkbox-label {
  display: flex;
  align-items: center;
  color: ${dt('color.fg.default')};
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.300')};
  cursor: pointer;
}

.checkbox-label--hover {
  color: ${dt('color.fg.brand.default')};
}

.checkbox-label--disabled {
  color: ${dt('color.fg.muted')};
  cursor: default;
}

.checkbox-caption {
  color: ${dt('color.fg.subtle')};
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.250')};
}

.checkbox-caption--hover {
  color: ${dt('color.fg.brand.default')};
}

.checkbox-caption--disabled {
  color: ${dt('color.fg.muted')};
}

/* Переопределение ширины border для checkbox */
.p-checkbox-box {
  border-width: ${dt('checkbox.root.extend.borderWidth')};
}

/* Состояние indeterminate - фон и border как у checked */
.p-checkbox-indeterminate .p-checkbox-box {
  background: ${dt('checkbox.root.checkedBackground')};
  border-color: ${dt('checkbox.root.checkedBorderColor')};
}

/* ─── Цвет иконки на залитом боксе ───
   checkbox.icon.checkedColor ссылается на color.fg.on.fill.default, а эта ветка не
   инвертируется: и в light, и в dark она #ffffff. Фон бокса при этом инвертируется
   (color.bg.neutral.strong.default: тёмный в light, светлый в dark), поэтому в тёмной теме
   белая галочка пропадала на светлом фоне. Берём инверсный алиас — он меняется вместе с фоном. */
.p-checkbox-checked .p-checkbox-icon,
.p-checkbox-indeterminate .p-checkbox-icon {
  color: ${dt('color.fg.inverse.default')};
}

/* То же на hover: PrimeNG подставляет icon.checkedHoverColor (color.fg.on.fill.hover),
   а эта ветка не инвертируется — в тёмной теме белая иконка пропадала на светлом боксе */
.p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-icon,
.p-checkbox-indeterminate:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-icon {
  color: ${dt('color.fg.inverse.default')};
}

/* Состояние hover для indeterminate */
.p-checkbox-indeterminate:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
  background: ${dt('checkbox.root.checkedHoverBackground')};
  border-color: ${dt('checkbox.root.checkedHoverBorderColor')};
}

/* Focus ring с зеленым цветом для валидных состояний */
.p-checkbox:not(.p-disabled):not(.p-checkbox-checked):not(.p-invalid):has(.p-checkbox-input:focus-visible) .p-checkbox-box,
.p-checkbox-checked:not(.p-disabled):not(.p-invalid):has(.p-checkbox-input:focus-visible) .p-checkbox-box,
.p-checkbox-indeterminate:not(.p-disabled):not(.p-invalid):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
  box-shadow: 0 0 0 ${dt('checkbox.root.focusRing.width')} ${dt('color.border.focus')};
}

/* Focus ring с красным цветом для состояний с ошибкой */
.p-checkbox.p-invalid .p-checkbox-box,
.p-checkbox-checked.p-invalid .p-checkbox-box,
.p-checkbox-indeterminate.p-invalid .p-checkbox-box {
  box-shadow: 0 0 0 ${dt('checkbox.root.focusRing.width')} ${dt('color.bg.status.danger.weak.active')};
}
`;

const inputmaskCss = ({ dt }) => `

/* ─── Раскладка обёртки с label/caption ───
   Шаблон ExtraInputMaskComponent оборачивает поле в .extra-inputmask только когда задан
   label или caption. Без этих правил div остаётся block-элементом: inline-лейбл при
   labelPosition="top" встаёт в одну строку с полем, а при "left" — выдавливается
   на строку выше (labelPosition работает ровно наоборот спецификации). */
.extra-inputmask {
  display: flex;
  flex-direction: column;
}

.extra-inputmask--left {
  flex-direction: row;
  align-items: flex-start;
  gap: ${dt('dimension.space.200')};
}

/* Лейбл слева выравниваем по высоте поля, а не по центру всего body с caption */
.extra-inputmask--left > .extra-inputmask-label {
  padding-block: calc(${dt('inputtext.root.paddingY')} + ${dt('inputtext.extend.borderWidth')});
}

.extra-inputmask-body {
  display: flex;
  flex-direction: column;
  /* без flex-start поле растягивается на всю ширину обёртки и игнорирует [fluid]="false";
     при fluid ширину задаёт сам p-inputmask (:has(.p-inputtext-fluid) → width: 100%),
     и flex-start ей не мешает */
  align-items: flex-start;
  gap: ${dt('dimension.space.100')};
}

/* В режиме left body забирает остаток строки — иначе [fluid] некуда растягиваться */
.extra-inputmask--left > .extra-inputmask-body {
  flex: 1 1 auto;
  min-width: 0;
}

/* ─── Label ─── */
.extra-inputmask-label {
  display: inline-flex;
  align-items: center;
  gap: ${dt('dimension.space.100')};
  color: ${dt('color.fg.default')};
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.300')};
  cursor: pointer;
}

.extra-inputmask-label-icon {
  color: ${dt('color.fg.subtle')};
  font-size: ${dt('inputtext.extend.iconSize')};
  cursor: help;
}

/* ─── Caption ─── */
.extra-inputmask-caption {
  color: ${dt('color.fg.subtle')};
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.250')};
}

/* Внутри p-floatlabel лейбл лежит поверх поля — курсор должен быть как у ввода */
.extra-inputmask-body > .p-floatlabel > .extra-inputmask-label {
  cursor: text;
}

/* ─── Clear icon ───
   Иконка очистки у p-inputmask своя (не p-iconfield), поэтому размер задаём ей отдельно
   тем же токеном, что и иконкам inputtext. */
.p-inputmask-clear-icon {
  width: ${dt('inputtext.extend.iconSize')};
  height: ${dt('inputtext.extend.iconSize')};
  margin-top: calc(${dt('inputtext.extend.iconSize')} / -2);
}

/* Иконка лежит поверх поля абсолютом — освобождаем под неё место справа, иначе
   значение уезжает под крестик. Класс ставится по пропу clearable (а не по наличию
   иконки), чтобы padding не прыгал на первом введённом символе. */
.p-inputtext.extra-inputmask-clearable {
  padding-inline-end: calc(${dt('inputtext.root.paddingX')} * 2 + ${dt('inputtext.extend.iconSize')});
}

.p-inputtext.extra-inputmask-clearable.p-inputtext-xlg {
  padding-inline-end: calc(${dt('inputtext.extend.extXlg.paddingX')} * 2 + ${dt('inputtext.extend.iconSize')});
}

/* ─── Sizes ───
   Базовые small/large приходят из pSize, xlg — класс на самом input (styleClass).
   Хост extra-input-mask с display: contents из раскладки выпадает, селектор идёт
   от p-inputmask. */
p-inputmask > .p-inputtext.p-inputtext-xlg {
  font-size: ${dt('inputtext.extend.extXlg.fontSize')};
  padding: ${dt('inputtext.extend.extXlg.paddingY')} ${dt('inputtext.extend.extXlg.paddingX')};
}
`;

const inputtextCss = ({ dt }) => `

/* ─── Раскладка обёртки с label/caption ───
   Шаблон ExtraInputTextComponent оборачивает поле в .extra-inputtext только когда задан
   label или caption. Без этих правил div остаётся block-элементом: inline-label при
   label-position="default" встаёт в одну строку с полем, а при "left" — наоборот,
   выдавливается на строку выше (label-position работает ровно наоборот спецификации). */
.extra-inputtext {
  display: flex;
  flex-direction: column;
}

.extra-inputtext--left {
  flex-direction: row;
  align-items: flex-start;
  gap: ${dt('dimension.space.200')};
}

/* Лейбл слева выравниваем по высоте поля, а не по центру всего body с caption */
.extra-inputtext--left > .extra-inputtext-label {
  padding-block: calc(${dt('inputtext.root.paddingY')} + ${dt('inputtext.extend.borderWidth')});
}

.extra-inputtext-body {
  display: flex;
  flex-direction: column;
  /* без flex-start поле растягивается на всю ширину обёртки и игнорирует [fluid]="false";
     при fluid ширина задана самим инпутом (width: 100%) и flex-start ей не мешает */
  align-items: flex-start;
  gap: ${dt('dimension.space.100')};
}

/* Обёртки поля (clearable → p-iconfield, label-position="float" → p-floatlabel) собственной
   ширины не имеют, поэтому при align-items: flex-start схлопываются по содержимому и
   [fluid]="true" внутри них перестаёт работать. Ширину задаём явно: align-self: stretch
   не помогает — у .p-iconfield ширина не auto. */
.extra-inputtext-body .p-iconfield:has(.p-inputtext-fluid),
.extra-inputtext-body > .p-floatlabel:has(.p-inputtext-fluid) {
  width: 100%;
}

/* В режиме left body забирает остаток строки — иначе [fluid] некуда растягиваться */
.extra-inputtext--left > .extra-inputtext-body {
  flex: 1 1 auto;
  min-width: 0;
}

/* ─── Label ─── */
.extra-inputtext-label {
  display: inline-flex;
  align-items: center;
  gap: ${dt('dimension.space.100')};
  color: ${dt('color.fg.default')};
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.300')};
  cursor: pointer;
}

.extra-inputtext-label-icon {
  color: ${dt('color.fg.subtle')};
  font-size: ${dt('inputtext.extend.iconSize')};
  cursor: help;
}

/* ─── Caption ─── */
.extra-inputtext-caption {
  color: ${dt('color.fg.subtle')};
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.250')};
}

/* Внутри p-floatlabel лейбл лежит поверх поля — курсор должен быть как у ввода */
.extra-inputtext-body > .p-floatlabel > .extra-inputtext-label {
  cursor: text;
}

/* ─── Базовые стили ─── */
.p-inputtext {
  line-height: ${dt('fonts.lineHeight.250')};
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-inputtext::placeholder {
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-floatlabel:has(.p-inputtext) label {
  font-family: ${dt('fonts.fontFamily.base')};
}

/* ─── Disabled ─── */
.p-inputtext:disabled {
  background: ${dt('inputtext.root.disabledBackground')};
  color: ${dt('inputtext.root.disabledColor')};
}

/* ─── Readonly ─── */
.p-inputtext:enabled:read-only {
  background: ${dt('inputtext.extend.readonlyBackground')};
  color: ${dt('inputtext.root.color')};
}

/* ─── Focus ─── */
.p-inputtext:enabled:focus {
  box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('inputtext.root.focusRing.color')};
}

/* ─── Invalid + Focus ─── */
.p-inputtext.p-invalid:focus {
  border-color: ${dt('inputtext.root.invalidBorderColor')};
  box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('color.border.status.danger.focus')};
}

/* ─── Extra Large ─── */
.p-inputtext.p-inputtext-xlg {
  font-size: ${dt('inputtext.extend.extXlg.fontSize')};
  padding: ${dt('inputtext.extend.extXlg.paddingY')} ${dt('inputtext.extend.extXlg.paddingX')};
}

/* ─── IconField ─── */
.p-iconfield[data-pc-name="iconfield"] {
  width: fit-content;
}

.p-iconfield .p-inputicon {
  font-size: ${dt('inputtext.extend.iconSize')};
  width: ${dt('inputtext.extend.iconSize')};
  height: ${dt('inputtext.extend.iconSize')};
  cursor: pointer;
}
`;

const progressspinnerCss = ({ dt }) => `
.p-progressspinner-circle {
  stroke-width: ${dt('progressspinner.root.borderWidth')};
}

/* multicolor false */
.p-progressspinner.p-progressspinner-monochrome .p-progressspinner-circle {
    stroke: ${dt('color.bg.brand.strong.default')};
    animation: p-progressspinner-dash 1.5s ease-in-out infinite;
}

.p-progressspinner.p-progressspinner-small,
.p-progressspinner.p-progressspinner-small .p-progressspinner-circle {
  width: ${dt('progressspinner.extend.small')};
  height: ${dt('progressspinner.extend.small')};
}

.p-progressspinner.p-progressspinner-base,
.p-progressspinner.p-progressspinner-base .p-progressspinner-circle {
  width: ${dt('progressspinner.extend.medium')};
  height: ${dt('progressspinner.extend.medium')};
}

.p-progressspinner.p-progressspinner-large,
.p-progressspinner.p-progressspinner-large .p-progressspinner-circle {
  width: ${dt('progressspinner.extend.large')};
  height: ${dt('progressspinner.extend.large')};
}

.p-progressspinner.p-progressspinner-xlarge,
.p-progressspinner.p-progressspinner-xlarge .p-progressspinner-circle {
  width: ${dt('progressspinner.extend.xlarge')};
  height: ${dt('progressspinner.extend.xlarge')};
}
`;

/**
 * Кастомная CSS-стилизация для компонента p-password.
 * Подключается в map-tokens.ts: `import { passwordCss } from './components/password'`
 */
const passwordCss = ({ dt }) => `
  /* ─── Иконки управления ─── */
  .p-password-toggle-mask-icon,
  .p-icon.p-password-toggle-mask-icon.p-password-unmask-icon {
    cursor: pointer;
    color: ${dt('password.icon.color')};
  }

  /* ─── Оверлей и индикатор ─── */
  .p-password-overlay {
    border-width: ${dt('password.extend.borderWidth')};
  }

  .p-password-meter-text {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
    color: ${dt('password.overlay.color')};
  }

  /* ─── Focus ─── */
  .p-password:has(.p-inputtext:enabled:focus) {
    box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('inputtext.root.focusRing.color')};
    border-radius: ${dt('inputtext.root.borderRadius')};
  }

  /* ─── Invalid + Focus ─── */
  .p-password:has(.p-inputtext.p-invalid:focus) {
    box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('color.bg.status.danger.weak.active')};
    border-radius: ${dt('inputtext.root.borderRadius')};
  }

  .p-password:has(.p-inputtext.p-invalid:focus) .p-inputtext {
    border-color: ${dt('inputtext.root.invalidBorderColor')};
  }

  /* ─── FloatLabel ─── */
  .p-floatlabel:has(.p-password) label {
    font-family: ${dt('fonts.fontFamily.base')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
    color: ${dt('color.bg.neutral.medium.strong')};
  }

  .p-floatlabel:has(.p-password) .p-floatlabel-active label {
    font-weight: ${dt('fonts.fontWeight.regular')};
  }

  .p-floatlabel-in .p-password .p-inputtext {
    font-family: ${dt('fonts.fontFamily.base')};
    padding-block-start: ${dt('dimension.space.700')};
    padding-block-end: ${dt('dimension.space.300')};
  }

  /* ─── Кастомный контент (правила пароля) ─── */
  .p-password-rules {
    display: flex;
    flex-direction: column;
    gap: ${dt('password.content.gap')};
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .p-password-rule {
    display: flex;
    align-items: center;
    gap: ${dt('password.content.gap')};
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
    color: ${dt('password.overlay.color')};
  }

  /* ─── Состояния иконок правил ─── */
  .p-password-rule i {
    font-size: ${dt('fonts.fontSize.200')};
  }

  .p-password-rule .ti-circle {
    color: ${dt('color.fg.subtle')};
  }

  .p-password-rule .ti-circle-check {
    color: ${dt('password.colorScheme.light.strength.strongBackground')};
  }

  .p-password-rule .ti-circle-x {
    color: ${dt('password.colorScheme.light.strength.weakBackground')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-tag.
 * Подключается в map-tokens.ts: `import { tagCss } from './tokens/components/tag'`
 *
 * Размеры, цвета и радиусы приходят токенами пресета (tag.root.*, tag.icon.*, tag.colorScheme.*) —
 * PrimeNG применяет их сам. Здесь только то, чего нет в наборе токенов Aura.
 */
const tagCss = ({ dt }) => `
  .p-tag {
    /* Дизайн набирает метку акцентным шрифтом (primary-font), а не текстовым */
    font-family: ${dt('fonts.fontFamily.heading')};
    line-height: ${dt('fonts.lineHeight.250')};
  }
`;

const textareaCss = ({ dt }) => `

/* --- Base --- */
.p-textarea {
  border-width: ${dt('textarea.extend.borderWidth')};
  line-height: ${dt('fonts.lineHeight.250')};
  min-height: ${dt('textarea.extend.minHeight')};
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-textarea::placeholder {
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-floatlabel:has(.p-textarea) label {
  font-family: ${dt('fonts.fontFamily.base')};
}

/* --- Sizes --- */
.p-textarea.p-textarea-xlg {
  font-size: ${dt('textarea.extend.extXlg.fontSize')};
  padding: ${dt('textarea.extend.extXlg.paddingY')} ${dt('textarea.extend.extXlg.paddingX')};
}

/* --- States --- */
.p-textarea:enabled:read-only {
  background: ${dt('textarea.extend.readonlyBackground')};
  color: ${dt('textarea.root.color')};
}

.p-textarea:disabled {
  background: ${dt('textarea.root.disabledBackground')};
  color: ${dt('textarea.root.disabledColor')};
  opacity: 1;
}

/* --- Focus --- */
.p-textarea:enabled:focus {
  box-shadow: 0 0 0 ${dt('textarea.root.focusRing.width')} ${dt('textarea.root.focusRing.color')};
}

/* --- Invalid + Focus --- */
.p-textarea.p-invalid:focus {
  border-color: ${dt('textarea.root.invalidBorderColor')};
  box-shadow: 0 0 0 ${dt('textarea.root.focusRing.width')} ${dt('color.bg.status.danger.weak.active')};
}

/* --- ClearButton (showClear) --- */
.p-iconfield:has(.p-textarea) {
  display: block;
  width: fit-content;
}

.p-iconfield:has(.p-textarea) .p-textarea {
  padding-right: ${dt('dimension.space.700')};
}

.p-iconfield:has(.p-textarea) .p-inputicon {
  top: ${dt('dimension.space.500')};
  transform: none;
  font-size: ${dt('textarea.extend.iconSize')};
  width: ${dt('textarea.extend.iconSize')};
  height: ${dt('textarea.extend.iconSize')};
  cursor: pointer;
}

`;

/**
 * Кастомная CSS-стилизация для компонента p-tooltip.
 * Подключается в map-tokens.ts: `import { tooltipCss } from './tokens/components/tooltip'`
 *
 * Геометрию и цвета применяет сам PrimeNG из токенов пресета (tooltip.root.*, tooltip.colorScheme.*):
 * maxWidth, gutter (он же размер стрелки), padding, borderRadius, shadow, фон и цвет текста.
 * Типографики у Aura для подсказки нет вовсе — её задаём здесь.
 */
const tooltipCss = ({ dt }) => `
/* Типографика для Tooltip.
   Figma <Tooltip> (24:1369) использует текстовый стиль secondary-font/text-base/font-normal:
   fontSize.200 + lineHeight.400. В ките стояла lineHeight.300 — 18px, подогнанные под базу 14. */
.p-tooltip .p-tooltip-text {
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.400')};
  letter-spacing: ${dt('fonts.letterSpacing.500')};
}
`;

const inputgroupCss = ({ dt }) => `

/* ─── Корректировка flex-layout через Angular-обёртки ─── */

/*
 * display: contents делает враппер-элементы прозрачными в layout-дереве:
 * p-inputgroupaddon и input.p-inputtext становятся прямыми flex-элементами
 * p-inputgroup. Это позволяет:
 * - align-items: stretch работать напрямую → правильная высота аддона
 * - границам быть на одном уровне → нет удвоения top/bottom border
 * - flex: 1 1 auto; width: 1% на input работать нативно через PrimeNG
 * CSS-селекторы по-прежнему работают (DOM-дерево не меняется).
 */
.p-inputgroup > input-group-addon {
  display: contents;
}

.p-inputgroup > input-text {
  display: contents;
}

/* ─── Корректировка border-radius и границ ─── */

/*
 * p-inputgroupaddon является :first-child И :last-child своего прямого родителя
 * input-group-addon, поэтому PrimeNG добавляет ему оба inline-бордера.
 * Сбрасываем их и переназначаем по позиции аддона в группе.
 */
.p-inputgroup > input-group-addon > .p-inputgroupaddon {
  border-radius: 0;
  border-inline-start: none;
  border-inline-end: none;
}

/* Первый элемент группы — аддон: левые углы + левая граница */
.p-inputgroup > input-group-addon:first-child > .p-inputgroupaddon {
  border-start-start-radius: ${dt('inputgroup.addon.borderRadius')};
  border-end-start-radius: ${dt('inputgroup.addon.borderRadius')};
  border-inline-start: ${dt('inputgroup.extend.borderWidth')} solid ${dt('inputgroup.addon.borderColor')};
}

/* Последний элемент группы — аддон: правые углы + правая граница */
.p-inputgroup > input-group-addon:last-child > .p-inputgroupaddon {
  border-start-end-radius: ${dt('inputgroup.addon.borderRadius')};
  border-end-end-radius: ${dt('inputgroup.addon.borderRadius')};
  border-inline-end: ${dt('inputgroup.extend.borderWidth')} solid ${dt('inputgroup.addon.borderColor')};
}

/* Аддон сразу после другого аддона: левая граница как разделитель */
.p-inputgroup > input-group-addon + input-group-addon > .p-inputgroupaddon {
  border-inline-start: ${dt('inputgroup.extend.borderWidth')} solid ${dt('inputgroup.addon.borderColor')};
}

/* Сброс border-radius у input внутри input-text-обёртки */
.p-inputgroup > input-text .p-inputtext {
  border-radius: 0;
  margin: 0;
}

/* Аддон: только горизонтальные границы (top/bottom), inline-бордеры управляются позиционно */
.p-inputgroup > input-group-addon > .p-inputgroupaddon {
  border-block-start: ${dt('inputgroup.extend.borderWidth')} solid ${dt('inputgroup.addon.borderColor')};
  border-block-end: ${dt('inputgroup.extend.borderWidth')} solid ${dt('inputgroup.addon.borderColor')};
}

/* Первый элемент группы — input: левые углы */
.p-inputgroup > input-text:first-child .p-inputtext {
  border-start-start-radius: ${dt('inputgroup.addon.borderRadius')};
  border-end-start-radius: ${dt('inputgroup.addon.borderRadius')};
}

/* Последний элемент группы — input: правые углы */
.p-inputgroup > input-text:last-child .p-inputtext {
  border-start-end-radius: ${dt('inputgroup.addon.borderRadius')};
  border-end-end-radius: ${dt('inputgroup.addon.borderRadius')};
}

/* ─── Addon в disabled состоянии ─── */
.p-inputgroup:has(input[disabled]) .p-inputgroupaddon,
.p-inputgroup:has(.p-inputtext[disabled]) .p-inputgroupaddon,
.p-inputgroup:has(.p-component[disabled]) .p-inputgroupaddon {
  background: ${dt('inputtext.root.disabledBackground')};
  color: ${dt('inputtext.root.disabledColor')};
}

/* ─── Иконка внутри addon ─── */
.p-inputgroup .p-inputgroupaddon i {
  font-size: ${dt('inputgroup.extend.iconSize')};
}

/* ─── Extra Large ─── */
.p-inputgroup.p-inputgroup-xlg .p-inputgroupaddon {
  font-size: ${dt('inputtext.extend.extXlg.fontSize')};
  padding: ${dt('inputtext.extend.extXlg.paddingY')} ${dt('inputtext.extend.extXlg.paddingX')};
}

.p-inputgroup.p-inputgroup-xlg .p-inputgroupaddon i {
  font-size: ${dt('inputtext.extend.extXlg.fontSize')};
}
`;

const megamenuCss = ({ dt }) => `
/* ─── Размер иконок ─── */
.p-megamenu-submenu-icon,
.p-megamenu-item-icon {
  font-size: ${dt('megamenu.extend.iconSize')};
}

/* ─── Типографика пунктов меню ─── */
.p-megamenu-item-label {
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.regular')};
}

/* ─── Caption (описание) для кастомных пунктов ─── */
.p-megamenu .megamenu-item-label {
  display: flex;
  flex-direction: column;
  gap: ${dt('megamenu.extend.extItem.caption.gap')};
}

.p-megamenu .megamenu-item-caption {
  font-size: ${dt('fonts.fontSize.200')};
  color: ${dt('megamenu.extend.extItem.caption.color')};
}

/* ─── Иконка мобильной кнопки ─── */
.p-megamenu-mobile-button-icon {
  font-size: ${dt('megamenu.extend.iconSize')};
}

/* ─── Размер ширины панели по контенту и позиционирование для активных пунктов горизонтального вида от начала пункта меню ─── */
.p-megamenu-root-list > .p-megamenu-item-active > .p-megamenu-overlay,
.p-megamenu-vertical .p-megamenu-root-list > .p-megamenu-item-active > .p-megamenu-overlay {
  min-width: fit-content;
  left: unset;
}

/* ─── Позиционирование оверлея от пункта для вертикального вида ─── */
.p-megamenu.p-megamenu-vertical .p-megamenu-root-list > .p-megamenu-item-active > .p-megamenu-overlay {
  left: 100%;
}
`;

const selectCss = ({ dt }) => `

  /* ─── Раскладка обёртки с label/caption ───
     Шаблон ExtraSelectComponent оборачивает поле в .extra-select только когда задан
     label или caption. Без этих правил div остаётся block-элементом: inline-лейбл при
     labelPosition="top" встаёт в одну строку с полем, а при "left" — выдавливается
     на строку выше (labelPosition работает ровно наоборот спецификации). */
  .extra-select {
    display: flex;
    flex-direction: column;
  }

  .extra-select--left {
    flex-direction: row;
    align-items: flex-start;
    gap: ${dt('dimension.space.200')};
  }

  /* Лейбл слева выравниваем по высоте поля, а не по центру всего body с caption */
  .extra-select--left > .extra-select-label {
    padding-block: calc(${dt('select.root.paddingY')} + ${dt('select.extend.borderWidth')});
  }

  .extra-select-body {
    display: flex;
    flex-direction: column;
    gap: ${dt('dimension.space.100')};
    min-width: 0;
  }

  /* В режиме left body забирает остаток строки — иначе полю некуда растягиваться */
  .extra-select--left > .extra-select-body {
    flex: 1 1 auto;
  }

  /* ─── Label ─── */
  .extra-select-label {
    display: inline-flex;
    align-items: center;
    gap: ${dt('dimension.space.100')};
    color: ${dt('color.fg.default')};
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.300')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.300')};
    cursor: pointer;
  }

  .extra-select-label-icon {
    color: ${dt('color.fg.subtle')};
    font-size: ${dt('select.extend.iconSize')};
    cursor: help;
  }

  /* ─── Caption ─── */
  .extra-select-caption {
    color: ${dt('color.fg.subtle')};
    font-family: ${dt('fonts.fontFamily.heading')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
  }

  /* Внутри p-floatlabel лейбл лежит поверх поля — курсор должен быть как у поля */
  .extra-select-body > .p-floatlabel > .extra-select-label {
    cursor: pointer;
  }

  .p-select.p-component {
    width: 100%;
    border-width: ${dt('select.extend.borderWidth')};
    line-height: ${dt('fonts.lineHeight.250')};

    /* select.dropdown.width приходит из DS как {dimension.size.1700} = 17rem (272px):
       зона chevron съедает почти всю строку и выдавливает подпись поля в многоточие,
       а .p-select-clear-icon позиционируется от этой же переменной и уезжает к середине.
       Переопределяем саму переменную — за ней следуют обе точки использования. */
    --p-select-dropdown-width: calc(${dt('select.root.paddingX')} * 2 + ${dt('select.extend.iconSize')});
  }

  .p-select.p-component.p-select-xlg {
    --p-select-dropdown-width: calc(${dt('select.extend.extXlg.paddingX')} * 2 + ${dt('select.extend.iconSize')});
  }

  .p-select.p-component .p-select-label,
  .p-select-option {
    font-family: ${dt('fonts.fontFamily.base')};
  }

  .p-select-option {
    background: ${dt('select.extend.extOption.background')};
    gap: ${dt('select.extend.extOption.gap')};
  }

  .p-select-option-group {
    gap: ${dt('select.extend.extOptionGroup.gap')};
  }

  .p-select.p-component:not(.p-disabled).p-focus {
    box-shadow: 0 0 0 ${dt('select.root.focusRing.width')} ${dt('select.root.focusRing.color')};
  }

  .p-select.p-component.p-invalid.p-focus {
    border-color: ${dt('select.root.invalidBorderColor')};
    box-shadow: 0 0 0 ${dt('select.root.focusRing.width')} ${dt('color.bg.status.danger.weak.active')};
  }

  .p-select.p-component[readonly] {
    background: ${dt('select.extend.readonlyBackground')};
    border-color: ${dt('select.root.borderColor')};
    color: ${dt('select.root.color')};
    cursor: default;
    pointer-events: none;
  }

  .p-select.p-component[readonly] :is(.p-select-dropdown .p-select-dropdown-icon, .p-select-clear-icon) {
    color: ${dt('select.root.placeholderColor')};
  }

  /* Размер xlg берём из собственных токенов селекта: переменные --p-inputtext-*
     эмитятся, только если на странице отрисован компонент семейства InputText,
     и на экране с одним селектом поле схлопывалось до нулевых паддингов. */
  .p-select.p-component.p-select-xlg .p-select-label {
    font-size: ${dt('select.extend.extXlg.fontSize')};
    padding-block: ${dt('select.extend.extXlg.paddingY')};
    padding-inline: ${dt('select.extend.extXlg.paddingX')};
  }

  .p-floatlabel:has(.p-select.p-component) label {
    font-family: ${dt('fonts.fontFamily.base')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
    color: ${dt('color.bg.neutral.medium.strong')};
  }

  .p-floatlabel:has(.p-select.p-component) .p-floatlabel-active label {
    font-weight: ${dt('fonts.fontWeight.regular')};
  }

  .p-floatlabel-in .p-select.p-component .p-select-label {
    font-family: ${dt('fonts.fontFamily.base')};
    padding-block-start: ${dt('dimension.space.700')};
    padding-block-end: ${dt('dimension.space.300')};
  }

  .p-select-option:has(.p-select-option-check-icon) {
    background: ${dt('select.option.selectedBackground')};
    color: ${dt('select.option.selectedColor')};
  }

  .p-select-option:has(.p-select-option-check-icon).p-focus {
    background: ${dt('select.option.selectedFocusBackground')};
    color: ${dt('select.option.selectedFocusColor')};
  }

  .p-select-option .p-select-option-check-icon,
  .p-select-option .p-select-option-blank-icon {
    display: none;
  }

  .p-select-option:has(.p-select-option-check-icon)::before,
  .p-select-option:has(.p-select-option-blank-icon)::before {
    font-family: 'tabler-icons';
    content: var(--p-select-checkmark-content, "\\ea5e");
    font-size: ${dt('select.extend.iconSize')};
    color: ${dt('select.option.selectedColor')};
    flex-shrink: 0;
    margin-inline-start: ${dt('select.checkmark.gutterStart')};
    margin-inline-end: ${dt('select.checkmark.gutterEnd')};
  }

  .p-select-option:has(.p-select-option-check-icon).p-focus::before {
    color: ${dt('select.option.focusColor')};
  }

  .p-select-option:has(.p-select-option-blank-icon)::before {
    visibility: hidden;
  }

  .p-select.p-component :is(.p-select-dropdown .p-select-dropdown-icon, .p-select-clear-icon, .p-select-loading-icon) {
    font-size: ${dt('select.extend.iconSize')};
    width: ${dt('select.extend.iconSize')};
    height: ${dt('select.extend.iconSize')};
    color: ${dt('select.root.placeholderColor')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-message.
 * Подключается в map-tokens.ts: `import { messageCss } from './tokens/components/message'`
 */
const messageCss = ({ dt }) => `
  /* Основной контейнер message: ширина по размеру (base по умолчанию) */
  .p-message {
    width: ${dt('message.extend.overlayWidth.base')};
    overflow: hidden;
    position: relative;
  }

  .p-message.p-message-size-small {
    width: ${dt('message.extend.overlayWidth.small')};
  }

  .p-message.p-message-size-large {
    width: ${dt('message.extend.overlayWidth.large')};
  }

  .p-message.p-message-size-xlarge {
    width: ${dt('message.extend.overlayWidth.xlarge')};
  }

  /* fill — сообщение занимает всю ширину контейнера */
  .p-message.p-message-size-fill {
    width: 100%;
  }

  /* Контент message с приоритизацией align-items */
  .p-message .p-message-content {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    width: stretch;
    border-radius: ${dt('message.root.borderRadius')};
  }

  /* Футер message: строка под основным контентом */
  .p-message .p-message-footer {
    flex-basis: 100%;
    display: flex;
    align-items: center;
    gap: ${dt('message.extend.extText.gap')};
  }

  /* Текстовый блок message */
  .p-message-text {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: ${dt('message.extend.extText.gap')};
  }

  /* Заголовок message */
  .p-message-summary {
    font-family: ${dt('fonts.fontFamily.base')};
    font-weight: ${dt('message.text.fontWeight')};
    line-height: ${dt('fonts.lineHeight.250')};
    font-size: ${dt('message.text.fontSize')};
  }

  /* Детальное описание message */
  .p-message .p-message-detail {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    line-height: ${dt('fonts.lineHeight.250')};
    font-weight: ${dt('fonts.fontWeight.regular')};
  }

  /* Кнопка закрытия message */
  .p-message .p-message-content .p-message-close-button {
    width: ${dt('message.closeButton.width')};
    height: ${dt('message.closeButton.height')};
    margin: 0;
    padding: 0;
    right: 0;
  }

  /* Общие стили border для кнопки закрытия всех типов message */
  .p-message-info .p-message-close-button,
  .p-message-success .p-message-close-button,
  .p-message-warn .p-message-close-button,
  .p-message-error .p-message-close-button {
    border: ${dt('message.extend.extCloseButton.width')} solid;
  }

  /* Общие стили для акцентной линии всех типов message */
  .p-message-info .p-message-accent-line,
  .p-message-success .p-message-accent-line,
  .p-message-warn .p-message-accent-line,
  .p-message-error .p-message-accent-line {
    width: ${dt('message.extend.extAccentLine.width')};
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    border-radius: ${dt('message.root.borderRadius')} 0 0 ${dt('message.root.borderRadius')};
  }

  /* Стили для message типа Info */
  .p-message-info .p-message-icon {
    color: ${dt('message.extend.extInfo.color')};
  }

  .p-message-info .p-message-close-button {
    color: ${dt('message.extend.extInfo.closeButton.color')};
    border-color: ${dt('message.extend.extInfo.closeButton.borderColor')};
  }

  .p-message.p-message-info .p-message-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('message.colorScheme.light.info.closeButton.hoverBackground')};
    border-color: ${dt('message.extend.extInfo.closeButton.borderColor')};
    color: ${dt('message.extend.extInfo.closeButton.color')};
  }

  .p-message-info .p-message-accent-line {
    background: ${dt('message.extend.extInfo.color')};
  }

  /* Стили для message типа Success */
  .p-message-success .p-message-icon {
    color: ${dt('message.extend.extSuccess.color')};
  }

  .p-message-success .p-message-close-button {
    color: ${dt('message.extend.extSuccess.closeButton.color')};
    border-color: ${dt('message.extend.extSuccess.closeButton.borderColor')};
  }

  .p-message.p-message-success .p-message-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('message.colorScheme.light.success.closeButton.hoverBackground')};
    border-color: ${dt('message.extend.extSuccess.closeButton.borderColor')};
    color: ${dt('message.extend.extSuccess.closeButton.color')};
  }

  .p-message-success .p-message-accent-line {
    background: ${dt('message.extend.extSuccess.color')};
  }

  /* Стили для message типа Warn */
  .p-message-warn .p-message-icon {
    color: ${dt('message.extend.extWarn.color')};
  }

  .p-message-warn .p-message-close-button {
    color: ${dt('message.extend.extWarn.closeButton.color')};
    border-color: ${dt('message.extend.extWarn.closeButton.borderColor')};
  }

  .p-message.p-message-warn .p-message-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('message.colorScheme.light.warn.closeButton.hoverBackground')};
    border-color: ${dt('message.extend.extWarn.closeButton.borderColor')};
    color: ${dt('message.extend.extWarn.closeButton.color')};
  }

  .p-message-warn .p-message-accent-line {
    background: ${dt('message.extend.extWarn.color')};
  }

  /* Стили для message типа Error */
  .p-message-error .p-message-icon {
    color: ${dt('message.extend.extError.color')};
  }

  .p-message-error .p-message-close-button {
    color: ${dt('message.extend.extError.closeButton.color')};
    border-color: ${dt('message.extend.extError.closeButton.borderColor')};
  }

  .p-message.p-message-error .p-message-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('message.colorScheme.light.error.closeButton.hoverBackground')};
    border-color: ${dt('message.extend.extError.closeButton.borderColor')};
    color: ${dt('message.extend.extError.closeButton.color')};
  }

  .p-message-error .p-message-accent-line {
    background: ${dt('message.extend.extError.color')};
  }

  /* Цвет подписи по типам: дизайн задаёт его отдельно от цвета акцента */
  .p-message-info .p-message-detail {
    color: ${dt('message.extend.extInfo.caption.color')};
  }
  .p-message-success .p-message-detail {
    color: ${dt('message.extend.extSuccess.caption.color')};
  }
  .p-message-warn .p-message-detail {
    color: ${dt('message.extend.extWarn.caption.color')};
  }
  .p-message-error .p-message-detail {
    color: ${dt('message.extend.extError.caption.color')};
  }
`;

const inputotpCss = ({ dt }) => `
/* Стили границы */
.p-inputotp.p-component .p-inputtext {
  border-width: ${dt('inputotp.extend.borderWidth')};
  padding-inline: 0;
}

/* ─── Disabled ─── */
.p-inputotp.p-component .p-inputtext:disabled {
  background: ${dt('inputtext.root.disabledBackground')};
  color: ${dt('inputtext.root.disabledColor')};
}

/* ─── Readonly ─── */
.p-inputotp.p-component .p-inputtext:enabled:read-only {
  background: ${dt('inputtext.extend.readonlyBackground')};
  color: ${dt('inputtext.root.color')};
}

/* ─── Focus ─── */
.p-inputotp.p-component .p-inputtext:enabled:focus {
  box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('inputtext.root.focusRing.color')};
}

/* ─── Invalid + Focus ─── */
.p-inputotp.p-component .p-inputtext.p-invalid:focus {
  border-color: ${dt('inputtext.root.invalidBorderColor')};
  box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('color.border.status.danger.focus')};
}

/* ─── Small ─── */
.p-inputotp.p-component .p-inputtext.p-inputtext-sm {
  height: ${dt('inputotp.extend.extSm.height')};
  /* радиус inputtext (14px) на ячейке 28px смыкается в круг — для sm свой */
  border-radius: ${dt('inputotp.extend.extSm.borderRadius')};
  padding-block: ${dt('inputtext.root.sm.paddingY')};
}

/* ─── Base ─── */
.p-inputotp.p-component .p-inputtext:not(.p-inputtext-sm):not(.p-inputtext-lg):not(.p-inputtext-xlg) {
  height: ${dt('inputotp.extend.height')};
  padding-block: ${dt('inputtext.root.paddingY')};
}

/* ─── Large ─── */
.p-inputotp.p-component .p-inputtext.p-inputtext-lg {
  height: ${dt('inputotp.extend.extLg.height')};
  padding-block: ${dt('inputtext.root.lg.paddingY')};
}

/* ─── Extra Large ─── */
.p-inputotp.p-component.p-inputotp-xlg .p-inputtext {
  font-size: ${dt('inputtext.extend.extXlg.fontSize')};
  padding-block: ${dt('inputtext.extend.extXlg.paddingY')};
}
`;

const carouselCss = ({ dt }) => `
  .p-carousel .p-carousel-prev-button.p-button-secondary,
  .p-carousel .p-carousel-next-button.p-button-secondary {
    background: ${dt('color.bg.neutral.weak.disabled')};
    color: ${dt('color.fg.default')};
    border-color: transparent;
  }

  .p-carousel .p-carousel-prev-button.p-button-secondary:not(:disabled):hover,
  .p-carousel .p-carousel-next-button.p-button-secondary:not(:disabled):hover {
    background: ${dt('color.fg.muted')};
    color: ${dt('color.fg.default')};
  }

  .p-carousel .p-carousel-prev-button.p-button-secondary:not(:disabled):active,
  .p-carousel .p-carousel-next-button.p-button-secondary:not(:disabled):active {
    background: ${dt('color.fg.subtle')};
    color: ${dt('color.fg.default')};
  }

  .p-carousel .p-button-icon-only.p-button-rounded {
    border-radius: ${dt('button.root.roundedBorderRadius')};
  }

  .p-carousel .p-carousel-item {
    padding-inline: calc(${dt('carousel.content.gap')} / 2);
  }

  /* Убираем visibility:hidden для неактивных слайдов.
     Отсечение за пределами viewport обеспечивается через overflow:hidden на контейнере карточки. */
  .p-carousel .p-items-hidden .p-carousel-item {
    visibility: visible;
  }
`;

const galleriaCss = ({ dt }) => `
.p-galleria .p-galleria-caption {
  background: ${dt('galleria.caption.background')};
  padding: ${dt('dimension.space.200')};
}

.p-galleria-thumbnails-content {
  background: ${dt('galleria.thumbnailContent.background')};
}

.p-galleria-mask.p-overlay-mask {
  background: ${dt('galleria.extend.backdrop')};
}

.p-galleria-mask.p-overlay-mask .p-galleria-nav-button {
  top: 0;
}

.p-galleria-mask.p-overlay-mask .p-galleria-items .p-galleria-nav-button {
  top: 50%;
}
`;

const confirmDialogCss = ({ dt }) => `
  /* Иконка в заголовке */
  .p-confirmdialog .p-dialog-title {
    display: flex;
    align-items: center;
    gap: ${dt('dialog.header.gap')};
  }

  .p-confirmdialog .p-dialog-title i {
    width: ${dt('confirmdialog.icon.size')};
    height: ${dt('confirmdialog.icon.size')};
    font-size: ${dt('confirmdialog.icon.size')};
    flex-shrink: 0;
  }

  /* Размеры */
  .p-confirmdialog.p-dialog {
    width: ${dt('confirmdialog.extend.dimension_overlayWidth_base')};
  }

  .p-confirmdialog-sm.p-dialog {
    width: ${dt('confirmdialog.extend.dimension_overlayWidth_sm')};
  }

  .p-confirmdialog-lg.p-dialog {
    width: ${dt('confirmdialog.extend.dimension_overlayWidth_lg')};
  }

  .p-confirmdialog-xlg.p-dialog {
    width: ${dt('confirmdialog.extend.dimension_overlayWidth_xlg')};
  }

  /* Цвета иконок по severity */
  .p-confirmdialog[data-pc-severity="success"] .p-dialog-title i,
  .p-confirmdialog.p-confirm-dialog-accept .p-dialog-title i {
    color: ${dt('confirmdialog.extend.extIcon.success')};
  }

  .p-confirmdialog[data-pc-severity="info"] .p-dialog-title i,
  .p-confirmdialog.p-confirm-dialog-info .p-dialog-title i {
    color: ${dt('confirmdialog.extend.extIcon.info')};
  }

  .p-confirmdialog[data-pc-severity="warn"] .p-dialog-title i,
  .p-confirmdialog.p-confirm-dialog-warn .p-dialog-title i {
    color: ${dt('confirmdialog.extend.extIcon.warn')};
  }

  .p-confirmdialog[data-pc-severity="help"] .p-dialog-title i,
  .p-confirmdialog.p-confirm-dialog-help .p-dialog-title i {
    color: ${dt('confirmdialog.extend.extIcon.help')};
  }

  .p-confirmdialog[data-pc-severity="danger"] .p-dialog-title i,
  .p-confirmdialog[data-pc-severity="error"] .p-dialog-title i,
  .p-confirmdialog.p-confirm-dialog-error .p-dialog-title i {
    color: ${dt('confirmdialog.extend.extIcon.danger')};
  }
`;

const drawerCss = ({ dt }) => `
.p-drawer-mask.p-overlay-mask {
  background: ${dt('drawer.extend.backdrop')};
}

.p-drawer.p-component {
  border-radius: ${dt('drawer.extend.borderRadius')};
}

.p-drawer.p-component .p-drawer-header {
  border-bottom: ${dt('drawer.extend.borderWidth')} solid ${dt('drawer.extend.extHeader.borderColor')};
  padding: ${dt('dimension.space.600')} ${dt('dimension.space.600')} ${dt('dimension.space.400')} ${dt('dimension.space.600')};
}

.p-drawer.p-component .p-drawer-title {
  font-weight: ${dt('drawer.title.fontWeight')};
  font-size: ${dt('drawer.title.fontSize')};
}

.p-drawer.p-component .p-drawer-header-actions {
  gap: ${dt('drawer.extend.extHeader.gap')};
}

.p-drawer.p-component .p-drawer-content {
  padding: ${dt('dimension.space.600')};
}

.p-drawer.p-component .p-drawer-footer {
  padding: 0 ${dt('dimension.space.600')} ${dt('dimension.space.600')} ${dt('dimension.space.600')};
}

/* Ширина панели по размерам: drawer.extend.overlayWidth — ступени семантической шкалы
   dimension.size (макет просит 280 / 350 / 420 / 630, ближайшие ступени дают 272 / 336 / 400 / 630) */
.p-drawer.p-component.p-drawer-left,
.p-drawer.p-component.p-drawer-right {
  margin: ${dt('drawer.extend.margin')};
  width: ${dt('drawer.extend.overlayWidth.base')};
  height: calc(100% - ${dt('drawer.extend.margin')} * 2);
}

.p-drawer.p-component.p-drawer-left.p-drawer-sm,
.p-drawer.p-component.p-drawer-right.p-drawer-sm {
  width: ${dt('drawer.extend.overlayWidth.sm')};
}

.p-drawer.p-component.p-drawer-left.p-drawer-lg,
.p-drawer.p-component.p-drawer-right.p-drawer-lg {
  width: ${dt('drawer.extend.overlayWidth.lg')};
}

.p-drawer.p-component.p-drawer-left.p-drawer-xlg,
.p-drawer.p-component.p-drawer-right.p-drawer-xlg {
  width: ${dt('drawer.extend.overlayWidth.xlg')};
}

.p-drawer.p-component.p-drawer-top,
.p-drawer.p-component.p-drawer-bottom {
  margin: ${dt('drawer.extend.margin')};
  width: calc(100% - ${dt('drawer.extend.margin')} * 2);
}

.p-drawer.p-component.p-drawer-full,
.p-drawer.p-component.p-drawer-full.p-drawer-sm,
.p-drawer.p-component.p-drawer-full.p-drawer-lg,
.p-drawer.p-component.p-drawer-full.p-drawer-xlg {
  margin: 0;
  width: 100%;
  height: 100%;
}

`;

/**
 * Кастомная CSS-стилизация для компонента p-datepicker.
 * Подключается в map-tokens.ts: `import { datePickerCss } from './components/date-picker'`
 */
const datePickerCss = ({ dt }) => `

.p-datepicker.p-datepicker {
  display: inline-flex;
  position: relative;
  max-width: fit-content;
}

.p-datepicker-panel.p-datepicker-panel {
  box-shadow: ${dt('datepicker.panel.shadow')};
  overflow: hidden;
}

/* Скрываем нативный заголовок с кнопками выбора месяца/года;
   кастомный заголовок (pTemplate="header") рендерится вне .p-datepicker-calendar */
.p-datepicker-calendar .p-datepicker-header {
  display: none;
}

.p-datepicker-custom-header.p-datepicker-header {
  gap: ${dt('datepicker.title.gap')};
  padding: ${dt('datepicker.header.padding')};
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.p-datepicker-day-selected:not(.p-disabled):hover {
  background: ${dt('datepicker.extend.extDate.selectedHoverBackground')};
}

.p-datepicker-title {
  display: flex;
  align-items: center;
  gap: ${dt('datepicker.title.gap')};
  min-width: ${dt('datepicker.extend.extTitle.width')};
  margin: 0 auto;
}

.p-datepicker-year-select {
  min-width: ${dt('dimension.size.1000')};
}

.p-datepicker-custom-header .p-button.p-button {
  width: ${dt('datepicker.dropdown.width')};
  height: ${dt('datepicker.dropdown.width')};
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.p-datepicker-today.p-datepicker-today > .p-datepicker-day:not(.p-datepicker-day-selected) {
  border: ${dt('dimension.size.100')} solid ${dt('datepicker.extend.extToday.borderColor')};
}

.p-datepicker-today.p-datepicker-today:hover > .p-datepicker-day:not(.p-datepicker-day-selected),
.p-datepicker-day-preview.p-datepicker-day-preview:not(.p-datepicker-day-selected) {
  background: ${dt('datepicker.extend.extToday.hoverBackground')};
}

.p-datepicker-day-preview.p-datepicker-day-preview:not(.p-datepicker-day-selected) {
  color: ${dt('datepicker.date.color')};
}

.p-datepicker-day-view.p-datepicker-day-view {
  width: stretch;
  border-collapse: separate;
  table-layout: auto;
  margin: ${dt('datepicker.dayView.margin')};
}

.p-datepicker-weekday {
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.demibold')};
}

.p-datepicker-day {
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.regular')};
}

.p-datepicker-time-picker.p-datepicker-time-picker:not(.p-datepicker-time-picker-custom) {
  display: none;
}

.p-datepicker-buttonbar.p-datepicker-buttonbar .p-button.p-button {
  background: transparent;
  color: ${dt('button.colorScheme.light.text.primary.color')};
  border: 0 none;
  font-family: ${dt('fonts.fontFamily.heading')};
  font-weight: ${dt('button.root.label.fontWeight')};
  transition: background-color ${dt('button.root.transitionDuration')};
}

.p-datepicker-buttonbar.p-datepicker-buttonbar .p-button.p-button:not(:disabled):hover {
  background: ${dt('button.colorScheme.light.text.primary.hoverBackground')};
  color: ${dt('button.colorScheme.light.text.primary.color')};
}

.p-datepicker-buttonbar.p-datepicker-buttonbar .p-button.p-button:not(:disabled):active {
  background: ${dt('button.colorScheme.light.text.primary.activeBackground')};
  color: ${dt('button.colorScheme.light.text.primary.color')};
}

.p-datepicker-clear-icon {
  display: flex;
  align-items: center;
  inset-inline-end: ${dt('inputtext.root.paddingX')};
  color: ${dt('datepicker.inputIcon.color')};
}

.p-datepicker:has(.p-datepicker-input-icon-container) .p-datepicker-clear-icon {
  inset-inline-end: calc((${dt('inputtext.root.paddingX')} * 1.5) + ${dt('inputtext.extend.iconSize')});
}

.p-datepicker:has(.p-inputtext-lg) .p-datepicker-dropdown .p-icon,
.p-datepicker:has(.p-inputtext-lg) .p-datepicker-input-icon,
.p-datepicker:has(.p-inputtext-lg) .p-datepicker-clear-icon .ti-x {
  font-size: ${dt('inputtext.root.lg.fontSize')};
  width: ${dt('inputtext.root.lg.fontSize')};
  height: ${dt('inputtext.root.lg.fontSize')};
}

.p-datepicker.p-datepicker:not(.p-inputwrapper-filled) .p-datepicker-clear-icon,
.p-datepicker.p-datepicker:has(.p-datepicker-input:placeholder-shown) .p-datepicker-clear-icon {
  display: none;
}

.p-datepicker-time-picker-custom.p-datepicker-time-picker-custom {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${dt('datepicker.timePicker.gap')};
  padding: ${dt('datepicker.timePicker.padding')};
  border-top: ${dt('dimension.size.100')} solid ${dt('datepicker.panel.borderColor')};
}

.p-datepicker-time-picker-custom .p-datepicker-time-field {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: ${dt('datepicker.timePicker.buttonGap')};
  width: auto;
}

.p-datepicker-time-picker-custom .p-datepicker-time-label {
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.100')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: 1;
  color: ${dt('datepicker.extend.extTimePicker.color')};
}

.p-datepicker-time-picker-custom .p-inputnumber,
.p-datepicker-time-picker-custom .p-datepicker-time-input.p-datepicker-time-input {
  width: ${dt('datepicker.extend.extTimePicker.minWidth')};
  text-align: center;
}

.p-datepicker-time-picker-custom .p-datepicker-separator {
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.100')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: 1;
  color: ${dt('datepicker.extend.extTimePicker.color')};
  margin-top: calc(${dt('fonts.fontSize.100')} + ${dt('datepicker.timePicker.buttonGap')});
}

:is(.p-datepicker-month-select, .p-datepicker-year-select) .p-select-dropdown {
  color: ${dt('datepicker.inputIcon.color')};
}

:is(.p-datepicker-month-select, .p-datepicker-year-select) .p-select-label {
  width: ${dt('dimension.size.1000')};
}

`;

/**
 * Кастомная CSS-стилизация для компонента p-accordion.
 * Подключается в map-tokens.ts: `import { accordionCss } from './tokens/components/accordion'`
 */
const accordionCss = ({ dt }) => `
  /* ─── Шрифт заголовка ─── */
  .p-accordionheader {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.300')};
  }

  /* ─── Размер иконки toggle ─── */
  .p-accordionheader-toggle-icon,
  .p-accordionpanel:not(.p-disabled).p-accordionpanel-active > .p-accordionheader .p-accordionheader-toggle-icon {
    width: ${dt('accordion.extend.extHeader.iconSize')};
    height: ${dt('accordion.extend.extHeader.iconSize')};
  }

  /* ─── Лэйаут заголовка: иконка + текст ─── */
  .p-accordionheader > div {
    display: flex;
    align-items: center;
    gap: ${dt('accordion.extend.extHeader.gap')};
  }

  /* ─── Размер иконки в заголовке ─── */
  .p-accordionheader > div > i {
    font-size: ${dt('accordion.extend.extHeader.iconSize')};
  }
`;

const badgeCss = ({ dt }) => `
.p-badge.p-component {
  font-family: ${dt('fonts.fontFamily.heading')};
  line-height: ${dt('fonts.lineHeight.350')};
}

.p-badge.p-badge-dot {
  padding: ${dt('badge.extend.ext.padding')};
}

.p-badge.p-badge-dot.p-badge-success {
  background: ${dt('badge.extend.extDot.success.background')};
}

.p-badge.p-badge-dot.p-badge-info {
  background: ${dt('badge.extend.extDot.info.background')};
}

.p-badge.p-badge-dot.p-badge-warn {
  background: ${dt('badge.extend.extDot.warn.background')};
}

.p-badge.p-badge-dot.p-badge-danger {
  background: ${dt('badge.extend.extDot.danger.background')};
}

.p-badge.p-badge-dot.p-badge-lg {
  min-width: unset;
  width: ${dt('badge.extend.extDot.lg.size')};
  height: ${dt('badge.extend.extDot.lg.size')};
}

.p-badge.p-badge-dot.p-badge-xl {
  min-width: unset;
  width: ${dt('badge.extend.extDot.xlg.size')};
  height: ${dt('badge.extend.extDot.xlg.size')};
}
`;

const chipCss = ({ dt }) => `
.p-chip {
  border: ${dt('chip.extend.borderWidth')} solid ${dt('chip.extend.borderColor')};
}

.p-chip-icon {
  font-size: ${dt('chip.icon.size')};
}

.p-chip-label {
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.none')};
}

.p-chip:has(.p-chip-remove-icon) {
  padding-inline-end: ${dt('chip.root.paddingX')};
}

.p-chip-remove-icon:focus-visible {
  outline: ${dt('chip.removeIcon.focusRing.width')} solid ${dt('chip.removeIcon.focusRing.color')};
}

.p-chip.p-disabled {
  opacity: ${dt('effects.opacity.50')};
  pointer-events: none;
}

.p-chip.p-disabled .p-chip-remove-icon {
  pointer-events: none;
}
`;

const dataTableCss = ({ dt }) => `
  .p-datatable .p-datatable-thead > tr > th {
    font-weight: ${dt('datatable.columnTitle.fontWeight')};
  }

  .p-datatable .p-datatable-tfoot > tr > td {
    font-weight: ${dt('datatable.columnFooter.fontWeight')};
  }

  .p-datatable .p-datatable-sort-icon {
    width: ${dt('datatable.sortIcon.size')};
    height: ${dt('datatable.sortIcon.size')};
  }

  .p-datatable .p-datatable-loading-icon {
    width: ${dt('datatable.loadingIcon.size')};
    height: ${dt('datatable.loadingIcon.size')};
  }

  .p-datatable .p-datatable-row-toggle-button {
    width: ${dt('datatable.rowToggleButton.size')};
    height: ${dt('datatable.rowToggleButton.size')};
  }

  .p-datatable .p-datatable-sortable-column:not(.p-datatable-column-sorted):hover {
    color: ${dt('color.fg.hover')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-dialog.
 * Подключается в map-tokens.ts: `import { dialogCss } from './tokens/components/dialog'`
 *
 * Радиусы, отступы, фон и тень приходят токенами пресета (dialog.root.*, dialog.header.* и т.д.).
 * Здесь — типографика и то, что Aura зашила сырыми значениями: рамка окна и фон подложки.
 */
const dialogCss = ({ dt }) => `
  .p-dialog .p-dialog-title {
    font-family: ${dt('fonts.fontFamily.heading')};
    font-size: ${dt('dialog.title.fontSize')};
    font-weight: ${dt('dialog.title.fontWeight')};
    line-height: ${dt('fonts.lineHeight.550')};
  }

  .p-dialog .p-dialog-content {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.300')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.500')};
  }

  .p-dialog .p-dialog-header {
    border-bottom: ${dt('dialog.extend.borderWidth')} solid ${dt('dialog.root.borderColor')};
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .p-dialog .p-dialog-header-actions {
    display: flex;
    align-items: center;
    margin-left: auto;
  }

  .p-dialog .p-dialog-header-actions .p-dialog-close-button.p-button-text:focus-visible,
  .p-dialog .p-dialog-header-actions .p-dialog-close-button.p-button:focus-visible,
  .p-dialog .p-button-text:focus-visible,
  .p-dialog .p-button:focus-visible {
    outline: 0 none;
    outline-color: transparent;
    box-shadow: none;
  }

  /* Рамка окна: Aura зашивает её сырым 1px, дизайн задаёт токеном.
     Ширина по умолчанию — base; в экспорте нет ветки overlayWidth, поэтому значения
     берём с той же ступени примитивов, что рисует Figma (overlay/width: 280 / 350 / 420 / 630) */
  .p-dialog {
    border: ${dt('dialog.extend.borderWidth')} solid ${dt('dialog.root.borderColor')};
    width: ${dt('sizing.175x')};
  }

  /* Подложка: Aura держит свой цвет анимацией появления (fill-mode: forwards),
     поэтому одного правила background мало — переопределяем саму анимацию маски диалога */
  .p-dialog-mask.p-overlay-mask {
    background: ${dt('dialog.extend.backdrop')};
  }

  .p-dialog-mask.p-overlay-mask-enter {
    animation-name: p-dialog-mask-enter;
  }

  .p-dialog-mask.p-overlay-mask-leave {
    animation-name: p-dialog-mask-leave;
  }

  @keyframes p-dialog-mask-enter {
    from {
      background: transparent;
    }
    to {
      background: ${dt('dialog.extend.backdrop')};
    }
  }

  @keyframes p-dialog-mask-leave {
    from {
      background: ${dt('dialog.extend.backdrop')};
    }
    to {
      background: transparent;
    }
  }

  .p-dialog.p-component.p-dialog-sm {
    width: ${dt('sizing.140x')};
  }

  .p-dialog.p-component.p-dialog-lg {
    width: ${dt('sizing.210x')};
  }

  .p-dialog.p-component.p-dialog-xlg {
    width: ${dt('sizing.315x')};
  }
`;

const dividerCss = ({ dt }) => `
.p-divider-content {
  display: flex;
  align-items: center;
  gap: ${dt('divider.extend.content.gap')};
  background: ${dt('color.bg.surface.default.default')};
  color: ${dt('color.fg.default')};
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.demibold')};
  line-height: ${dt('fonts.lineHeight.350')};
  letter-spacing: ${dt('fonts.letterSpacing.500')};
  text-transform: uppercase;
}

.p-divider-content .ti {
  font-size: ${dt('divider.extend.iconSize')};
}

.p-divider.p-divider-vertical.p-divider-top .p-divider-content {
  align-items: flex-start;
}

.p-divider.p-divider-vertical.p-divider-bottom .p-divider-content {
  align-items: flex-end;
}
`;

const inputnumberCss = ({ dt }) => `
.p-inputnumber .p-inputnumber-input {
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-inputnumber .p-inputnumber-input::placeholder {
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-floatlabel:has(.p-inputnumber) label {
  font-family: ${dt('fonts.fontFamily.base')};
}

.p-inputnumber-button {
  border-width: ${dt('inputnumber.extend.borderWidth')};
}

.p-inputnumber-horizontal .p-inputnumber-button {
  min-height: ${dt('inputnumber.extend.extButton.height')};
  border: ${dt('inputnumber.extend.borderWidth')} solid ${dt('inputnumber.button.borderColor')};
}

.p-inputnumber-horizontal .p-inputnumber-decrement-button {
  border-right: none;
}

.p-inputnumber-button .p-icon,
.p-inputnumber-button [class*='ti-'] {
  font-size: ${dt('inputnumber.extend.extButton.iconSize')};
  width: ${dt('inputnumber.extend.extButton.iconSize')};
  height: ${dt('inputnumber.extend.extButton.iconSize')};
}

.p-inputnumber .p-inputnumber-input:enabled:focus {
  box-shadow: 0 0 0 ${dt('inputtext.root.focusRing.width')} ${dt('inputtext.root.focusRing.color')};
}

.p-inputnumber.p-invalid .p-inputnumber-input:focus {
  border-color: ${dt('inputtext.root.invalidBorderColor')};
  box-shadow: 0 0 0 ${dt('inputnumber.extend.borderWidth')} ${dt('inputtext.root.invalidBorderColor')};
}

.p-inputnumber-horizontal:has(.p-inputnumber-input:disabled) .p-inputnumber-button {
  background: ${dt('inputtext.root.disabledBackground')};
  color: ${dt('inputtext.root.disabledColor')};
}

.p-floatlabel:has(.p-inputnumber-horizontal) .p-inputnumber-button {
  align-self: stretch;
}

.p-inputnumber.p-inputnumber-xlg .p-inputnumber-input {
  font-size: ${dt('inputtext.extend.extXlg.fontSize')};
  padding: ${dt('inputtext.extend.extXlg.paddingY')} ${dt('inputtext.extend.extXlg.paddingX')};
}
`;

const listboxCss = ({ dt }) => `
.p-listbox-option {
  display: flex;
  align-items: center;
  gap: ${dt('listbox.extend.extOption.gap')};
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.200')};
  line-height: ${dt('fonts.lineHeight.none')};
}

.p-listbox-option:has(.p-listbox-option-label-group) {
  align-items: flex-start;
}

.p-listbox-option:has(.p-listbox-option-check-icon) {
  gap: unset;
}

.p-listbox-option-label-group {
  display: flex;
  flex-direction: column;
  gap: ${dt('listbox.extend.extOption.label.gap')};
}

.p-listbox-option-caption {
  color: ${dt('listbox.extend.extOption.caption.color')};
  font-size: ${dt('fonts.fontSize.200')};
  font-family: ${dt('fonts.fontFamily.heading')};
}

.p-listbox-striped li:nth-child(even of .p-listbox-option) .p-listbox-option-caption {
  color: ${dt('listbox.extend.extOption.caption.stripedColor')};
}

.p-listbox-check-icon {
  margin-inline-start: ${dt('listbox.checkmark.gutterStart')};
  margin-inline-end: ${dt('listbox.checkmark.gutterEnd')};
}

.p-listbox .p-listbox-list .p-listbox-option.p-listbox-option-selected .p-listbox-option-check-icon {
  color: ${dt('listbox.option.selectedColor')};
}
`;

const menuCss = ({ dt }) => `
  .p-menu.p-component {
    padding: ${dt('menu.extend.paddingY')} ${dt('menu.extend.paddingX')};
  }

  .p-menu .p-menu-item-content .p-menu-item-link .p-menu-item-label {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.none')};
  }

  .p-menu .p-menu-item-content .p-menu-item-icon {
    font-size: ${dt('menu.extend.iconSize')};
  }

  .p-menu .p-menu-item-content .menu-item-label {
    display: flex;
    flex-direction: column;
    gap: ${dt('menu.extend.extItem.caption.gap')};
  }

  .p-menu .p-menu-item-content .menu-item-caption {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    color: ${dt('menu.extend.extItem.caption.color')};
  }

  /* Наведение на светлой поверхности — обычный пункт. */
  .p-menu .p-menu-item:not(.p-disabled):not(.p-menuitem-checked):not(.p-focus) .p-menu-item-content:hover,
  .p-menu .p-menu-item:not(.p-disabled):not(.p-menuitem-checked):not(.p-focus) .p-menu-item-content:hover .p-menu-item-link,
  .p-menu .p-menu-item:not(.p-disabled):not(.p-menuitem-checked):not(.p-focus) .p-menu-item-content:hover .p-menu-item-label,
  .p-menu .p-menu-item:not(.p-disabled):not(.p-menuitem-checked):not(.p-focus) .p-menu-item-content:hover .p-menu-item-icon {
    background: ${dt('color.bg.neutral.weak.hover')};
    color: ${dt('color.fg.default')};
  }

  .p-menu .p-menu-item.p-menuitem-checked > .p-menu-item-content,
  .p-menu .p-menu-item.p-focus > .p-menu-item-content {
    background: ${dt('menu.extend.extItem.activeBackground')};
    color: ${dt('menu.extend.extItem.activeColor')};
  }

  .p-menu .p-menu-item.p-menuitem-checked > .p-menu-item-content .p-menu-item-link,
  .p-menu .p-menu-item.p-menuitem-checked > .p-menu-item-content .p-menu-item-label,
  .p-menu .p-menu-item.p-focus > .p-menu-item-content .p-menu-item-link,
  .p-menu .p-menu-item.p-focus > .p-menu-item-content .p-menu-item-label {
    color: ${dt('menu.extend.extItem.activeColor')};
  }

  .p-menu .p-menu-item.p-menuitem-checked > .p-menu-item-content .p-menu-item-icon,
  .p-menu .p-menu-item.p-focus > .p-menu-item-content .p-menu-item-icon {
    color: ${dt('menu.extend.extItem.icon.activeColor')};
  }

  /*
   * Наведение на тёмной поверхности — выбранный или сфокусированный пункт. Ступень hover берётся
   * у той же поверхности, на которой пункт стоит: светлый weak.hover вернул бы ему вид обычного.
   * Текст не трогаем — он уже инверсный по правилам выше.
   */
  .p-menu .p-menu-item:not(.p-disabled).p-menuitem-checked > .p-menu-item-content:hover,
  .p-menu .p-menu-item:not(.p-disabled).p-focus > .p-menu-item-content:hover {
    background: ${dt('color.bg.neutral.strong.hover')};
  }

  /*
   * Нажатие. Меняется только фон — на ступень «active» той же поверхности, на которой пункт
   * уже стоит: невыбранный остаётся светлым, выбранный тёмным. Текст и иконка не трогаются,
   * иначе на невыбранном пункте они вспыхивали бы белым под тёмной подложкой.
   * .p-menu-list в цепочке поднимает специфичность выше правил наведения и выбора.
   * transition-duration: 0s гасит переход только на вдавливании: оттенок появляется мгновенно,
   * а на отпускании правило перестаёт совпадать и фон уходит по общему transition компонента.
   */
  .p-menu .p-menu-list .p-menu-item:not(.p-disabled):not(.p-menuitem-checked):not(.p-focus) > .p-menu-item-content:active {
    background: ${dt('color.bg.neutral.weak.active')};
    transition-duration: 0s;
  }

  .p-menu .p-menu-list .p-menu-item:not(.p-disabled).p-menuitem-checked > .p-menu-item-content:active,
  .p-menu .p-menu-list .p-menu-item:not(.p-disabled).p-focus > .p-menu-item-content:active {
    background: ${dt('color.bg.neutral.strong.active')};
    transition-duration: 0s;
  }

  .p-menu .p-menu-submenu-label {
    text-transform: uppercase;
    font-family: ${dt('fonts.fontFamily.heading')};
    font-size: ${dt('fonts.fontSize.100')};
    line-height: ${dt('fonts.lineHeight.none')};
  }
`;

const metergroupCss = ({ dt }) => `
  .p-metergroup-label-text {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
    color: ${dt('metergroup.extend.extLabel.color')};
  }
  .p-metergroup-label .p-metergroup-label-text + span {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.200')};
    font-weight: ${dt('fonts.fontWeight.medium')};
    color: ${dt('color.fg.default')};
  }
  .p-metergroup-horizontal .p-metergroup-meter { min-height: 100%; }
  .p-metergroup-vertical .p-metergroup-meter { min-width: 100%; }
`;

const paginatorCss = ({ dt }) => `
  /* ─── Current page report ─── */
  .p-paginator .p-paginator-current {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.300')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
    color: ${dt('paginator.currentPageReport.color')};
  }

  /* ─── Page number buttons ─── */
  .p-paginator .p-paginator-page {
    font-family: ${dt('fonts.fontFamily.base')};
    font-size: ${dt('fonts.fontSize.300')};
    font-weight: ${dt('fonts.fontWeight.regular')};
    line-height: ${dt('fonts.lineHeight.250')};
  }
`;

const panelmenuCss = ({ dt }) => `
  .p-panelmenu {
    gap: ${dt('panelmenu.extend.extPanel.gap')};
  }

  .p-panelmenu-panel {
    padding: ${dt('panelmenu.extend.extPanel.gap')};
  }

  .p-panelmenu-header-content,
  .p-panelmenu-item-content {
    font-size: ${dt('fonts.fontSize.300')};
  }

  .p-panelmenu-submenu-icon {
    font-size: ${dt('panelmenu.extend.iconSize')};
  }

  /* ─── Active & Focused States ─── */

  .p-panelmenu .p-panelmenu-item.p-panelmenu-item-active > .p-panelmenu-item-content,
  .p-panelmenu .p-panelmenu-item.p-focus > .p-panelmenu-item-content,
  .p-panelmenu .p-panelmenu-header.p-focus .p-panelmenu-header-content {
    background: ${dt('panelmenu.extend.extItem.activeBackground')};
    color: ${dt('panelmenu.extend.extItem.activeColor')};
  }

  .p-panelmenu .p-panelmenu-item.p-panelmenu-item-active > .p-panelmenu-item-content :is(.p-panelmenu-item-link, .p-panelmenu-item-label, .p-panelmenu-item-icon, .p-panelmenu-submenu-icon),
  .p-panelmenu .p-panelmenu-item.p-focus > .p-panelmenu-item-content :is(.p-panelmenu-item-link, .p-panelmenu-item-label, .p-panelmenu-item-icon, .p-panelmenu-header-icon, .p-panelmenu-submenu-icon),
  .p-panelmenu .p-panelmenu-header.p-focus .p-panelmenu-header-content :is(.p-panelmenu-header-link, .p-panelmenu-header-label, .p-panelmenu-submenu-icon, .p-panelmenu-item-icon, .p-panelmenu-header-icon) {
    color: ${dt('panelmenu.extend.extItem.activeColor')};
  }

  /* ─── Hover on Active States ─── */

  .p-panelmenu .p-panelmenu-item.p-panelmenu-item-active:not(.p-disabled) > .p-panelmenu-item-content:hover,
  .p-panelmenu .p-panelmenu-item.p-focus:not(.p-disabled) > .p-panelmenu-item-content:hover,
  .p-panelmenu .p-panelmenu-header.p-focus .p-panelmenu-header-content:hover {
    background: ${dt('panelmenu.item.focusBackground')};
    color: ${dt('panelmenu.item.focusColor')};
  }

  .p-panelmenu .p-panelmenu-item.p-panelmenu-item-active:not(.p-disabled) > .p-panelmenu-item-content:hover :is(.p-panelmenu-item-link, .p-panelmenu-item-label),
  .p-panelmenu .p-panelmenu-item.p-focus:not(.p-disabled) > .p-panelmenu-item-content:hover :is(.p-panelmenu-item-link, .p-panelmenu-item-label),
  .p-panelmenu .p-panelmenu-header.p-focus .p-panelmenu-header-content:hover :is(.p-panelmenu-header-link, .p-panelmenu-header-label) {
    color: ${dt('panelmenu.item.focusColor')};
  }

  .p-panelmenu .p-panelmenu-item.p-panelmenu-item-active:not(.p-disabled) > .p-panelmenu-item-content:hover :is(.p-panelmenu-item-icon, .p-panelmenu-submenu-icon),
  .p-panelmenu .p-panelmenu-item.p-focus:not(.p-disabled) > .p-panelmenu-item-content:hover :is(.p-panelmenu-item-icon, .p-panelmenu-submenu-icon),
  .p-panelmenu .p-panelmenu-header.p-focus .p-panelmenu-header-content:hover :is(.p-panelmenu-submenu-icon, .p-panelmenu-item-icon) {
    color: ${dt('panelmenu.item.icon.focusColor')};
  }

  /* ─── Captions ─── */

  .p-panelmenu .panelmenu-item-label {
    display: flex;
    flex-direction: column;
    gap: ${dt('panelmenu.extend.extItem.caption.gap')};
  }

  .p-panelmenu .panelmenu-item-caption {
    font-size: ${dt('fonts.fontSize.200')};
    line-height: ${dt('fonts.lineHeight.500')};
    color: ${dt('panelmenu.extend.extItem.caption.color')};
  }
`;

const progressbarCss = ({ dt }) => `
  .p-progressbar-label {
    font-family: ${dt('fonts.fontFamily.base')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-radiobutton.
 * Подключается в map-tokens.ts: `import { radiobuttonCss } from './tokens/components/radiobutton'`
 *
 * Цвета и базовые размеры приходят токенами пресета (radiobutton.root.*): их применяет сам PrimeNG.
 * Здесь — кольцо фокуса, ступень sm и цвет точки: этого у Aura нет либо
 * значение теряется на коллизии имён (см. комментарии ниже).
 */
const radiobuttonCss = ({ dt }) => `
/* Focus ring с зеленым цветом для валидных состояний */
.p-radiobutton:not(.p-disabled):not(.p-invalid):has(.p-radiobutton-input:focus-visible) .p-radiobutton-box,
.p-radiobutton-checked:not(.p-disabled):not(.p-invalid):has(.p-radiobutton-input:focus-visible) .p-radiobutton-box {
  outline: none;
  box-shadow: 0 0 0 ${dt('radiobutton.focusRing.width')} ${dt('color.border.focus')};
}

/* Focus ring с красным цветом для состояний с ошибкой */
.p-radiobutton.p-invalid .p-radiobutton-box,
.p-radiobutton.p-invalid:not(.p-disabled):has(.p-radiobutton-input:focus-visible) .p-radiobutton-box,
.p-radiobutton-checked.p-invalid .p-radiobutton-box,
.p-radiobutton-checked.p-invalid:not(.p-disabled):has(.p-radiobutton-input:focus-visible) .p-radiobutton-box {
  box-shadow: 0 0 0 ${dt('radiobutton.focusRing.width')} ${dt('color.bg.status.danger.weak.active')};
}

/* ─── Ступень sm ───
   Ширина sm продублирована в экспорте на двух уровнях: radiobutton.sm.width = dimension.size.450
   (16px) и radiobutton.root.sm.width = dimension.size.200 (8px). PrimeUIX отбрасывает сегмент
   root, обе схлопываются в --p-radiobutton-sm-width, и побеждает объявленная позже — 8px,
   вдвое меньше замысла: точка (8px) не помещалась в бокс. Через dt('radiobutton.sm.width')
   правильное значение не достать — это то же имя переменной, поэтому ссылаемся на ту самую
   ступень, на которую указывает radiobutton.sm.width. Коллизию чинить в Figma. */
.p-radiobutton.p-radiobutton-sm,
.p-radiobutton.p-radiobutton-sm .p-radiobutton-box {
  width: ${dt('dimension.size.450')};
  height: ${dt('dimension.size.450')};
}

.p-radiobutton.p-radiobutton-sm .p-radiobutton-icon {
  width: ${dt('radiobutton.icon.sm.size')};
  height: ${dt('radiobutton.icon.sm.size')};
}

/* ─── Цвет точки ───
   radiobutton.icon.checkedColor ссылается на color.fg.on.fill.default, а эта ветка не
   инвертируется: и в light, и в dark она #ffffff. Фон бокса при этом инвертируется
   (color.bg.neutral.strong.default: тёмный в light, светлый в dark), поэтому в тёмной теме
   белая точка пропадала на светлом фоне. Берём инверсный алиас — он меняется вместе с фоном. */
.p-radiobutton-checked .p-radiobutton-icon {
  background: ${dt('color.fg.inverse.default')};
}
`;

/**
 * Кастомная CSS-стилизация для компонента p-scrollpanel.
 * Подключается в map-tokens.ts: `import { scrollPanelCss } from './tokens/components/scroll-panel'`
 */
const scrollPanelCss = ({ dt }) => `
  /* ─── Полоса прокрутки ─── */
  .p-scrollpanel-bar {
    background: ${dt('scrollpanel.bar.background')};
    border-radius: ${dt('scrollpanel.bar.borderRadius')};
    transition-duration: ${dt('scrollpanel.root.transitionDuration')};
  }

  .p-scrollpanel-bar:focus-visible {
    outline-width: ${dt('scrollpanel.bar.focusRing.width')};
    outline-style: ${dt('scrollpanel.bar.focusRing.style')};
    outline-color: ${dt('scrollpanel.bar.focusRing.color')};
    outline-offset: ${dt('scrollpanel.bar.focusRing.offset')};
    box-shadow: ${dt('scrollpanel.bar.focusRing.shadow')};
  }
`;

const skeletonCss = ({ dt }) => `
.p-skeleton {
  min-width: ${dt('skeleton.extend.minWidth')};
}
`;

/**
 * Кастомная CSS-стилизация для компонента p-slider.
 * Подключается в map-tokens.ts: `import { sliderCss } from './components/slider'`
 */
const sliderCss = ({ dt }) => `
  /* ─── Focus ring ползунка ─── */
  .p-slider-handle:focus-visible {
    outline: ${dt('slider.handle.focusRing.width')} ${dt('slider.handle.focusRing.style')} ${dt('color.border.focus')};
    outline-offset: ${dt('slider.handle.focusRing.offset')};
    box-shadow: none;
  }
`;

const stepperCss = ({ dt }) => `

/* Caption - gap */
.p-stepper .p-step-title {
  display: flex;
  flex-direction: column;
  gap: ${dt('stepper.extend.extCaption.gap')};
  line-height: ${dt('fonts.lineHeight.250')};
  align-items: flex-start;
  text-align: left;
}

/* Caption - secondary text */
.p-stepper .p-step-title .caption-secondary {
  display: flex;
  justify-content: flex-start;
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: normal;
  color: ${dt('color.fg.muted')};
}

/* Номер шага */
.p-stepper .p-step-number {
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.medium')};
  line-height: ${dt('fonts.lineHeight.250')};
}

/* Border для номера шага */
.p-stepper .p-step-number.p-step-number {
  border-width: ${dt('stepper.extend.extStepNumber.borderWidth')};
}

/* Invalid состояние для step-number - только когда активен */
.p-stepper .step-invalid.p-step-active .p-step-number {
  background: ${dt('stepper.extend.extStepNumber.invalidBackground')};
  color: ${dt('stepper.extend.extStepNumber.invalidColor')};
  border-color: ${dt('stepper.extend.extStepNumber.invalidBorderColor')};
}

/* Step-number с иконкой */
.p-stepper .p-step-number:has(i) {
  background: transparent;
  border-color: transparent;
}

/* Размер иконок в step-number */
.p-stepper .p-step-number i {
  font-size: ${dt('stepper.extend.extStepNumber.iconSize')};
}

/* Активное состояние - иконка в цвет фона */
.p-stepper .p-step-active .p-step-number i {
  color: ${dt('stepper.stepNumber.activeBackground')};
}

/* Прозрачный фон для панелей */
.p-stepper .p-steppanel {
  background: transparent;
}
`;

const tabsCss = ({ dt }) => `
.p-tabs .p-tablist.p-tablist,
.p-tabs .p-tablist-content.p-tablist-content,
.p-tabs .p-tablist-viewport.p-tablist-viewport {
  overflow: visible;
}

.p-tabs .p-tablist .p-tab.p-tab {
  display: flex;
  align-items: center;
  gap: ${dt('tabs.tab.gap')};
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('tabs.tab.fontWeight')};
  line-height: ${dt('fonts.lineHeight.none')};
}

.p-tabs .p-tablist {
  border-style: solid;
  border-width: ${dt('tabs.tablist.borderWidth')};
  border-color: ${dt('tabs.tablist.borderColor')};
}
`;

const tieredmenuCss = ({ dt }) => `
  .p-tieredmenu {
    width: min-content;
  }

  .p-tieredmenu-item-content {
    font-size: ${dt('fonts.fontSize.300')};
  }

  .p-tieredmenu-submenu-icon {
    font-size: ${dt('tieredmenu.extend.iconSize')};
  }

  /* ─── Selected (checked) item ─── */

  .p-tieredmenu .p-tieredmenu-item.p-tieredmenu-item-checked > .p-tieredmenu-item-content {
    background: ${dt('tieredmenu.item.activeBackground')};
    color: ${dt('tieredmenu.item.activeColor')};
  }

  .p-tieredmenu .p-tieredmenu-item.p-tieredmenu-item-checked > .p-tieredmenu-item-content :is(.p-tieredmenu-item-link, .p-tieredmenu-item-label, .p-tieredmenu-item-icon, .p-tieredmenu-submenu-icon) {
    color: ${dt('tieredmenu.item.activeColor')};
  }

  /* ─── Hover on selected ─── */

  .p-tieredmenu .p-tieredmenu-item.p-tieredmenu-item-checked:not(.p-disabled) > .p-tieredmenu-item-content:hover {
    background: ${dt('tieredmenu.item.focusBackground')};
    color: ${dt('tieredmenu.item.focusColor')};
  }

  .p-tieredmenu .p-tieredmenu-item.p-tieredmenu-item-checked:not(.p-disabled) > .p-tieredmenu-item-content:hover :is(.p-tieredmenu-item-link, .p-tieredmenu-item-label) {
    color: ${dt('tieredmenu.item.focusColor')};
  }

  .p-tieredmenu .p-tieredmenu-item.p-tieredmenu-item-checked:not(.p-disabled) > .p-tieredmenu-item-content:hover :is(.p-tieredmenu-item-icon, .p-tieredmenu-submenu-icon) {
    color: ${dt('tieredmenu.item.icon.focusColor')};
  }

  /* ─── Captions ─── */

  .p-tieredmenu .p-tieredmenu-item-caption {
    display: flex;
    flex-direction: column;
    gap: ${dt('tieredmenu.extend.extItem.caption.gap')};
  }

  .p-tieredmenu .p-tieredmenu-item-caption-text {
    font-size: ${dt('fonts.fontSize.200')};
    color: ${dt('tieredmenu.extend.extItem.caption.color')};
  }
`;

const timelineCss = ({ dt }) => `

/* ─── Типографика ─── */
.p-timeline {
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.300')};
  line-height: ${dt('fonts.lineHeight.500')};
  color: ${dt('color.fg.default')};
}

/* ─── Маркер ─── */
.p-timeline-event-marker {
  border-width: ${dt('timeline.eventMarker.borderWidth')};
  background: ${dt('timeline.eventMarker.background')};
  border-color: ${dt('timeline.eventMarker.borderColor')};
}

.p-timeline-event-marker::before {
  background: ${dt('timeline.eventMarker.content.background')};
}

/* ─── Коннектор ─── */
.p-timeline-event-connector {
  background: ${dt('timeline.eventConnector.color')};
}

/* ─── Стиль линии ─── */
timeline[data-line="dashed"] .p-timeline-event-connector {
  background: none;
  border-left: ${dt('timeline.eventConnector.size')} dashed ${dt('timeline.eventConnector.color')};
}

timeline[data-line="dotted"] .p-timeline-event-connector {
  background: none;
  border-left: ${dt('timeline.eventConnector.size')} dotted ${dt('timeline.eventConnector.color')};
}

timeline[data-line="none"] .p-timeline-event-connector {
  background: none;
}

/* Горизонтальная ориентация линии */
timeline[data-line="dashed"] .p-timeline-horizontal .p-timeline-event-connector {
  border-left: none;
  border-top: ${dt('timeline.eventConnector.size')} dashed ${dt('timeline.eventConnector.color')};
}

timeline[data-line="dotted"] .p-timeline-horizontal .p-timeline-event-connector {
  border-left: none;
  border-top: ${dt('timeline.eventConnector.size')} dotted ${dt('timeline.eventConnector.color')};
}

/* ─── Маркер-иконка (без бордера и фона) ─── */
.p-timeline-event-marker:has(i) {
  border: none;
  background: none;
}

.p-timeline-event-marker:has(i)::before {
  display: none;
}

/* ─── Кастомный цвет маркера ─── */
timeline[style*="--timeline-marker-color"] .p-timeline-event-marker {
  border-color: var(--timeline-marker-color);
}

timeline[style*="--timeline-marker-color"] .p-timeline-event-marker i {
  color: var(--timeline-marker-color);
}
`;

const toastCss = ({ dt }) => `
  /* Основной контейнер toast-сообщения */
  .p-toast-message {
    width: ${dt('toast.root.width')};
    overflow: hidden;
    border-width: ${dt('toast.root.borderWidth')};
    border-radius: ${dt('toast.root.borderRadius')};
    box-shadow: ${dt('toast.colorScheme.light.info.shadow')};
    position: relative;
  }

  /* border-radius для контента toast-сообщения */
  .p-toast .p-toast-message .p-toast-message-content {
    border-radius: ${dt('toast.root.borderRadius')};
  }

  /* Текстовый блок toast */
  .p-toast-message-text {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: ${dt('toast.text.gap')};
  }

  /* Заголовок toast */
  .p-toast-summary {
    font-family: ${dt('fonts.fontFamily.base')};
    line-height: ${dt('fonts.lineHeight.250')};
  }

  /* Детальное описание toast */
  .p-toast-message .p-toast-detail {
    font-family: ${dt('fonts.fontFamily.base')};
    line-height: ${dt('fonts.lineHeight.250')};
  }

  /* Кнопка закрытия toast-сообщения */
  .p-toast-message .p-toast-message-content .p-toast-close-button {
    margin: 0;
    padding: 0;
    right: 0;
  }

  /* Общие стили border для кнопки закрытия всех типов toast */
  .p-toast-message-info .p-toast-close-button,
  .p-toast-message-success .p-toast-close-button,
  .p-toast-message-warn .p-toast-close-button,
  .p-toast-message-error .p-toast-close-button {
    border: ${dt('toast.extend.extCloseButton.width')} solid;
  }

  /* Общие стили для акцентной линии всех типов toast */
  .p-toast-message-info .p-toast-accent-line,
  .p-toast-message-success .p-toast-accent-line,
  .p-toast-message-warn .p-toast-accent-line,
  .p-toast-message-error .p-toast-accent-line {
    width: ${dt('toast.extend.extAccentLine.width')};
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    border-radius: ${dt('toast.root.borderRadius')} 0 0 ${dt('toast.root.borderRadius')};
  }

  /* Стили для toast типа Info */
  .p-toast-message-info .p-toast-message-icon {
    color: ${dt('toast.extend.extInfo.color')};
  }

  .p-toast-message-info .p-toast-close-button {
    color: ${dt('toast.extend.extInfo.closeButton.color')};
    border-color: ${dt('toast.extend.extInfo.closeButton.borderColor')};
  }

  .p-toast-message.p-toast-message-info .p-toast-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('toast.colorScheme.light.info.closeButton.hoverBackground')};
    border-color: ${dt('toast.extend.extInfo.closeButton.borderColor')};
    color: ${dt('toast.extend.extInfo.closeButton.color')};
  }

  .p-toast-message-info .p-toast-accent-line {
    background: ${dt('toast.extend.extInfo.color')};
  }

  /* Стили для toast типа Success */
  .p-toast-message-success .p-toast-message-icon {
    color: ${dt('toast.extend.extSuccess.color')};
  }

  .p-toast-message-success .p-toast-close-button {
    color: ${dt('toast.extend.extSuccess.closeButton.color')};
    border-color: ${dt('toast.extend.extSuccess.closeButton.borderColor')};
  }

  .p-toast-message.p-toast-message-success .p-toast-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('toast.colorScheme.light.success.closeButton.hoverBackground')};
    border-color: ${dt('toast.extend.extSuccess.closeButton.borderColor')};
    color: ${dt('toast.extend.extSuccess.closeButton.color')};
  }

  .p-toast-message-success .p-toast-accent-line {
    background: ${dt('toast.extend.extSuccess.color')};
  }

  /* Стили для toast типа Warn */
  .p-toast-message-warn .p-toast-message-icon {
    color: ${dt('toast.extend.extWarn.color')};
  }

  .p-toast-message-warn .p-toast-close-button {
    color: ${dt('toast.extend.extWarn.closeButton.color')};
    border-color: ${dt('toast.extend.extWarn.closeButton.borderColor')};
  }

  .p-toast-message.p-toast-message-warn .p-toast-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('toast.colorScheme.light.warn.closeButton.hoverBackground')};
    border-color: ${dt('toast.extend.extWarn.closeButton.borderColor')};
    color: ${dt('toast.extend.extWarn.closeButton.color')};
  }

  .p-toast-message-warn .p-toast-accent-line {
    background: ${dt('toast.extend.extWarn.color')};
  }

  /* Стили для toast типа Error */
  .p-toast-message-error .p-toast-message-icon {
    color: ${dt('toast.extend.extError.color')};
  }

  .p-toast-message-error .p-toast-close-button {
    color: ${dt('toast.extend.extError.closeButton.color')};
    border-color: ${dt('toast.extend.extError.closeButton.borderColor')};
  }

  .p-toast-message.p-toast-message-error .p-toast-close-button.p-button-text:not(:disabled):hover {
    background: ${dt('toast.colorScheme.light.error.closeButton.hoverBackground')};
    border-color: ${dt('toast.extend.extError.closeButton.borderColor')};
    color: ${dt('toast.extend.extError.closeButton.color')};
  }

  .p-toast-message-error .p-toast-accent-line {
    background: ${dt('toast.extend.extError.color')};
  }
`;

/**
 * Кастомная CSS-стилизация для компонента p-togglebutton.
 * Подключается в map-tokens.ts: `import { togglebuttonCss } from './tokens/components/togglebutton'`
 *
 * Высота у всех размеров задаётся явно из размерной лестницы дизайна
 * (`extend.*.iconOnlyWidth` = 32/40/56/64px). Без этого высота текстовой кнопки выводилась
 * из паддинга и расходилась с icon-only на 2–6px, а внутри select-button — ещё и с группой.
 */
const togglebuttonCss = ({ dt }) => `

/* ─── Типографика ─── */
.p-togglebutton.p-component {
  font-family: ${dt('fonts.fontFamily.heading')};
  font-weight: ${dt('fonts.fontWeight.demibold')};
  line-height: ${dt('fonts.lineHeight.500')};
}

/* ─── Высота по размерам: одна лестница для текстовых и icon-only ─── */
.p-togglebutton.p-component {
  height: ${dt('togglebutton.extend.iconOnlyWidth')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-sm {
  height: ${dt('togglebutton.extend.extSm.iconOnlyWidth')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-lg {
  height: ${dt('togglebutton.extend.extLg.iconOnlyWidth')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-xlarge {
  height: ${dt('togglebutton.extend.extXlg.iconOnlyWidth')};
}

/* ─── Hover unchecked ─── */
.p-togglebutton:not(:disabled):not(.p-togglebutton-checked):hover {
  border-color: ${dt('togglebutton.extend.hoverBorderColor')};
}

/* ─── Hover checked ─── */
.p-togglebutton.p-togglebutton-checked:hover {
  background: ${dt('togglebutton.extend.checkedHoverBackground')};
  border-color: ${dt('togglebutton.extend.checkedHoverBorderColor')};
  color: ${dt('togglebutton.extend.checkedHoverColor')};
}

/* ─── Small ─── */
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-sm {
  line-height: ${dt('fonts.lineHeight.300')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-sm .p-togglebutton-label {
  line-height: ${dt('fonts.lineHeight.250')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-sm .p-togglebutton-icon {
  font-size: ${dt('togglebutton.extend.iconSize.sm')};
}

/* ─── Base (default) ─── */
.p-togglebutton.p-component:not(.p-togglebutton-sm):not(.p-togglebutton-lg):not(.p-togglebutton-xlarge) .p-togglebutton-icon {
  font-size: ${dt('togglebutton.extend.iconSize.md')};
}

/* ─── Large ─── */
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-lg {
  line-height: ${dt('fonts.lineHeight.550')};
  gap: ${dt('togglebutton.root.gap')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-lg .p-togglebutton-content {
  gap: ${dt('togglebutton.extend.ext.gap')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-lg .p-togglebutton-icon {
  font-size: ${dt('togglebutton.extend.iconSize.lg')};
}

/* ─── Extra Large ─── */
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-xlarge {
  padding: ${dt('togglebutton.extend.extXlg.padding')};
  font-size: ${dt('fonts.fontSize.500')};
  line-height: ${dt('fonts.lineHeight.550')};
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: ${dt('togglebutton.root.gap')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-xlarge .p-togglebutton-content {
  gap: ${dt('togglebutton.extend.ext.gap')};
}
.p-togglebutton.p-togglebutton.p-component.p-togglebutton-xlarge .p-togglebutton-icon {
  font-size: ${dt('togglebutton.extend.iconSize.lg')};
}

/* ─── Icon-only base ─── */
.p-togglebutton.p-togglebutton-icon-only {
  padding: 0;
  width: ${dt('togglebutton.extend.iconOnlyWidth')};
  height: ${dt('togglebutton.extend.iconOnlyWidth')};
  border-radius: ${dt('togglebutton.root.borderRadius')};
}
.p-togglebutton.p-togglebutton-icon-only .p-togglebutton-label {
  display: none;
}

/* ─── Icon-only sm ─── */
.p-togglebutton.p-togglebutton-sm.p-togglebutton-icon-only {
  width: ${dt('togglebutton.extend.extSm.iconOnlyWidth')};
  height: ${dt('togglebutton.extend.extSm.iconOnlyWidth')};
}

/* ─── Icon-only lg ─── */
.p-togglebutton.p-togglebutton-lg.p-togglebutton-icon-only {
  width: ${dt('togglebutton.extend.extLg.iconOnlyWidth')};
  height: ${dt('togglebutton.extend.extLg.iconOnlyWidth')};
}

/* ─── Icon-only xlarge ─── */
.p-togglebutton.p-togglebutton-xlarge.p-togglebutton-icon-only {
  width: ${dt('togglebutton.extend.extXlg.iconOnlyWidth')};
  height: ${dt('togglebutton.extend.extXlg.iconOnlyWidth')};
}
`;

const toggleswitchCss = ({ dt }) => `
  /* Focus ring для валидных состояний */
  .p-toggleswitch:not(.p-disabled):not(.p-invalid):has(.p-toggleswitch-input:focus-visible) .p-toggleswitch-slider {
    box-shadow: 0 0 0 ${dt('toggleswitch.root.focusRing.width')} ${dt('color.border.focus')};
  }

  /* Focus ring для состояния ошибки */
  .p-toggleswitch.p-invalid:not(.p-disabled):has(.p-toggleswitch-input:focus-visible) .p-toggleswitch-slider {
    box-shadow: 0 0 0 ${dt('dimension.space.100')} ${dt('color.bg.status.danger.weak.active')};
  }
`;

const autocompleteCss = ({ dt }) => `
  /* ─── Base ─── */
  .p-autocomplete {
    width: 100%;
  }

  .p-autocomplete:has(input:disabled) .p-autocomplete-input,
  .p-autocomplete:has(input:disabled) .p-autocomplete-input-multiple,
  .p-autocomplete:has(input:disabled) .p-autocomplete-dropdown {
    border-color: ${dt('color.fg.muted')};
  }

  /* ─── Инпут и границы ─── */
  .p-autocomplete .p-autocomplete-input {
    width: 100%;
    padding: ${dt('autocomplete.root.paddingY')} ${dt('autocomplete.root.paddingX')};
    line-height: ${dt('fonts.lineHeight.250')};
  }

  /* Монолитный вид: убираем стыкующиеся границы инпута и dropdown-кнопки.
     border-inline-end-width не перезаписывается hover/focus, т.к. те меняют только border-color. */
  .p-autocomplete:has(.p-autocomplete-dropdown) .p-autocomplete-input {
    border-inline-end-width: 0;
  }

  /* Dropdown: дублируем border-inline-start: 0 с повышенной специфичностью,
     чтобы наш селектор гарантированно побеждал базовое правило PrimeNG. */
  .p-autocomplete .p-autocomplete-dropdown {
    border-inline-start: 0 none;
  }

  /* ─── States: Hover ─── */
  .p-autocomplete.p-component:not(:has(input:disabled)):hover .p-inputtext.p-autocomplete-input,
  .p-autocomplete.p-component:not(:has(input:disabled)):hover .p-autocomplete-dropdown,
  .p-autocomplete.p-component:not(:has(input:disabled)):has(.p-autocomplete-input:hover) .p-autocomplete-dropdown {
    border-color: ${dt('color.bg.brand.strong.hover')};
  }

  /* ─── States: Focus ─── */
  .p-autocomplete:has(.p-autocomplete-input:focus) .p-autocomplete-dropdown {
    border-color: ${dt('color.bg.brand.strong.hover')};
  }

  /* ─── Иконки ─── */
  .p-autocomplete-clear-icon,
  .p-autocomplete-dropdown .p-icon {
    color: ${dt('autocomplete.dropdown.color')};
  }

  .p-autocomplete.p-component:has(.p-autocomplete-dropdown) .p-autocomplete-clear-icon {
    inset-inline-end: ${dt('dimension.size.1100')};
  }

  /* ─── Multiple: чипсы ─── */
  .p-autocomplete .p-autocomplete-input-multiple {
    line-height: ${dt('fonts.lineHeight.250')};
    padding: ${dt('autocomplete.root.paddingY')} ${dt('autocomplete.root.paddingX')};
  }

  .p-autocomplete .p-autocomplete-input-multiple:has(.p-autocomplete-chip) {
    padding: calc(${dt('autocomplete.root.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
  }

  .p-autocomplete .p-autocomplete-input-chip {
    padding-block-start: 0;
    padding-block-end: 0;
  }

  .p-autocomplete .p-autocomplete-input-multiple [data-pc-section="input"] {
    font-family: inherit;
    font-size: inherit;
    color: inherit;
    background: transparent;
    border: 0 none;
    outline: 0 none;
    padding: 0;
    margin: 0;
    line-height: inherit;
  }

  .p-autocomplete .p-autocomplete-chip,
  .p-autocomplete-option {
    gap: ${dt('autocomplete.extend.extOption.gap')};
  }

  .p-autocomplete-option {
    background: ${dt('autocomplete.extend.option.background')};
  }

  .p-autocomplete-option-group {
    gap: ${dt('autocomplete.extend.extOptionGroup.gap')};
  }

  .p-chip.p-chip:has(.p-chip-remove-icon) {
    padding-inline-end: ${dt('chip.root.paddingX')};
  }

  /* ─── Sizes ─────────────────────────────────────────────────────────────────
     Повторяем padding-block / padding-inline из PrimeNG inputtext-size классов,
     но с повышенной специфичностью (.p-autocomplete.p-component + класс размера),
     чтобы перебить base-padding из .p-autocomplete .p-autocomplete-input выше.
  ──────────────────────────────────────────────────────────────────────────── */

  /* sm */
  .p-autocomplete.p-component .p-inputtext-sm.p-autocomplete-input,
  .p-autocomplete.p-component .p-inputtext-sm.p-autocomplete-input-multiple {
    font-size: ${dt('inputtext.root.sm.fontSize')};
    padding-block: ${dt('inputtext.root.sm.paddingY')};
    padding-inline: ${dt('inputtext.root.sm.paddingX')};
  }

  .p-autocomplete.p-component .p-inputtext-sm.p-autocomplete-input-multiple:has(.p-autocomplete-chip) {
    padding-block: calc(${dt('inputtext.root.sm.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
    padding-inline: calc(${dt('inputtext.root.sm.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
  }

  /* lg */
  .p-autocomplete.p-component .p-inputtext-lg.p-autocomplete-input,
  .p-autocomplete.p-component .p-inputtext-lg.p-autocomplete-input-multiple {
    font-size: ${dt('inputtext.root.lg.fontSize')};
    padding-block: ${dt('inputtext.root.lg.paddingY')};
    padding-inline: ${dt('inputtext.root.lg.paddingX')};
  }

  .p-autocomplete.p-component .p-inputtext-lg.p-autocomplete-input-multiple:has(.p-autocomplete-chip) {
    padding-block: calc(${dt('inputtext.root.lg.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
    padding-inline: calc(${dt('inputtext.root.lg.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
  }

  /* xlg */
  .p-autocomplete.p-component .p-inputtext-xlg.p-autocomplete-input,
  .p-autocomplete.p-component .p-inputtext-xlg.p-autocomplete-input-multiple {
    font-size: ${dt('inputtext.extend.extXlg.fontSize')};
    padding-block: ${dt('inputtext.extend.extXlg.paddingY')};
    padding-inline: ${dt('inputtext.extend.extXlg.paddingX')};
  }

  .p-autocomplete.p-component .p-inputtext-xlg.p-autocomplete-input-multiple:has(.p-autocomplete-chip) {
    padding-block: calc(${dt('inputtext.extend.extXlg.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
    padding-inline: calc(${dt('inputtext.extend.extXlg.paddingY')} - ${dt('chip.root.paddingY')} - ${dt('chip.extend.borderWidth')});
  }

  .p-autocomplete.p-component .p-inputtext-xlg .p-autocomplete-chip {
    padding-top: ${dt('dimension.space.200')};
    padding-bottom: ${dt('dimension.space.200')};
    font-size: ${dt('fonts.fontSize.300')};
  }
`;

const popoverCss = ({ dt }) => `
.p-popover.p-component::before {
  border-width: ${dt('popover.extend.arrow.height')} calc(${dt('popover.extend.arrow.width')} / 2);
  margin-left: calc(-1 * ${dt('popover.extend.arrow.width')} / 2);
}

.p-popover.p-component::after {
  border-width: calc(${dt('popover.extend.arrow.height')} - ${dt('popover.extend.borderWidth')})
    calc(${dt('popover.extend.arrow.width')} / 2 - ${dt('popover.extend.borderWidth')});
  margin-left: calc(-1 * (${dt('popover.extend.arrow.width')} / 2 - ${dt('popover.extend.borderWidth')}));
}
`;

/**
 * Кастомная CSS-стилизация для компонента p-selectbutton.
 * Подключается в map-tokens.ts: `import { selectbuttonCss } from './tokens/components/selectbutton'`
 *
 * Высоты и hover-рамка берутся из токенов togglebutton: selectbutton — контейнер кнопок-переключателей,
 * и их размерная лестница задаётся дизайном именно там.
 */
const selectbuttonCss = ({ dt }) => `
.p-selectbutton.p-component {
  background: ${dt('selectbutton.colorScheme.light.extend.background')};
  padding: ${dt('selectbutton.extend.paddingY')} ${dt('selectbutton.extend.paddingX')};
  gap: ${dt('selectbutton.extend.gap')};
  font-family: ${dt('fonts.fontFamily.heading')};
  font-weight: ${dt('fonts.fontWeight.demibold')};
}

.p-selectbutton.p-component .p-togglebutton.p-component {
  font-family: ${dt('fonts.fontFamily.heading')};
  font-weight: ${dt('fonts.fontWeight.demibold')};
  line-height: ${dt('fonts.lineHeight.500')};
  height: ${dt('togglebutton.extend.iconOnlyWidth')};
  border-radius: ${dt('selectbutton.extend.ext.borderRadius')};
}

.p-selectbutton.p-component .p-togglebutton .p-togglebutton-label,
.p-selectbutton.p-component .p-togglebutton .p-togglebutton-content > span {
  line-height: ${dt('fonts.lineHeight.400')};
}

.p-selectbutton.p-component .p-togglebutton.p-togglebutton-checked.p-component,
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-checked.p-component:hover {
  background: ${dt('selectbutton.extend.checkedBackground')};
  border-radius: ${dt('selectbutton.extend.ext.borderRadius')};
  border-color: ${dt('selectbutton.extend.checkedBorderColor')};
  color: ${dt('selectbutton.extend.checkedColor')};
}

.p-selectbutton.p-component .p-togglebutton.p-component:not(:disabled):not(.p-togglebutton-checked):hover {
  border-radius: ${dt('selectbutton.extend.ext.borderRadius')};
  border-color: ${dt('togglebutton.extend.hoverBorderColor')};
}

/* Size: small — PrimeNG вешает .p-togglebutton-sm на дочерний p-togglebutton */
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-sm.p-component {
  line-height: ${dt('fonts.lineHeight.300')};
  height: ${dt('togglebutton.extend.extSm.iconOnlyWidth')};
}

.p-selectbutton.p-component .p-togglebutton.p-togglebutton-sm .p-togglebutton-label,
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-sm .p-togglebutton-content > span {
  line-height: ${dt('fonts.lineHeight.250')};
}

.p-selectbutton.p-component .p-togglebutton.p-togglebutton-sm .p-togglebutton-icon,
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-sm i {
  font-size: ${dt('selectbutton.extend.iconSize.sm')};
}

/* Size: base — токен md для togglebutton без класса размера (исключая xlarge-корень) */
.p-selectbutton.p-component:not(.p-selectbutton-xlarge) .p-togglebutton:not(.p-togglebutton-sm):not(.p-togglebutton-lg) .p-togglebutton-icon,
.p-selectbutton.p-component:not(.p-selectbutton-xlarge) .p-togglebutton:not(.p-togglebutton-sm):not(.p-togglebutton-lg) i {
  font-size: ${dt('selectbutton.extend.iconSize.md')};
}

/* Size: large — PrimeNG вешает .p-togglebutton-lg на дочерний p-togglebutton */
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-lg.p-component {
  line-height: ${dt('fonts.lineHeight.550')};
  height: ${dt('togglebutton.extend.extLg.iconOnlyWidth')};
}

.p-selectbutton.p-component .p-togglebutton.p-togglebutton-lg .p-togglebutton-label,
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-lg .p-togglebutton-content > span {
  line-height: ${dt('fonts.lineHeight.550')};
}

.p-selectbutton.p-component .p-togglebutton.p-togglebutton-lg .p-togglebutton-icon,
.p-selectbutton.p-component .p-togglebutton.p-togglebutton-lg i {
  font-size: ${dt('selectbutton.extend.iconSize.lg')};
}

/* Size: xlarge — PrimeNG не вешает на дочерний p-togglebutton класс размера (у него нет
   ступени xlg), поэтому паддинги остаются базовыми: задаём их сами, как у отдельного
   togglebutton в этой же ступени. */
.p-selectbutton.p-selectbutton-xlarge.p-component .p-togglebutton.p-component {
  padding: ${dt('togglebutton.extend.extXlg.padding')};
  font-size: ${dt('fonts.fontSize.600')};
  line-height: ${dt('fonts.lineHeight.550')};
  height: ${dt('togglebutton.extend.extXlg.iconOnlyWidth')};
}

.p-selectbutton.p-selectbutton-xlarge.p-component .p-togglebutton .p-togglebutton-label,
.p-selectbutton.p-selectbutton-xlarge.p-component .p-togglebutton .p-togglebutton-content > span {
  line-height: ${dt('fonts.lineHeight.700')};
}

.p-selectbutton.p-selectbutton-xlarge.p-component .p-togglebutton .p-togglebutton-icon,
.p-selectbutton.p-selectbutton-xlarge.p-component .p-togglebutton i {
  font-size: ${dt('selectbutton.extend.iconSize.xlg')};
}
`;

const fileuploadCss = ({ dt }) => `

.p-fileupload {
  display: flex;
  flex-direction: column;
  gap: ${dt('dimension.space.200')};
  border: unset;
}

.p-fileupload .p-fileupload-header {
  padding: 0;
}

.p-fileupload .p-fileupload-content {
  padding: 0;
  border: unset;
}

.p-fileupload .p-message .p-message-content {
  align-items: center;
}

/* ─── Drop zone ─── */
.fu-header {
  width: 100%;
}

.fu-dropzone {
  border: ${dt('dimension.borderWidth.100')} dashed ${dt('fileupload.extend.extContent.highlightBorderDefault')};
  border-radius: ${dt('fileupload.extend.extDragNdrop.borderRadius')};
  padding: ${dt('fileupload.extend.extDragNdrop.padding')};
  background: ${dt('fileupload.extend.extDragNdrop.background')};
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: ${dt('fileupload.content.gap')};
  cursor: pointer;
  transition: border-color ${dt('fileupload.root.transitionDuration')};
}

.fu-dropzone:hover {
  border-color: ${dt('fileupload.content.highlightBorderColor')};
}

.fu-dropzone.fu-dropzone--disabled:hover {
  border-color: ${dt('fileupload.extend.extContent.highlightBorderDefault')};
}

.fu-dropzone__icon {
  font-size: ${dt('fileupload.extend.extDragNdrop.iconSize')};
  color: ${dt('color.fg.default')};
}

.fu-dropzone__info {
  display: flex;
  flex-direction: column;
  gap: ${dt('fileupload.extend.extDragNdrop.info.gap')};
  width: 100%;
}

.fu-dropzone__title {
  font-family: ${dt('fonts.fontFamily.heading')};
  font-size: ${dt('fonts.fontSize.300')};
  font-weight: ${dt('fonts.fontWeight.bold')};
  line-height: ${dt('fonts.lineHeight.500')};
  color: ${dt('color.fg.default')};
  align-self: center;
}

.fu-dropzone__caption {
  display: flex;
  align-items: center;
  gap: ${dt('dimension.space.100')};
  font-family: ${dt('fonts.fontFamily.base')};
  font-size: ${dt('fonts.fontSize.200')};
  font-weight: ${dt('fonts.fontWeight.regular')};
  line-height: ${dt('fonts.lineHeight.250')};
  color: ${dt('color.fg.muted')};
  align-self: center;
}

.fu-dropzone__caption .ti {
  font-size: ${dt('fonts.fontSize.300')};
  line-height: ${dt('fonts.lineHeight.250')};
}

/* ─── Content ─── */
.fu-content {
  display: flex;
  flex-direction: column;
  gap: ${dt('fileupload.content.gap')};
}

/* ─── File list ─── */
.fu-file-list {
  display: flex;
  flex-direction: column;
  gap: ${dt('fileupload.fileList.gap')};
}

.fu-file-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${dt('fileupload.file.padding')};
  border: ${dt('dimension.borderWidth.100')} solid ${dt('fileupload.file.borderColor')};
  border-radius: ${dt('fileupload.extend.extDragNdrop.borderRadius')};
  gap: ${dt('fileupload.file.gap')};
  transition: border-color ${dt('fileupload.root.transitionDuration')};
}

.fu-file-card--uploaded {
  opacity: ${dt('effects.opacity.50')};
  background: ${dt('colors.solid.zinc.50')};
}

.fu-file-card__wrap {
  display: flex;
  align-items: center;
  gap: ${dt('dimension.space.300')};
}

.fu-file-card__icon {
  font-size: ${dt('fileupload.extend.extFile.iconSize')};
  color: ${dt('color.fg.default')};
  flex-shrink: 0;
}

.fu-file-card__thumbnail {
  width: ${dt('fileupload.extend.extFile.iconSize')};
  height: ${dt('fileupload.extend.extFile.iconSize')};
  object-fit: cover;
  border-radius: ${dt('fileupload.extend.extContent.borderRadius')};
  flex-shrink: 0;
}

.fu-file-card__info {
  display: flex;
  flex-direction: column;
  gap: ${dt('fileupload.file.info.gap')};
}

.fu-file-card__name {
  font-size: ${dt('fonts.fontSize.300')};
  color: ${dt('color.fg.default')};
  line-height: ${dt('fonts.lineHeight.400')};
}

.fu-file-card__size {
  display: flex;
  align-items: center;
  gap: ${dt('dimension.space.100')};
  font-size: ${dt('fonts.fontSize.200')};
  color: ${dt('color.fg.muted')};
}

.fu-file-card__size .ti {
  font-size: ${dt('fonts.fontSize.300')};
}

/* ─── Footer ─── */
.fu-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

`;

const presetTokens = {
    primitive: tokens.primitive,
    semantic: tokens.semantic,
    components: {
        ...tokens.components,
        avatar: {
            ...tokens.components.avatar,
            css: avatarCss
        },
        card: {
            ...tokens.components.card,
            css: cardCss
        },
        checkbox: {
            ...tokens.components.checkbox,
            css: checkboxCss
        },
        button: {
            ...tokens.components.button,
            css: buttonCss
        },
        message: {
            ...tokens.components.message,
            css: messageCss
        },
        progressspinner: {
            ...tokens.components.progressspinner,
            css: progressspinnerCss
        },
        inputotp: {
            ...tokens.components.inputotp,
            css: inputotpCss
        },
        inputtext: {
            ...tokens.components.inputtext,
            css: inputtextCss
        },
        inputmask: {
            css: inputmaskCss
        },
        inputgroup: {
            ...tokens.components.inputgroup,
            css: inputgroupCss
        },
        tag: {
            ...tokens.components.tag,
            css: tagCss
        },
        textarea: {
            ...tokens.components.textarea,
            css: textareaCss
        },
        tooltip: {
            ...tokens.components.tooltip,
            css: tooltipCss
        },
        megamenu: {
            ...tokens.components.megamenu,
            css: megamenuCss
        },
        select: {
            ...tokens.components.select,
            css: selectCss
        },
        passwordCss: {
            ...tokens.components.password,
            css: passwordCss
        },
        carousel: {
            ...tokens.components.carousel,
            css: carouselCss
        },
        galleria: {
            ...tokens.components.galleria,
            css: galleriaCss
        },
        confirmdialog: {
            ...tokens.components.confirmdialog,
            css: confirmDialogCss
        },
        drawer: {
            ...tokens.components.drawer,
            css: drawerCss
        },
        datepicker: {
            ...tokens.components.datepicker,
            css: datePickerCss
        },
        accordion: {
            ...tokens.components.accordion,
            css: accordionCss
        },
        badge: {
            ...tokens.components.badge,
            css: badgeCss
        },
        chip: {
            ...tokens.components.chip,
            css: chipCss
        },
        datatable: {
            ...tokens.components.datatable,
            css: dataTableCss
        },
        dialog: {
            ...tokens.components.dialog,
            css: dialogCss
        },
        divider: {
            ...tokens.components.divider,
            css: dividerCss
        },
        inputnumber: {
            ...tokens.components.inputnumber,
            css: inputnumberCss
        },
        listbox: {
            ...tokens.components.listbox,
            css: listboxCss
        },
        menu: {
            ...tokens.components.menu,
            css: menuCss
        },
        metergroup: {
            ...tokens.components.metergroup,
            css: metergroupCss
        },
        paginator: {
            ...tokens.components.paginator,
            css: paginatorCss
        },
        panelmenu: {
            ...tokens.components.panelmenu,
            css: panelmenuCss
        },
        progressbar: {
            ...tokens.components.progressbar,
            css: progressbarCss
        },
        radiobutton: {
            ...tokens.components.radiobutton,
            css: radiobuttonCss
        },
        scrollpanel: {
            ...tokens.components.scrollpanel,
            css: scrollPanelCss
        },
        skeleton: {
            ...tokens.components.skeleton,
            css: skeletonCss
        },
        slider: {
            ...tokens.components.slider,
            css: sliderCss
        },
        stepper: {
            ...tokens.components.stepper,
            css: stepperCss
        },
        tabs: {
            ...tokens.components.tabs,
            css: tabsCss
        },
        tieredmenu: {
            ...tokens.components.tieredmenu,
            css: tieredmenuCss
        },
        timeline: {
            ...tokens.components.timeline,
            css: timelineCss
        },
        toast: {
            ...tokens.components.toast,
            css: toastCss
        },
        togglebutton: {
            ...tokens.components.togglebutton,
            css: togglebuttonCss
        },
        toggleswitch: {
            ...tokens.components.toggleswitch,
            css: toggleswitchCss
        },
        autocomplete: {
            ...tokens.components.autocomplete,
            css: autocompleteCss
        },
        popover: {
            ...tokens.components.popover,
            css: popoverCss
        },
        selectbutton: {
            ...tokens.components.selectbutton,
            css: selectbuttonCss
        },
        fileupload: {
            ...tokens.components.fileupload,
            css: fileuploadCss
        }
    }
};

const Preset = definePreset(Aura, presetTokens);

function provideExtraThemes() {
    return makeEnvironmentProviders([
        providePrimeNG({
            theme: {
                preset: Preset,
                options: {
                    darkModeSelector: false,
                    cssLayer: false
                }
            }
        })
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { provideExtraThemes };
//# sourceMappingURL=cdek-it-angular-ui-kit-providers.mjs.map
