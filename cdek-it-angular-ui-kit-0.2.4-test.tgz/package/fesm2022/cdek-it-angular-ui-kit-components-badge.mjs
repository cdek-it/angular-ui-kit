import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Badge } from 'primeng/badge';

class ExtraBadgeComponent {
    value = '';
    severity = 'primary';
    size = 'base';
    get primeSeverity() {
        if (this.severity === 'primary')
            return null;
        if (this.severity === 'warning')
            return 'warn';
        return this.severity;
    }
    get primeSize() {
        if (this.size === 'base')
            return null;
        return this.size;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraBadgeComponent, isStandalone: true, selector: "extra-badge", inputs: { value: "value", severity: "severity", size: "size" }, ngImport: i0, template: ` <p-badge [value]="value" [severity]="primeSeverity" [size]="primeSize"></p-badge> `, isInline: true, dependencies: [{ kind: "component", type: Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraBadgeComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-badge',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Badge],
                    template: ` <p-badge [value]="value" [severity]="primeSeverity" [size]="primeSize"></p-badge> `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], severity: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraBadgeComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-badge.mjs.map
