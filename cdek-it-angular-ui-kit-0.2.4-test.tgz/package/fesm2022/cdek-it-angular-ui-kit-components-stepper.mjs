import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { NgClass } from '@angular/common';
import { Stepper, StepList, Step, StepPanels, StepPanel, StepItem } from 'primeng/stepper';
import { ExtraButtonComponent } from '@cdek-it/angular-ui-kit/components/button';

class ExtraStepperComponent {
    value = 1;
    steps = [];
    linear = false;
    orientation = 'horizontal';
    showPanels = true;
    valueChange = new EventEmitter();
    onValueChange(newValue) {
        this.value = newValue;
        this.valueChange.emit(newValue);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraStepperComponent, isStandalone: true, selector: "extra-stepper", inputs: { value: "value", steps: "steps", linear: "linear", orientation: "orientation", showPanels: "showPanels" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-stepper [value]="value" [linear]="linear" (valueChange)="onValueChange($event)">
      @if (orientation === 'horizontal') {
        <p-step-list>
          @for (step of steps; track step.value) {
            <p-step
              [value]="step.value"
              [disabled]="step.disabled || false"
              [ngClass]="{ 'step-invalid': step.invalid }"
            >
              {{ step.label }}
              @if (step.caption) {
                <div class="caption-secondary">{{ step.caption }}</div>
              }
            </p-step>
          }
        </p-step-list>
      }
      @if (orientation === 'horizontal' && showPanels) {
        <p-step-panels>
          @for (step of steps; track step.value; let i = $index; let first = $first; let last = $last) {
            <p-step-panel [value]="step.value">
              <ng-template #content let-activateCallback="activateCallback">
                <p class="m-0">{{ step.content }}</p>
                <div class="flex pt-4">
                  @if (!first) {
                    <extra-button
                      label="Назад"
                      variant="tertiary"
                      (click)="activateCallback(steps[i - 1].value)"
                    ></extra-button>
                  }
                  @if (!last) {
                    <extra-button
                      label="Вперёд"
                      variant="secondary"
                      class="ml-auto"
                      [disabled]="!!step.invalid"
                      (click)="activateCallback(steps[i + 1].value)"
                    ></extra-button>
                  }
                </div>
              </ng-template>
            </p-step-panel>
          }
        </p-step-panels>
      }

      @if (orientation === 'vertical') {
        @for (step of steps; track step.value; let i = $index; let first = $first; let last = $last) {
          <p-step-item [value]="step.value">
            <p-step
              [value]="step.value"
              [disabled]="step.disabled || false"
              [ngClass]="{ 'step-invalid': step.invalid }"
            >
              {{ step.label }}
              @if (step.caption) {
                <div class="caption-secondary">{{ step.caption }}</div>
              }
            </p-step>
            @if (showPanels) {
              <p-step-panel [value]="step.value">
                <ng-template #content let-activateCallback="activateCallback">
                  <p class="m-0">{{ step.content }}</p>
                  <div class="flex gap-2 pt-4">
                    @if (!first) {
                      <extra-button
                        label="Назад"
                        variant="tertiary"
                        (click)="activateCallback(steps[i - 1].value)"
                      ></extra-button>
                    }
                    @if (!last) {
                      <extra-button
                        label="Вперёд"
                        variant="secondary"
                        [disabled]="!!step.invalid"
                        (click)="activateCallback(steps[i + 1].value)"
                      ></extra-button>
                    }
                  </div>
                </ng-template>
              </p-step-panel>
            }
          </p-step-item>
        }
      }
    </p-stepper>
  `, isInline: true, dependencies: [{ kind: "component", type: Stepper, selector: "p-stepper", inputs: ["value", "linear", "transitionOptions"], outputs: ["valueChange"] }, { kind: "component", type: StepList, selector: "p-step-list" }, { kind: "component", type: Step, selector: "p-step", inputs: ["value", "disabled"], outputs: ["valueChange"] }, { kind: "component", type: StepPanels, selector: "p-step-panels" }, { kind: "component", type: StepPanel, selector: "p-step-panel", inputs: ["value"], outputs: ["valueChange"] }, { kind: "component", type: StepItem, selector: "p-step-item", inputs: ["value"], outputs: ["valueChange"] }, { kind: "component", type: ExtraButtonComponent, selector: "extra-button", inputs: ["label", "icon", "iconPosition", "variant", "severity", "size", "rounded", "fluid", "disabled", "loading"], outputs: ["focus", "blur"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraStepperComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-stepper',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Stepper, StepList, Step, StepPanels, StepPanel, StepItem, ExtraButtonComponent, NgClass],
                    template: `
    <p-stepper [value]="value" [linear]="linear" (valueChange)="onValueChange($event)">
      @if (orientation === 'horizontal') {
        <p-step-list>
          @for (step of steps; track step.value) {
            <p-step
              [value]="step.value"
              [disabled]="step.disabled || false"
              [ngClass]="{ 'step-invalid': step.invalid }"
            >
              {{ step.label }}
              @if (step.caption) {
                <div class="caption-secondary">{{ step.caption }}</div>
              }
            </p-step>
          }
        </p-step-list>
      }
      @if (orientation === 'horizontal' && showPanels) {
        <p-step-panels>
          @for (step of steps; track step.value; let i = $index; let first = $first; let last = $last) {
            <p-step-panel [value]="step.value">
              <ng-template #content let-activateCallback="activateCallback">
                <p class="m-0">{{ step.content }}</p>
                <div class="flex pt-4">
                  @if (!first) {
                    <extra-button
                      label="Назад"
                      variant="tertiary"
                      (click)="activateCallback(steps[i - 1].value)"
                    ></extra-button>
                  }
                  @if (!last) {
                    <extra-button
                      label="Вперёд"
                      variant="secondary"
                      class="ml-auto"
                      [disabled]="!!step.invalid"
                      (click)="activateCallback(steps[i + 1].value)"
                    ></extra-button>
                  }
                </div>
              </ng-template>
            </p-step-panel>
          }
        </p-step-panels>
      }

      @if (orientation === 'vertical') {
        @for (step of steps; track step.value; let i = $index; let first = $first; let last = $last) {
          <p-step-item [value]="step.value">
            <p-step
              [value]="step.value"
              [disabled]="step.disabled || false"
              [ngClass]="{ 'step-invalid': step.invalid }"
            >
              {{ step.label }}
              @if (step.caption) {
                <div class="caption-secondary">{{ step.caption }}</div>
              }
            </p-step>
            @if (showPanels) {
              <p-step-panel [value]="step.value">
                <ng-template #content let-activateCallback="activateCallback">
                  <p class="m-0">{{ step.content }}</p>
                  <div class="flex gap-2 pt-4">
                    @if (!first) {
                      <extra-button
                        label="Назад"
                        variant="tertiary"
                        (click)="activateCallback(steps[i - 1].value)"
                      ></extra-button>
                    }
                    @if (!last) {
                      <extra-button
                        label="Вперёд"
                        variant="secondary"
                        [disabled]="!!step.invalid"
                        (click)="activateCallback(steps[i + 1].value)"
                      ></extra-button>
                    }
                  </div>
                </ng-template>
              </p-step-panel>
            }
          </p-step-item>
        }
      }
    </p-stepper>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], steps: [{
                type: Input
            }], linear: [{
                type: Input
            }], orientation: [{
                type: Input
            }], showPanels: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraStepperComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-stepper.mjs.map
