import * as i0 from '@angular/core';
import { Input, Directive, EventEmitter, inject, ElementRef, ChangeDetectorRef, ContentChildren, ViewChild, Output, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT, NgTemplateOutlet } from '@angular/common';
import { Menu } from 'primeng/menu';
import { PrimeTemplate } from 'primeng/api';

/**
 * Именованный шаблон для слотов ExtraMenuComponent.
 *
 * ```html
 * <extra-menu [items]="items">
 *   <ng-template extraMenuTemplate="start">…</ng-template>
 *   <ng-template extraMenuTemplate="item" let-item>…</ng-template>
 *   <ng-template extraMenuTemplate="submenuHeader" let-group>…</ng-template>
 *   <ng-template extraMenuTemplate="end">…</ng-template>
 * </extra-menu>
 * ```
 */
class ExtraMenuTemplateDirective {
    template;
    /** Имя слота: item | submenuHeader | start | end. */
    extraMenuTemplate;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenuTemplateDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraMenuTemplateDirective, isStandalone: true, selector: "[extraMenuTemplate]", inputs: { extraMenuTemplate: "extraMenuTemplate" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenuTemplateDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[extraMenuTemplate]'
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { extraMenuTemplate: [{
                type: Input,
                args: [{ required: true }]
            }] } });

function isMenuSeparator(item) {
    return item.separator === true;
}
function isMenuGroup(item) {
    return Array.isArray(item.items);
}
class ExtraMenuComponent {
    items = [];
    popup = false;
    open = false;
    appendTo = 'body';
    ariaLabel;
    onItemSelect = new EventEmitter();
    onShow = new EventEmitter();
    onHide = new EventEmitter();
    menuRef;
    templates;
    itemTpl;
    submenuHeaderTpl;
    startTpl;
    endTpl;
    elementRef = inject(ElementRef);
    document = inject(DOCUMENT);
    cdr = inject(ChangeDetectorRef);
    syntheticAnchor;
    suppressOpenSync = false;
    get resolvedAppendTo() {
        if (this.appendTo === 'self')
            return undefined;
        if (this.appendTo === 'body')
            return 'body';
        return this.appendTo instanceof ElementRef ? this.appendTo.nativeElement : this.appendTo;
    }
    primeItems = [];
    ngOnChanges(changes) {
        if (changes['items'])
            this.syncPrimeItems();
        if (changes['open'] && !changes['open'].firstChange && !this.suppressOpenSync) {
            if (this.open)
                this.show();
            else
                this.hide();
        }
    }
    ngAfterContentInit() {
        this.itemTpl = this.templates.find((tpl) => tpl.extraMenuTemplate === 'item');
        this.submenuHeaderTpl = this.templates.find((tpl) => tpl.extraMenuTemplate === 'submenuHeader');
        this.startTpl = this.templates.find((tpl) => tpl.extraMenuTemplate === 'start');
        this.endTpl = this.templates.find((tpl) => tpl.extraMenuTemplate === 'end');
        this.cdr.detectChanges();
    }
    ngAfterViewInit() {
        if (this.open)
            this.show();
    }
    ngOnDestroy() {
        this.clearSyntheticAnchor();
    }
    /** Переключить всплывающее меню. */
    toggle(anchor) {
        if (this.menuRef.visible)
            this.hide();
        else
            this.show(anchor);
    }
    /** Открыть всплывающее меню. При отсутствии anchor используется хост-элемент компонента. */
    show(anchor) {
        this.menuRef.show(this.toPrimeAnchorEvent(anchor));
    }
    /** Закрыть всплывающее меню. */
    hide() {
        this.menuRef.hide();
        this.clearSyntheticAnchor();
    }
    handleShow() {
        this.syncOpen(true);
        this.onShow.emit();
    }
    handleHide() {
        this.syncOpen(false);
        this.onHide.emit();
    }
    /**
     * PrimeNG раздаёт `model` через *ngFor без trackBy: новый объект пункта — это пересоздание
     * <li>, вместе с которым обрывается CSS-переход. Поэтому элементы живут между обновлениями
     * `items`, меняются только их поля — это и сохраняет identity для *ngFor.
     *
     * Сам массив-обёртка при этом всегда новый: p-menu — отдельный OnPush-компонент, и если бы
     * [model] получал ту же ссылку, что и в прошлый раз, Angular не гарантирует p-menu корректный
     * повторный проход (наблюдалось состояние, где заголовок группы обновился, а её дети — нет).
     * Одна лишняя аллокация маленького массива несравнимо дешевле такой рассинхронизации.
     */
    syncPrimeItems() {
        this.primeItems = [
            ...this.mergePrimeItems(this.primeItems, this.items.map((item) => this.toPrimeItem(item)))
        ];
    }
    mergePrimeItems(current, next) {
        if (current.length !== next.length)
            return next;
        next.forEach((item, index) => {
            const target = current[index];
            const nested = target.items;
            this.resetToShapeOf(target, item);
            Object.assign(target, item);
            if (nested && item.items)
                target.items = this.mergePrimeItems(nested, item.items);
        });
        return current;
    }
    /**
     * Object.assign не удаляет поля, которых нет в источнике. Если на том же индексе пункт сменил
     * "вид" (была группа с `items`, стал экшен без него, или наоборот) — старые поля продолжали бы
     * висеть на объекте: например, стейл `items` заставлял бы PrimeNG `hasSubMenu()` и дальше
     * считать пункт группой. Стираем всё, чего нет в новой форме, перед тем как наложить её поля.
     */
    resetToShapeOf(target, shape) {
        for (const key of Object.keys(target)) {
            if (!(key in shape))
                delete target[key];
        }
    }
    /** Держит [open] в согласии с реальной видимостью после show()/hide() или клика по пункту. */
    syncOpen(open) {
        if (this.open === open)
            return;
        this.suppressOpenSync = true;
        this.open = open;
        this.suppressOpenSync = false;
    }
    /** PrimeNG `show()` вычисляет якорь из `event.currentTarget` — нормализуем под это. */
    toPrimeAnchorEvent(anchor) {
        if (!anchor)
            return { currentTarget: this.elementRef.nativeElement };
        if (anchor instanceof Event)
            return { currentTarget: this.resolveEventAnchor(anchor) };
        if (anchor instanceof ElementRef)
            return { currentTarget: anchor.nativeElement };
        if (anchor instanceof HTMLElement)
            return { currentTarget: anchor };
        return { currentTarget: this.createCoordinateAnchor(anchor.x, anchor.y) };
    }
    /**
     * Обёртки кита (`<extra-button>`) — инлайновые элементы: их getBoundingClientRect() описывает
     * строку текста, а не отрисованную кнопку, и меню всплывает поверх триггера. Берём из цепочки
     * события ближайший интерактивный элемент — он и есть реальный якорь.
     */
    resolveEventAnchor(event) {
        const currentTarget = event.currentTarget;
        const trigger = event.target?.closest('button, a, [role="button"]');
        if (trigger && currentTarget?.contains(trigger))
            return trigger;
        return currentTarget ?? event.target ?? this.elementRef.nativeElement;
    }
    /** Координатный якорь: PrimeNG позиционирует меню через getBoundingClientRect() реального элемента. */
    createCoordinateAnchor(x, y) {
        this.clearSyntheticAnchor();
        const el = this.document.createElement('div');
        el.style.position = 'fixed';
        el.style.left = `${x}px`;
        el.style.top = `${y}px`;
        el.style.width = '0';
        el.style.height = '0';
        this.document.body.appendChild(el);
        this.syntheticAnchor = el;
        return el;
    }
    clearSyntheticAnchor() {
        this.syntheticAnchor?.remove();
        this.syntheticAnchor = undefined;
    }
    toPrimeItem(item) {
        if (isMenuSeparator(item))
            return { separator: true };
        if (isMenuGroup(item)) {
            return {
                label: item.label,
                visible: item.visible,
                id: item.id,
                items: item.items.map((action) => this.toPrimeAction(action))
            };
        }
        return this.toPrimeAction(item);
    }
    /**
     * Спека называет поле ссылки `href`, PrimeNG читает `url` для решения "это реальная ссылка,
     * не звать preventDefault()". Кладём оба — `href` остаётся в контексте слота `item` как есть.
     */
    toPrimeAction(action) {
        return {
            label: action.label,
            caption: action.caption,
            icon: action.icon,
            iconEnd: action.iconEnd,
            selected: action.selected,
            disabled: action.disabled,
            visible: action.visible,
            id: action.id,
            styleClass: action.selected ? 'p-menuitem-checked' : undefined,
            href: action.href,
            target: action.target,
            url: action.href,
            command: (event) => {
                const selectEvent = { item: action, originalEvent: event.originalEvent };
                action.command?.(selectEvent);
                this.onItemSelect.emit(selectEvent);
            }
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraMenuComponent, isStandalone: true, selector: "extra-menu", inputs: { items: "items", popup: "popup", open: "open", appendTo: "appendTo", ariaLabel: "ariaLabel" }, outputs: { onItemSelect: "onItemSelect", onShow: "onShow", onHide: "onHide" }, host: { styleAttribute: "display: contents" }, queries: [{ propertyName: "templates", predicate: ExtraMenuTemplateDirective }], viewQueries: [{ propertyName: "menuRef", first: true, predicate: ["menuRef"], descendants: true }], usesOnChanges: true, ngImport: i0, template: `
    <p-menu
      #menuRef
      [model]="primeItems"
      [popup]="popup"
      [appendTo]="resolvedAppendTo"
      [ariaLabel]="ariaLabel"
      (onShow)="handleShow()"
      (onHide)="handleHide()"
    >
      @if (startTpl) {
        <ng-template pTemplate="start">
          <ng-container [ngTemplateOutlet]="startTpl.template"></ng-container>
        </ng-template>
      }
      <ng-template pTemplate="submenuheader" let-submenu>
        @if (submenuHeaderTpl) {
          <ng-container
            [ngTemplateOutlet]="submenuHeaderTpl.template"
            [ngTemplateOutletContext]="{ $implicit: submenu }"
          ></ng-container>
        } @else {
          {{ submenu.label }}
        }
      </ng-template>
      <ng-template pTemplate="item" let-item>
        @if (itemTpl) {
          <ng-container
            [ngTemplateOutlet]="itemTpl.template"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        } @else {
          <a
            class="p-menu-item-link"
            [attr.tabindex]="-1"
            [class.p-disabled]="item.disabled"
            [attr.href]="item.href || null"
            [attr.target]="item.target || null"
          >
            @if (item.icon) {
              <span [class]="item.icon + ' p-menu-item-icon'"></span>
            }
            @if (item.caption) {
              <div class="menu-item-label">
                <span class="p-menu-item-label">{{ item.label }}</span>
                <small class="menu-item-caption">{{ item.caption }}</small>
              </div>
            } @else {
              <span class="p-menu-item-label">{{ item.label }}</span>
            }
            @if (item.iconEnd) {
              <span [class]="item.iconEnd + ' p-menu-item-icon-end'"></span>
            }
          </a>
        }
      </ng-template>
      @if (endTpl) {
        <ng-template pTemplate="end">
          <ng-container [ngTemplateOutlet]="endTpl.template"></ng-container>
        </ng-template>
      }
    </p-menu>
  `, isInline: true, dependencies: [{ kind: "component", type: Menu, selector: "p-menu", inputs: ["model", "popup", "style", "styleClass", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "ariaLabel", "ariaLabelledBy", "id", "tabindex", "appendTo"], outputs: ["onShow", "onHide", "onBlur", "onFocus"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-menu',
                    host: { style: 'display: contents' },
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Menu, PrimeTemplate, NgTemplateOutlet],
                    template: `
    <p-menu
      #menuRef
      [model]="primeItems"
      [popup]="popup"
      [appendTo]="resolvedAppendTo"
      [ariaLabel]="ariaLabel"
      (onShow)="handleShow()"
      (onHide)="handleHide()"
    >
      @if (startTpl) {
        <ng-template pTemplate="start">
          <ng-container [ngTemplateOutlet]="startTpl.template"></ng-container>
        </ng-template>
      }
      <ng-template pTemplate="submenuheader" let-submenu>
        @if (submenuHeaderTpl) {
          <ng-container
            [ngTemplateOutlet]="submenuHeaderTpl.template"
            [ngTemplateOutletContext]="{ $implicit: submenu }"
          ></ng-container>
        } @else {
          {{ submenu.label }}
        }
      </ng-template>
      <ng-template pTemplate="item" let-item>
        @if (itemTpl) {
          <ng-container
            [ngTemplateOutlet]="itemTpl.template"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        } @else {
          <a
            class="p-menu-item-link"
            [attr.tabindex]="-1"
            [class.p-disabled]="item.disabled"
            [attr.href]="item.href || null"
            [attr.target]="item.target || null"
          >
            @if (item.icon) {
              <span [class]="item.icon + ' p-menu-item-icon'"></span>
            }
            @if (item.caption) {
              <div class="menu-item-label">
                <span class="p-menu-item-label">{{ item.label }}</span>
                <small class="menu-item-caption">{{ item.caption }}</small>
              </div>
            } @else {
              <span class="p-menu-item-label">{{ item.label }}</span>
            }
            @if (item.iconEnd) {
              <span [class]="item.iconEnd + ' p-menu-item-icon-end'"></span>
            }
          </a>
        }
      </ng-template>
      @if (endTpl) {
        <ng-template pTemplate="end">
          <ng-container [ngTemplateOutlet]="endTpl.template"></ng-container>
        </ng-template>
      }
    </p-menu>
  `
                }]
        }], propDecorators: { items: [{
                type: Input
            }], popup: [{
                type: Input
            }], open: [{
                type: Input
            }], appendTo: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], onItemSelect: [{
                type: Output
            }], onShow: [{
                type: Output
            }], onHide: [{
                type: Output
            }], menuRef: [{
                type: ViewChild,
                args: ['menuRef']
            }], templates: [{
                type: ContentChildren,
                args: [ExtraMenuTemplateDirective]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraMenuComponent, ExtraMenuTemplateDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-menu.mjs.map
