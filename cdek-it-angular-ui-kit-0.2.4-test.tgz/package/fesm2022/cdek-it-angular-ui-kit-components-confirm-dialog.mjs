import * as i0 from '@angular/core';
import { Directive, TemplateRef, ContentChild, Input, Component, Injectable } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { ConfirmDialog } from 'primeng/confirmdialog';
import * as i1 from 'primeng/api';
import { PrimeTemplate, ConfirmationService } from 'primeng/api';
import { ExtraButtonComponent } from '@cdek-it/angular-ui-kit/components/button';

class ExtraConfirmDialogHeaderDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraConfirmDialogHeaderDirective, isStandalone: true, selector: "[extraConfirmDialogHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraConfirmDialogHeader]', standalone: true }]
        }] });
class ExtraConfirmDialogFooterDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraConfirmDialogFooterDirective, isStandalone: true, selector: "[extraConfirmDialogFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraConfirmDialogFooter]', standalone: true }]
        }] });
class ExtraConfirmDialogComponent {
    key = '';
    size = 'default';
    severity = 'default';
    headerTemplate = null;
    footerTemplate = null;
    mapSeverity(severity) {
        if (severity === 'danger' || severity === 'warn' || severity === 'warning')
            return severity === 'warn' ? 'warning' : severity;
        if (severity === 'success' || severity === 'info')
            return severity;
        return 'base';
    }
    get computedClass() {
        const classes = [];
        if (this.size === 'sm')
            classes.push('p-confirmdialog-sm');
        else if (this.size === 'lg')
            classes.push('p-confirmdialog-lg');
        else if (this.size === 'xlg')
            classes.push('p-confirmdialog-xlg');
        const severityMap = {
            success: 'p-confirm-dialog-accept',
            info: 'p-confirm-dialog-info',
            warning: 'p-confirm-dialog-warn',
            help: 'p-confirm-dialog-help',
            danger: 'p-confirm-dialog-error',
            default: ''
        };
        if (severityMap[this.severity])
            classes.push(severityMap[this.severity]);
        return classes.join(' ');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraConfirmDialogComponent, isStandalone: true, selector: "extra-confirm-dialog", inputs: { key: "key", size: "size", severity: "severity" }, host: { styleAttribute: "display: contents" }, queries: [{ propertyName: "headerTemplate", first: true, predicate: ExtraConfirmDialogHeaderDirective, descendants: true, read: TemplateRef }, { propertyName: "footerTemplate", first: true, predicate: ExtraConfirmDialogFooterDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-confirmDialog [key]="key" [styleClass]="computedClass" appendTo="body">
      <ng-template pTemplate="headless" let-message let-onAccept="onAccept" let-onReject="onReject">
        @if (headerTemplate) {
          <ng-container
            [ngTemplateOutlet]="headerTemplate"
            [ngTemplateOutletContext]="{ $implicit: message, onAccept, onReject }"
          >
          </ng-container>
        } @else {
          <div class="p-dialog-header">
            <div class="p-dialog-title">
              <i [class]="message.icon"></i>
              <span>{{ message.header }}</span>
            </div>
            <extra-button
              variant="text"
              icon="ti ti-x"
              [rounded]="true"
              (click)="onReject()"
            ></extra-button>
          </div>
        }
        <div class="p-dialog-content">
          <p>{{ message.message }}</p>
        </div>
        @if (footerTemplate) {
          <ng-container
            [ngTemplateOutlet]="footerTemplate"
            [ngTemplateOutletContext]="{ $implicit: message, onAccept, onReject }"
          >
          </ng-container>
        } @else {
          <div class="p-dialog-footer">
            <extra-button [label]="message.rejectLabel" variant="text" (click)="onReject()"></extra-button>
            <extra-button
              [label]="message.acceptLabel"
              [severity]="mapSeverity(message.acceptButtonProps?.severity)"
              (click)="onAccept()"
            ></extra-button>
          </div>
        }
      </ng-template>
    </p-confirmDialog>
  `, isInline: true, dependencies: [{ kind: "component", type: ConfirmDialog, selector: "p-confirmDialog, p-confirmdialog, p-confirm-dialog", inputs: ["header", "icon", "message", "style", "styleClass", "maskStyleClass", "acceptIcon", "acceptLabel", "closeAriaLabel", "acceptAriaLabel", "acceptVisible", "rejectIcon", "rejectLabel", "rejectAriaLabel", "rejectVisible", "acceptButtonStyleClass", "rejectButtonStyleClass", "closeOnEscape", "dismissableMask", "blockScroll", "rtl", "closable", "appendTo", "key", "autoZIndex", "baseZIndex", "transitionOptions", "focusTrap", "defaultFocus", "breakpoints", "modal", "visible", "position", "draggable"], outputs: ["onHide"] }, { kind: "component", type: ExtraButtonComponent, selector: "extra-button", inputs: ["label", "icon", "iconPosition", "variant", "severity", "size", "rounded", "fluid", "disabled", "loading"], outputs: ["focus", "blur"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-confirm-dialog',
                    host: { style: 'display: contents' },
                    standalone: true,
                    imports: [ConfirmDialog, ExtraButtonComponent, PrimeTemplate, NgTemplateOutlet],
                    template: `
    <p-confirmDialog [key]="key" [styleClass]="computedClass" appendTo="body">
      <ng-template pTemplate="headless" let-message let-onAccept="onAccept" let-onReject="onReject">
        @if (headerTemplate) {
          <ng-container
            [ngTemplateOutlet]="headerTemplate"
            [ngTemplateOutletContext]="{ $implicit: message, onAccept, onReject }"
          >
          </ng-container>
        } @else {
          <div class="p-dialog-header">
            <div class="p-dialog-title">
              <i [class]="message.icon"></i>
              <span>{{ message.header }}</span>
            </div>
            <extra-button
              variant="text"
              icon="ti ti-x"
              [rounded]="true"
              (click)="onReject()"
            ></extra-button>
          </div>
        }
        <div class="p-dialog-content">
          <p>{{ message.message }}</p>
        </div>
        @if (footerTemplate) {
          <ng-container
            [ngTemplateOutlet]="footerTemplate"
            [ngTemplateOutletContext]="{ $implicit: message, onAccept, onReject }"
          >
          </ng-container>
        } @else {
          <div class="p-dialog-footer">
            <extra-button [label]="message.rejectLabel" variant="text" (click)="onReject()"></extra-button>
            <extra-button
              [label]="message.acceptLabel"
              [severity]="mapSeverity(message.acceptButtonProps?.severity)"
              (click)="onAccept()"
            ></extra-button>
          </div>
        }
      </ng-template>
    </p-confirmDialog>
  `
                }]
        }], propDecorators: { key: [{
                type: Input
            }], size: [{
                type: Input
            }], severity: [{
                type: Input
            }], headerTemplate: [{
                type: ContentChild,
                args: [ExtraConfirmDialogHeaderDirective, { read: TemplateRef }]
            }], footerTemplate: [{
                type: ContentChild,
                args: [ExtraConfirmDialogFooterDirective, { read: TemplateRef }]
            }] } });

function provideExtraConfirmDialog() {
    return [ConfirmationService, ExtraConfirmDialogService];
}
class ExtraConfirmDialogService {
    confirmationService;
    constructor(confirmationService) {
        this.confirmationService = confirmationService;
    }
    confirm(options) {
        this.confirmationService.confirm(options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogService, deps: [{ token: i1.ConfirmationService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraConfirmDialogService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.ConfirmationService }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraConfirmDialogComponent, ExtraConfirmDialogFooterDirective, ExtraConfirmDialogHeaderDirective, ExtraConfirmDialogService, provideExtraConfirmDialog };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-confirm-dialog.mjs.map
