import * as i0 from '@angular/core';
import { inject, Injector, ChangeDetectorRef, DestroyRef, EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormControl, NgControl, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { InputOtp } from 'primeng/inputotp';

class ExtraInputOtpComponent {
    _injector = inject(Injector);
    _cdr = inject(ChangeDetectorRef);
    destroyRef = inject(DestroyRef);
    _ngControl = null;
    control = new FormControl(null);
    length = 4;
    mask = false;
    integerOnly = false;
    /** Размер ячейки. */
    size = 'base';
    disabled = false;
    /** PrimeNG знает только small/large; base — размер по умолчанию, без класса. */
    get primeSize() {
        return this.size === 'base' ? undefined : this.size;
    }
    onChange = new EventEmitter();
    _onChange = () => { };
    _onTouched = () => { };
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
        this.control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((v) => {
            this._onChange(v);
            this._onTouched();
        });
        /**
         * invalid — геттер поверх NgControl.invalid; на OnPush не пересчитывается сам по себе,
         * когда валидность меняется извне (Validators/updateValueAndValidity без локального события).
         */
        this._ngControl?.statusChanges?.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this._cdr.markForCheck());
    }
    get invalid() {
        return this._ngControl?.invalid ?? false;
    }
    onChangeHandler(event) {
        this.onChange.emit({ value: event.value, originalEvent: event.originalEvent });
    }
    writeValue(value) {
        this.control.setValue(value ?? null, { emitEvent: false });
        this._cdr.markForCheck();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        isDisabled ? this.control.disable({ emitEvent: false }) : this.control.enable({ emitEvent: false });
        this._cdr.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputOtpComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraInputOtpComponent, isStandalone: true, selector: "extra-input-otp", inputs: { length: "length", mask: "mask", integerOnly: "integerOnly", size: "size" }, outputs: { onChange: "onChange" }, host: { styleAttribute: "display: contents" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraInputOtpComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    <p-inputotp
      [length]="length"
      [mask]="mask"
      [integerOnly]="integerOnly"
      [size]="primeSize"
      [disabled]="disabled"
      [invalid]="invalid"
      [formControl]="control"
      (onChange)="onChangeHandler($event)"
    ></p-inputotp>
  `, isInline: true, dependencies: [{ kind: "component", type: InputOtp, selector: "p-inputOtp, p-inputotp, p-input-otp", inputs: ["readonly", "tabindex", "length", "styleClass", "mask", "integerOnly", "autofocus", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputOtpComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-input-otp',
                    standalone: true,
                    imports: [InputOtp, ReactiveFormsModule],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { style: 'display: contents' },
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraInputOtpComponent),
                            multi: true
                        }
                    ],
                    template: `
    <p-inputotp
      [length]="length"
      [mask]="mask"
      [integerOnly]="integerOnly"
      [size]="primeSize"
      [disabled]="disabled"
      [invalid]="invalid"
      [formControl]="control"
      (onChange)="onChangeHandler($event)"
    ></p-inputotp>
  `
                }]
        }], propDecorators: { length: [{
                type: Input
            }], mask: [{
                type: Input
            }], integerOnly: [{
                type: Input
            }], size: [{
                type: Input
            }], onChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraInputOtpComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-inputotp.mjs.map
