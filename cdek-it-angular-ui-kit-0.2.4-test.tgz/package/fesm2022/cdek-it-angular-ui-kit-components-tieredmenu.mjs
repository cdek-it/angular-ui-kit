import * as i0 from '@angular/core';
import { HostListener, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { TieredMenu } from 'primeng/tieredmenu';

class ExtraTieredMenuComponent {
    el;
    model = [];
    autoDisplay = true;
    tabindex = undefined;
    activeItemId = null;
    constructor(el) {
        this.el = el;
    }
    onItemClick(event) {
        const target = event.target;
        const item = target.closest('.p-tieredmenu-item');
        if (!item)
            return;
        const hasSubmenu = item.querySelector(':scope > .p-tieredmenu-submenu, :scope > [class*="content-container"]');
        if (hasSubmenu)
            return;
        this.activeItemId = item.id || null;
        this.applyActiveClass();
    }
    ngAfterViewChecked() {
        if (this.activeItemId) {
            this.applyActiveClass();
        }
    }
    applyActiveClass() {
        const root = this.el.nativeElement;
        root
            .querySelectorAll('.p-tieredmenu-item-checked')
            .forEach((el) => el.classList.remove('p-tieredmenu-item-checked'));
        if (this.activeItemId) {
            const active = root.querySelector(`#${CSS.escape(this.activeItemId)}`);
            if (active) {
                active.classList.add('p-tieredmenu-item-checked');
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTieredMenuComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraTieredMenuComponent, isStandalone: true, selector: "extra-tieredmenu", inputs: { model: "model", autoDisplay: "autoDisplay", tabindex: "tabindex" }, host: { listeners: { "click": "onItemClick($event)" } }, ngImport: i0, template: ` <p-tieredmenu [model]="model" [autoDisplay]="autoDisplay" [tabindex]="tabindex"></p-tieredmenu> `, isInline: true, dependencies: [{ kind: "component", type: TieredMenu, selector: "p-tieredMenu, p-tieredmenu, p-tiered-menu", inputs: ["model", "popup", "style", "styleClass", "breakpoint", "autoZIndex", "baseZIndex", "autoDisplay", "showTransitionOptions", "hideTransitionOptions", "id", "ariaLabel", "ariaLabelledBy", "disabled", "tabindex", "appendTo"], outputs: ["onShow", "onHide"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTieredMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-tieredmenu',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [TieredMenu],
                    template: ` <p-tieredmenu [model]="model" [autoDisplay]="autoDisplay" [tabindex]="tabindex"></p-tieredmenu> `
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { model: [{
                type: Input
            }], autoDisplay: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], onItemClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraTieredMenuComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-tieredmenu.mjs.map
