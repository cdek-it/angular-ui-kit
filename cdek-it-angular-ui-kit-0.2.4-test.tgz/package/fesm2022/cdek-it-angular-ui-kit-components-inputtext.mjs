import * as i0 from '@angular/core';
import { inject, Injector, EventEmitter, forwardRef, booleanAttribute, Output, Input, Component } from '@angular/core';
import { NgControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import { InputText } from 'primeng/inputtext';
import { IconField } from 'primeng/iconfield';
import { InputIcon } from 'primeng/inputicon';
import { FloatLabel } from 'primeng/floatlabel';
import { ExtraTooltipDirective } from '@cdek-it/angular-ui-kit/components/tooltip';

let nextInputId = 0;
class ExtraInputTextComponent {
    _injector = inject(Injector);
    _ngControl = null;
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
    }
    placeholder = '';
    label = '';
    labelPosition = 'default';
    clearable = false;
    caption = '';
    info = '';
    size = 'base';
    /** Растягивает поле на всю ширину контейнера. */
    fluid = false;
    type = 'text';
    /** Уникальный id поля для связи label ↔ input. */
    inputId = `extra-input-text-${nextInputId++}`;
    disabled = false;
    get invalid() {
        return this._ngControl?.invalid ?? false;
    }
    onClear = new EventEmitter();
    modelValue = '';
    _onChange = () => { };
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large' || this.size === 'xlarge')
            return 'large';
        return undefined;
    }
    get sizeClass() {
        return { 'p-inputtext-xlg': this.size === 'xlarge' };
    }
    onInput(event) {
        const value = event.target.value;
        this.modelValue = value;
        this._onChange(value);
    }
    onTouched = () => { };
    clearValue() {
        this.modelValue = '';
        this._onChange('');
        this.onClear.emit();
    }
    writeValue(value) {
        this.modelValue = value ?? '';
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputTextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraInputTextComponent, isStandalone: true, selector: "extra-input-text", inputs: { placeholder: "placeholder", label: "label", labelPosition: "labelPosition", clearable: ["clearable", "clearable", booleanAttribute], caption: "caption", info: "info", size: "size", fluid: ["fluid", "fluid", booleanAttribute], type: "type" }, outputs: { onClear: "onClear" }, host: { styleAttribute: "display: contents" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraInputTextComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    <!-- Без label/caption поле не оборачиваем — сохраняем прежнюю DOM-структуру
         (важно для p-inputgroup, где input обязан быть прямым flex-элементом). -->
    @if (label || caption) {
      <div class="extra-inputtext" [class.extra-inputtext--left]="labelPosition === 'left'">
        @if (label && labelPosition === 'left') {
          <ng-container [ngTemplateOutlet]="labelTpl" />
        }
        <div class="extra-inputtext-body">
          @if (label && labelPosition === 'default') {
            <ng-container [ngTemplateOutlet]="labelTpl" />
          }
          @if (labelPosition === 'float') {
            <p-floatlabel variant="in">
              <ng-container [ngTemplateOutlet]="fieldTpl" />
              @if (label) {
                <ng-container [ngTemplateOutlet]="labelTpl" />
              }
            </p-floatlabel>
          } @else {
            <ng-container [ngTemplateOutlet]="fieldTpl" />
          }
          @if (caption) {
            <div class="extra-inputtext-caption">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="fieldTpl" />
    }

    <ng-template #labelTpl>
      <label class="extra-inputtext-label" [for]="inputId">
        {{ label }}
        @if (info) {
          <i class="extra-inputtext-label-icon ti ti-info-circle" [extra-tooltip]="info"></i>
        }
      </label>
    </ng-template>

    <ng-template #fieldTpl>
      @if (clearable) {
        <p-iconfield>
          <input
            pInputText
            [id]="inputId"
            [ngClass]="sizeClass"
            [pSize]="primeSize!"
            [fluid]="fluid"
            [type]="type"
            [disabled]="disabled"
            [invalid]="invalid"
            [attr.placeholder]="placeholder || null"
            [value]="modelValue"
            (input)="onInput($event)"
            (blur)="onTouched()"
          />
          <p-inputicon
            class="ti ti-x"
            tabindex="0"
            [style.visibility]="modelValue ? 'visible' : 'hidden'"
            [style.pointerEvents]="modelValue ? 'auto' : 'none'"
            (click)="clearValue()"
            (keydown.enter)="clearValue()"
            (keydown.space)="clearValue()"
          ></p-inputicon>
        </p-iconfield>
      } @else {
        <input
          pInputText
          [id]="inputId"
          [ngClass]="sizeClass"
          [pSize]="primeSize!"
          [fluid]="fluid"
          [type]="type"
          [disabled]="disabled"
          [invalid]="invalid"
          [attr.placeholder]="placeholder || null"
          [value]="modelValue"
          (input)="onInput($event)"
          (blur)="onTouched()"
        />
      }
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "directive", type: InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pSize", "variant", "fluid", "invalid"] }, { kind: "component", type: IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "component", type: InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: ExtraTooltipDirective, selector: "[extra-tooltip]", inputs: ["extra-tooltip", "position", "event", "showDelay", "hideDelay", "tooltipDisabled"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputTextComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-input-text',
                    standalone: true,
                    imports: [InputText, IconField, InputIcon, FloatLabel, NgClass, NgTemplateOutlet, ExtraTooltipDirective],
                    host: { style: 'display: contents' },
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraInputTextComponent),
                            multi: true
                        }
                    ],
                    template: `
    <!-- Без label/caption поле не оборачиваем — сохраняем прежнюю DOM-структуру
         (важно для p-inputgroup, где input обязан быть прямым flex-элементом). -->
    @if (label || caption) {
      <div class="extra-inputtext" [class.extra-inputtext--left]="labelPosition === 'left'">
        @if (label && labelPosition === 'left') {
          <ng-container [ngTemplateOutlet]="labelTpl" />
        }
        <div class="extra-inputtext-body">
          @if (label && labelPosition === 'default') {
            <ng-container [ngTemplateOutlet]="labelTpl" />
          }
          @if (labelPosition === 'float') {
            <p-floatlabel variant="in">
              <ng-container [ngTemplateOutlet]="fieldTpl" />
              @if (label) {
                <ng-container [ngTemplateOutlet]="labelTpl" />
              }
            </p-floatlabel>
          } @else {
            <ng-container [ngTemplateOutlet]="fieldTpl" />
          }
          @if (caption) {
            <div class="extra-inputtext-caption">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="fieldTpl" />
    }

    <ng-template #labelTpl>
      <label class="extra-inputtext-label" [for]="inputId">
        {{ label }}
        @if (info) {
          <i class="extra-inputtext-label-icon ti ti-info-circle" [extra-tooltip]="info"></i>
        }
      </label>
    </ng-template>

    <ng-template #fieldTpl>
      @if (clearable) {
        <p-iconfield>
          <input
            pInputText
            [id]="inputId"
            [ngClass]="sizeClass"
            [pSize]="primeSize!"
            [fluid]="fluid"
            [type]="type"
            [disabled]="disabled"
            [invalid]="invalid"
            [attr.placeholder]="placeholder || null"
            [value]="modelValue"
            (input)="onInput($event)"
            (blur)="onTouched()"
          />
          <p-inputicon
            class="ti ti-x"
            tabindex="0"
            [style.visibility]="modelValue ? 'visible' : 'hidden'"
            [style.pointerEvents]="modelValue ? 'auto' : 'none'"
            (click)="clearValue()"
            (keydown.enter)="clearValue()"
            (keydown.space)="clearValue()"
          ></p-inputicon>
        </p-iconfield>
      } @else {
        <input
          pInputText
          [id]="inputId"
          [ngClass]="sizeClass"
          [pSize]="primeSize!"
          [fluid]="fluid"
          [type]="type"
          [disabled]="disabled"
          [invalid]="invalid"
          [attr.placeholder]="placeholder || null"
          [value]="modelValue"
          (input)="onInput($event)"
          (blur)="onTouched()"
        />
      }
    </ng-template>
  `
                }]
        }], propDecorators: { placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], clearable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], caption: [{
                type: Input
            }], info: [{
                type: Input
            }], size: [{
                type: Input
            }], fluid: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], type: [{
                type: Input
            }], onClear: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraInputTextComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-inputtext.mjs.map
