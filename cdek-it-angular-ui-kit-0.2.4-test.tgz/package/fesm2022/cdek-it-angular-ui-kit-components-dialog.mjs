import * as i0 from '@angular/core';
import { Input, Directive, EventEmitter, Output, ContentChildren, ChangeDetectionStrategy, Component, Injector, Injectable } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Dialog } from 'primeng/dialog';
import { PrimeTemplate } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
export { DynamicDialogRef } from 'primeng/dynamicdialog';

/**
 * Именованный шаблон для слотов ExtraDialogComponent.
 *
 * ```html
 * <extra-dialog [visible]="visible">
 *   Основное содержимое окна (слот content)
 *   <ng-template extraDialogTemplate="header">…</ng-template>
 *   <ng-template extraDialogTemplate="footer">…</ng-template>
 * </extra-dialog>
 * ```
 */
class ExtraDialogTemplateDirective {
    template;
    /** Имя слота: header | footer. */
    extraDialogTemplate;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogTemplateDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraDialogTemplateDirective, isStandalone: true, selector: "[extraDialogTemplate]", inputs: { extraDialogTemplate: "extraDialogTemplate" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogTemplateDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[extraDialogTemplate]'
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { extraDialogTemplate: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ExtraDialogComponent {
    cdr;
    header = '';
    visible = false;
    /** Отображать маску (overlay) поверх интерфейса. */
    showOverlay = true;
    /** Кнопка разворота окна на весь экран. */
    showMaximize = false;
    /** Кнопка закрытия окна. */
    showClose = true;
    size = 'default';
    dismissableMask = false;
    closeOnEscape = true;
    focusOnShow = false;
    appendTo = 'body';
    templates;
    headerTpl;
    footerTpl;
    visibleChange = new EventEmitter();
    onShow = new EventEmitter();
    onHide = new EventEmitter();
    onMaximize = new EventEmitter();
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterContentInit() {
        this.headerTpl = this.templates.find((tpl) => tpl.extraDialogTemplate === 'header');
        this.footerTpl = this.templates.find((tpl) => tpl.extraDialogTemplate === 'footer');
        this.cdr.detectChanges();
    }
    get sizeClass() {
        if (this.size === 'sm')
            return 'p-dialog-sm';
        if (this.size === 'lg')
            return 'p-dialog-lg';
        if (this.size === 'xlg')
            return 'p-dialog-xlg';
        return '';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraDialogComponent, isStandalone: true, selector: "extra-dialog", inputs: { header: "header", visible: "visible", showOverlay: "showOverlay", showMaximize: "showMaximize", showClose: "showClose", size: "size", dismissableMask: "dismissableMask", closeOnEscape: "closeOnEscape", focusOnShow: "focusOnShow", appendTo: "appendTo" }, outputs: { visibleChange: "visibleChange", onShow: "onShow", onHide: "onHide", onMaximize: "onMaximize" }, host: { styleAttribute: "display: contents" }, queries: [{ propertyName: "templates", predicate: ExtraDialogTemplateDirective }], ngImport: i0, template: `
    <p-dialog
      [header]="header"
      [visible]="visible"
      (visibleChange)="visibleChange.emit($event)"
      [modal]="showOverlay"
      [closable]="showClose"
      [maximizable]="showMaximize"
      (onMaximize)="onMaximize.emit()"
      (onShow)="onShow.emit()"
      (onHide)="onHide.emit()"
      [dismissableMask]="dismissableMask"
      [closeOnEscape]="closeOnEscape"
      [focusOnShow]="focusOnShow"
      [styleClass]="sizeClass"
      [appendTo]="appendTo"
    >
      @if (headerTpl) {
        <ng-template pTemplate="header">
          <ng-container [ngTemplateOutlet]="headerTpl.template"></ng-container>
        </ng-template>
      }
      <ng-content></ng-content>
      @if (footerTpl) {
        <ng-template pTemplate="footer">
          <ng-container [ngTemplateOutlet]="footerTpl.template"></ng-container>
        </ng-template>
      }
    </p-dialog>
  `, isInline: true, dependencies: [{ kind: "component", type: Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-dialog',
                    host: { style: 'display: contents' },
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Dialog, NgTemplateOutlet, PrimeTemplate],
                    template: `
    <p-dialog
      [header]="header"
      [visible]="visible"
      (visibleChange)="visibleChange.emit($event)"
      [modal]="showOverlay"
      [closable]="showClose"
      [maximizable]="showMaximize"
      (onMaximize)="onMaximize.emit()"
      (onShow)="onShow.emit()"
      (onHide)="onHide.emit()"
      [dismissableMask]="dismissableMask"
      [closeOnEscape]="closeOnEscape"
      [focusOnShow]="focusOnShow"
      [styleClass]="sizeClass"
      [appendTo]="appendTo"
    >
      @if (headerTpl) {
        <ng-template pTemplate="header">
          <ng-container [ngTemplateOutlet]="headerTpl.template"></ng-container>
        </ng-template>
      }
      <ng-content></ng-content>
      @if (footerTpl) {
        <ng-template pTemplate="footer">
          <ng-container [ngTemplateOutlet]="footerTpl.template"></ng-container>
        </ng-template>
      }
    </p-dialog>
  `
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { header: [{
                type: Input
            }], visible: [{
                type: Input
            }], showOverlay: [{
                type: Input
            }], showMaximize: [{
                type: Input
            }], showClose: [{
                type: Input
            }], size: [{
                type: Input
            }], dismissableMask: [{
                type: Input
            }], closeOnEscape: [{
                type: Input
            }], focusOnShow: [{
                type: Input
            }], appendTo: [{
                type: Input
            }], templates: [{
                type: ContentChildren,
                args: [ExtraDialogTemplateDirective]
            }], visibleChange: [{
                type: Output
            }], onShow: [{
                type: Output
            }], onHide: [{
                type: Output
            }], onMaximize: [{
                type: Output
            }] } });

class ExtraDialogService {
    injector;
    constructor(injector) {
        this.injector = injector;
    }
    open(componentType, config = {}) {
        const { size, styleClass, ...rest } = config;
        const sizeClass = this.toSizeClass(size);
        const mergedStyleClass = [sizeClass, styleClass].filter(Boolean).join(' ');
        const childInjector = Injector.create({
            providers: [DialogService],
            parent: this.injector
        });
        const dialogService = childInjector.get(DialogService);
        return dialogService.open(componentType, {
            ...rest,
            ...(mergedStyleClass && { styleClass: mergedStyleClass }),
            appendTo: rest.appendTo ?? 'body'
        });
    }
    toSizeClass(size) {
        if (size === 'sm')
            return 'p-dialog-sm';
        if (size === 'lg')
            return 'p-dialog-lg';
        if (size === 'xlg')
            return 'p-dialog-xlg';
        return '';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogService, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i0.Injector }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraDialogComponent, ExtraDialogService, ExtraDialogTemplateDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-dialog.mjs.map
