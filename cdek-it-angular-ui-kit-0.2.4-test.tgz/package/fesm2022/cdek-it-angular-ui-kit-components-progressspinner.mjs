import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { ProgressSpinner } from 'primeng/progressspinner';

class ExtraProgressSpinnerComponent {
    size = 'base';
    multicolor = true;
    strokeWidth = '2';
    fill = 'none';
    animationDuration = '2s';
    ariaLabel = undefined;
    get primeStyleClass() {
        const sizeClass = `p-progressspinner-${this.size}`;
        const colorClass = this.multicolor ? '' : 'p-progressspinner-monochrome';
        return `${sizeClass} ${colorClass}`.trim();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraProgressSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraProgressSpinnerComponent, isStandalone: true, selector: "extra-progressspinner", inputs: { size: "size", multicolor: "multicolor", strokeWidth: "strokeWidth", fill: "fill", animationDuration: "animationDuration", ariaLabel: "ariaLabel" }, ngImport: i0, template: `
    <p-progressSpinner
      [styleClass]="primeStyleClass"
      [strokeWidth]="strokeWidth"
      [fill]="fill"
      [animationDuration]="animationDuration"
      [ariaLabel]="ariaLabel"
    ></p-progressSpinner>
  `, isInline: true, dependencies: [{ kind: "component", type: ProgressSpinner, selector: "p-progressSpinner, p-progress-spinner, p-progressspinner", inputs: ["styleClass", "strokeWidth", "fill", "animationDuration", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraProgressSpinnerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-progressspinner',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [ProgressSpinner],
                    template: `
    <p-progressSpinner
      [styleClass]="primeStyleClass"
      [strokeWidth]="strokeWidth"
      [fill]="fill"
      [animationDuration]="animationDuration"
      [ariaLabel]="ariaLabel"
    ></p-progressSpinner>
  `
                }]
        }], propDecorators: { size: [{
                type: Input
            }], multicolor: [{
                type: Input
            }], strokeWidth: [{
                type: Input
            }], fill: [{
                type: Input
            }], animationDuration: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraProgressSpinnerComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-progressspinner.mjs.map
