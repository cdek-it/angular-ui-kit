import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { RadioButton } from 'primeng/radiobutton';

class ExtraRadiobuttonComponent {
    value = null;
    name = undefined;
    disabled = false;
    invalid = false;
    variant = 'outlined';
    size = 'base';
    inputId = undefined;
    tabindex = undefined;
    ariaLabel = undefined;
    ariaLabelledBy = undefined;
    autofocus = false;
    onClick = new EventEmitter();
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    modelValue = null;
    _onChange = () => { };
    _onTouched = () => { };
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large')
            return 'large';
        return undefined;
    }
    get primeVariant() {
        return this.variant === 'filled' ? 'filled' : undefined;
    }
    onClickHandler(event) {
        this._onChange(event.value);
        this._onTouched();
        this.onClick.emit(event);
    }
    writeValue(value) {
        this.modelValue = value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraRadiobuttonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraRadiobuttonComponent, isStandalone: true, selector: "extra-radiobutton", inputs: { value: "value", name: "name", disabled: "disabled", invalid: "invalid", variant: "variant", size: "size", inputId: "inputId", tabindex: "tabindex", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy", autofocus: "autofocus" }, outputs: { onClick: "onClick", onFocus: "onFocus", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraRadiobuttonComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    <p-radiobutton
      [value]="value"
      [name]="name ?? ''"
      [disabled]="disabled"
      [invalid]="invalid"
      [(ngModel)]="modelValue"
      [variant]="primeVariant"
      [size]="primeSize"
      [inputId]="inputId"
      [tabindex]="tabindex"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [autofocus]="autofocus"
      (onClick)="onClickHandler($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
    ></p-radiobutton>
  `, isInline: true, dependencies: [{ kind: "component", type: RadioButton, selector: "p-radioButton, p-radiobutton, p-radio-button", inputs: ["value", "tabindex", "inputId", "ariaLabelledBy", "ariaLabel", "styleClass", "autofocus", "binary", "variant", "size"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraRadiobuttonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-radiobutton',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [RadioButton, FormsModule],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraRadiobuttonComponent),
                            multi: true
                        }
                    ],
                    template: `
    <p-radiobutton
      [value]="value"
      [name]="name ?? ''"
      [disabled]="disabled"
      [invalid]="invalid"
      [(ngModel)]="modelValue"
      [variant]="primeVariant"
      [size]="primeSize"
      [inputId]="inputId"
      [tabindex]="tabindex"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [autofocus]="autofocus"
      (onClick)="onClickHandler($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
    ></p-radiobutton>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], name: [{
                type: Input
            }], disabled: [{
                type: Input
            }], invalid: [{
                type: Input
            }], variant: [{
                type: Input
            }], size: [{
                type: Input
            }], inputId: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], autofocus: [{
                type: Input
            }], onClick: [{
                type: Output
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraRadiobuttonComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-radiobutton.mjs.map
