import * as i0 from '@angular/core';
import { inject, Injector, EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { NgControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgClass } from '@angular/common';
import { Textarea } from 'primeng/textarea';
import { IconField } from 'primeng/iconfield';
import { InputIcon } from 'primeng/inputicon';

class ExtraTextareaComponent {
    _injector = inject(Injector);
    _ngControl = null;
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
    }
    placeholder = '';
    size = 'base';
    readonly = false;
    showClear = false;
    fluid = false;
    autoResize = false;
    rows = 3;
    cols;
    disabled = false;
    get invalid() {
        return this._ngControl?.invalid ?? false;
    }
    onResize = new EventEmitter();
    onClear = new EventEmitter();
    modelValue = '';
    _onChange = () => { };
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large')
            return 'large';
        return undefined;
    }
    get sizeClass() {
        return { 'p-textarea-xlg': this.size === 'xlarge' };
    }
    onInput(event) {
        const value = event.target.value;
        this.modelValue = value;
        this._onChange(value);
    }
    onTouched = () => { };
    clearValue() {
        this.modelValue = '';
        this._onChange('');
        this.onClear.emit();
    }
    writeValue(value) {
        this.modelValue = value ?? '';
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraTextareaComponent, isStandalone: true, selector: "extra-textarea", inputs: { placeholder: "placeholder", size: "size", readonly: "readonly", showClear: "showClear", fluid: "fluid", autoResize: "autoResize", rows: "rows", cols: "cols" }, outputs: { onResize: "onResize", onClear: "onClear" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraTextareaComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    @if (showClear) {
      <p-iconfield [ngClass]="{ '!w-full': fluid }">
        <textarea
          pTextarea
          [ngClass]="sizeClass"
          [pSize]="primeSize"
          [disabled]="disabled"
          [readOnly]="readonly"
          [invalid]="invalid"
          [fluid]="fluid"
          [autoResize]="autoResize"
          [rows]="rows"
          [cols]="cols"
          [placeholder]="placeholder"
          [value]="modelValue"
          (input)="onInput($event)"
          (blur)="onTouched()"
          (onResize)="onResize.emit($event)"
        ></textarea>
        <p-inputicon
          class="ti ti-x"
          tabindex="0"
          [style.visibility]="modelValue ? 'visible' : 'hidden'"
          [style.pointerEvents]="modelValue ? 'auto' : 'none'"
          (click)="clearValue()"
          (keydown.enter)="clearValue()"
          (keydown.space)="clearValue()"
        ></p-inputicon>
      </p-iconfield>
    } @else {
      <textarea
        pTextarea
        [ngClass]="sizeClass"
        [pSize]="primeSize"
        [disabled]="disabled"
        [readOnly]="readonly"
        [invalid]="invalid"
        [fluid]="fluid"
        [autoResize]="autoResize"
        [rows]="rows"
        [cols]="cols"
        [placeholder]="placeholder"
        [value]="modelValue"
        (input)="onInput($event)"
        (blur)="onTouched()"
        (onResize)="onResize.emit($event)"
      ></textarea>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: Textarea, selector: "[pTextarea], [pInputTextarea]", inputs: ["autoResize", "pSize", "variant", "fluid", "invalid"], outputs: ["onResize"] }, { kind: "component", type: IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "component", type: InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTextareaComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-textarea',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Textarea, IconField, InputIcon, NgClass],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraTextareaComponent),
                            multi: true
                        }
                    ],
                    template: `
    @if (showClear) {
      <p-iconfield [ngClass]="{ '!w-full': fluid }">
        <textarea
          pTextarea
          [ngClass]="sizeClass"
          [pSize]="primeSize"
          [disabled]="disabled"
          [readOnly]="readonly"
          [invalid]="invalid"
          [fluid]="fluid"
          [autoResize]="autoResize"
          [rows]="rows"
          [cols]="cols"
          [placeholder]="placeholder"
          [value]="modelValue"
          (input)="onInput($event)"
          (blur)="onTouched()"
          (onResize)="onResize.emit($event)"
        ></textarea>
        <p-inputicon
          class="ti ti-x"
          tabindex="0"
          [style.visibility]="modelValue ? 'visible' : 'hidden'"
          [style.pointerEvents]="modelValue ? 'auto' : 'none'"
          (click)="clearValue()"
          (keydown.enter)="clearValue()"
          (keydown.space)="clearValue()"
        ></p-inputicon>
      </p-iconfield>
    } @else {
      <textarea
        pTextarea
        [ngClass]="sizeClass"
        [pSize]="primeSize"
        [disabled]="disabled"
        [readOnly]="readonly"
        [invalid]="invalid"
        [fluid]="fluid"
        [autoResize]="autoResize"
        [rows]="rows"
        [cols]="cols"
        [placeholder]="placeholder"
        [value]="modelValue"
        (input)="onInput($event)"
        (blur)="onTouched()"
        (onResize)="onResize.emit($event)"
      ></textarea>
    }
  `
                }]
        }], propDecorators: { placeholder: [{
                type: Input
            }], size: [{
                type: Input
            }], readonly: [{
                type: Input
            }], showClear: [{
                type: Input
            }], fluid: [{
                type: Input
            }], autoResize: [{
                type: Input
            }], rows: [{
                type: Input
            }], cols: [{
                type: Input
            }], onResize: [{
                type: Output
            }], onClear: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraTextareaComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-textarea.mjs.map
