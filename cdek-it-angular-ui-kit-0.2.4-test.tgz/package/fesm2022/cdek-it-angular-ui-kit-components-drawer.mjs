import * as i0 from '@angular/core';
import { Directive, EventEmitter, TemplateRef, ContentChild, Output, Input, Component } from '@angular/core';
import { Drawer } from 'primeng/drawer';
import * as i1 from 'primeng/api';
import { SharedModule } from 'primeng/api';
import { NgTemplateOutlet } from '@angular/common';

class ExtraDrawerHeaderDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDrawerHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraDrawerHeaderDirective, isStandalone: true, selector: "[extraDrawerHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDrawerHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraDrawerHeader]', standalone: true }]
        }] });
class ExtraDrawerFooterDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDrawerFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraDrawerFooterDirective, isStandalone: true, selector: "[extraDrawerFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDrawerFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraDrawerFooter]', standalone: true }]
        }] });
class ExtraDrawerComponent {
    visible = false;
    header;
    position = 'right';
    size = 'default';
    modal = true;
    fullScreen = false;
    dismissible = true;
    showCloseIcon = true;
    closeOnEscape = true;
    blockScroll = true;
    visibleChange = new EventEmitter();
    onShow = new EventEmitter();
    onHide = new EventEmitter();
    headerTemplate = null;
    footerTemplate = null;
    get sizeClass() {
        if (this.size === 'default')
            return '';
        return `p-drawer-${this.size}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDrawerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraDrawerComponent, isStandalone: true, selector: "extra-drawer", inputs: { visible: "visible", header: "header", position: "position", size: "size", modal: "modal", fullScreen: "fullScreen", dismissible: "dismissible", showCloseIcon: "showCloseIcon", closeOnEscape: "closeOnEscape", blockScroll: "blockScroll" }, outputs: { visibleChange: "visibleChange", onShow: "onShow", onHide: "onHide" }, queries: [{ propertyName: "headerTemplate", first: true, predicate: ExtraDrawerHeaderDirective, descendants: true, read: TemplateRef }, { propertyName: "footerTemplate", first: true, predicate: ExtraDrawerFooterDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-drawer
      [visible]="visible"
      [header]="headerTemplate ? undefined : header"
      [modal]="modal"
      [fullScreen]="fullScreen"
      [dismissible]="dismissible"
      [closable]="showCloseIcon"
      [closeOnEscape]="closeOnEscape"
      [blockScroll]="blockScroll"
      [styleClass]="sizeClass"
      [position]="position"
      [closeButtonProps]="{ text: true, rounded: true }"
      (visibleChange)="visibleChange.emit($event)"
      (onShow)="onShow.emit()"
      (onHide)="onHide.emit()"
    >
      <ng-content></ng-content>
      @if (headerTemplate) {
        <ng-template pTemplate="header">
          <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
        </ng-template>
      }
      @if (footerTemplate) {
        <ng-template pTemplate="footer">
          <ng-container *ngTemplateOutlet="footerTemplate"></ng-container>
        </ng-template>
      }
    </p-drawer>
  `, isInline: true, dependencies: [{ kind: "component", type: Drawer, selector: "p-drawer", inputs: ["appendTo", "blockScroll", "style", "styleClass", "ariaCloseLabel", "autoZIndex", "baseZIndex", "modal", "closeButtonProps", "dismissible", "showCloseIcon", "closeOnEscape", "transitionOptions", "visible", "position", "fullScreen", "header", "maskStyle", "closable"], outputs: ["onShow", "onHide", "visibleChange"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDrawerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-drawer',
                    standalone: true,
                    imports: [Drawer, SharedModule, NgTemplateOutlet],
                    template: `
    <p-drawer
      [visible]="visible"
      [header]="headerTemplate ? undefined : header"
      [modal]="modal"
      [fullScreen]="fullScreen"
      [dismissible]="dismissible"
      [closable]="showCloseIcon"
      [closeOnEscape]="closeOnEscape"
      [blockScroll]="blockScroll"
      [styleClass]="sizeClass"
      [position]="position"
      [closeButtonProps]="{ text: true, rounded: true }"
      (visibleChange)="visibleChange.emit($event)"
      (onShow)="onShow.emit()"
      (onHide)="onHide.emit()"
    >
      <ng-content></ng-content>
      @if (headerTemplate) {
        <ng-template pTemplate="header">
          <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
        </ng-template>
      }
      @if (footerTemplate) {
        <ng-template pTemplate="footer">
          <ng-container *ngTemplateOutlet="footerTemplate"></ng-container>
        </ng-template>
      }
    </p-drawer>
  `
                }]
        }], propDecorators: { visible: [{
                type: Input
            }], header: [{
                type: Input
            }], position: [{
                type: Input
            }], size: [{
                type: Input
            }], modal: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], showCloseIcon: [{
                type: Input
            }], closeOnEscape: [{
                type: Input
            }], blockScroll: [{
                type: Input
            }], visibleChange: [{
                type: Output
            }], onShow: [{
                type: Output
            }], onHide: [{
                type: Output
            }], headerTemplate: [{
                type: ContentChild,
                args: [ExtraDrawerHeaderDirective, { read: TemplateRef }]
            }], footerTemplate: [{
                type: ContentChild,
                args: [ExtraDrawerFooterDirective, { read: TemplateRef }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraDrawerComponent, ExtraDrawerFooterDirective, ExtraDrawerHeaderDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-drawer.mjs.map
