import * as i0 from '@angular/core';
import { signal, EventEmitter, computed, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { AutoComplete } from 'primeng/autocomplete';

class ExtraAutoCompleteComponent {
    suggestions = [];
    optionLabel = undefined;
    optionValue = undefined;
    optionDisabled = undefined;
    optionGroupLabel = undefined;
    optionGroupChildren = undefined;
    group = false;
    multiple = false;
    dropdown = false;
    dropdownMode = 'blank';
    showClear = false;
    forceSelection = false;
    completeOnFocus = false;
    placeholder = undefined;
    minLength = 1;
    delay = 300;
    scrollHeight = '200px';
    emptyMessage = undefined;
    _size = signal('base', ...(ngDevMode ? [{ debugName: "_size" }] : []));
    set size(v) { this._size.set(v); }
    get size() { return this._size(); }
    disabled = false;
    readonly = false;
    invalid = false;
    fluid = false;
    unique = false;
    dataKey = undefined;
    inputStyleClass = undefined;
    inputId = undefined;
    ariaLabel = undefined;
    ariaLabelledBy = undefined;
    autofocus = false;
    completeMethod = new EventEmitter();
    onSelect = new EventEmitter();
    onUnselect = new EventEmitter();
    onDropdownClick = new EventEmitter();
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    onClear = new EventEmitter();
    computedInputStyleClass = computed(() => {
        const classes = [];
        const s = this._size();
        if (s === 'small')
            classes.push('p-inputtext-sm');
        if (s === 'large')
            classes.push('p-inputtext-lg');
        if (s === 'xlarge')
            classes.push('p-inputtext-lg', 'p-inputtext-xlg');
        if (this.inputStyleClass)
            classes.push(this.inputStyleClass);
        return classes.join(' ') || undefined;
    }, ...(ngDevMode ? [{ debugName: "computedInputStyleClass" }] : []));
    modelValue = null;
    _onChange = () => { };
    _onTouched = () => { };
    handleChange(value) {
        this.modelValue = value;
        this._onChange(value);
        this._onTouched();
    }
    writeValue(value) {
        this.modelValue = value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAutoCompleteComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraAutoCompleteComponent, isStandalone: true, selector: "extra-auto-complete", inputs: { suggestions: "suggestions", optionLabel: "optionLabel", optionValue: "optionValue", optionDisabled: "optionDisabled", optionGroupLabel: "optionGroupLabel", optionGroupChildren: "optionGroupChildren", group: "group", multiple: "multiple", dropdown: "dropdown", dropdownMode: "dropdownMode", showClear: "showClear", forceSelection: "forceSelection", completeOnFocus: "completeOnFocus", placeholder: "placeholder", minLength: "minLength", delay: "delay", scrollHeight: "scrollHeight", emptyMessage: "emptyMessage", size: "size", disabled: "disabled", readonly: "readonly", invalid: "invalid", fluid: "fluid", unique: "unique", dataKey: "dataKey", inputStyleClass: "inputStyleClass", inputId: "inputId", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy", autofocus: "autofocus" }, outputs: { completeMethod: "completeMethod", onSelect: "onSelect", onUnselect: "onUnselect", onDropdownClick: "onDropdownClick", onFocus: "onFocus", onBlur: "onBlur", onClear: "onClear" }, host: { styleAttribute: "display: block" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraAutoCompleteComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <p-autocomplete
      [ngModel]="modelValue"
      (ngModelChange)="handleChange($event)"
      [suggestions]="suggestions"
      [optionLabel]="optionLabel"
      [optionValue]="optionValue"
      [optionDisabled]="optionDisabled"
      [optionGroupLabel]="optionGroupLabel"
      [optionGroupChildren]="optionGroupChildren"
      [group]="group"
      [multiple]="multiple"
      [dropdown]="dropdown"
      [dropdownMode]="dropdownMode"
      [showClear]="showClear"
      [forceSelection]="forceSelection"
      [completeOnFocus]="completeOnFocus"
      [placeholder]="placeholder"
      [minLength]="minLength"
      [delay]="delay"
      [scrollHeight]="scrollHeight"
      [emptyMessage]="emptyMessage"
      [disabled]="disabled"
      [readonly]="readonly"
      [invalid]="invalid"
      [fluid]="fluid"
      [unique]="unique"
      [dataKey]="dataKey"
      [inputStyleClass]="computedInputStyleClass()"
      [inputId]="inputId"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [autofocus]="autofocus"
      (completeMethod)="completeMethod.emit($event)"
      (onSelect)="onSelect.emit($event)"
      (onUnselect)="onUnselect.emit($event)"
      (onDropdownClick)="onDropdownClick.emit($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
      (onClear)="onClear.emit()"
    ></p-autocomplete>
  `, isInline: true, dependencies: [{ kind: "component", type: AutoComplete, selector: "p-autoComplete, p-autocomplete, p-auto-complete", inputs: ["minLength", "minQueryLength", "delay", "panelStyle", "styleClass", "panelStyleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "readonly", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "autoHighlight", "forceSelection", "type", "autoZIndex", "baseZIndex", "ariaLabel", "dropdownAriaLabel", "ariaLabelledBy", "dropdownIcon", "unique", "group", "completeOnFocus", "showClear", "dropdown", "showEmptyMessage", "dropdownMode", "multiple", "addOnTab", "tabindex", "dataKey", "emptyMessage", "showTransitionOptions", "hideTransitionOptions", "autofocus", "autocomplete", "optionGroupChildren", "optionGroupLabel", "overlayOptions", "suggestions", "optionLabel", "optionValue", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "selectOnFocus", "searchLocale", "optionDisabled", "focusOnHover", "typeahead", "addOnBlur", "separator", "appendTo"], outputs: ["completeMethod", "onSelect", "onUnselect", "onAdd", "onFocus", "onBlur", "onDropdownClick", "onClear", "onInputKeydown", "onKeyUp", "onShow", "onHide", "onLazyLoad"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAutoCompleteComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-auto-complete',
                    host: { style: 'display: block' },
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [AutoComplete, FormsModule],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraAutoCompleteComponent),
                            multi: true,
                        },
                    ],
                    template: `
    <p-autocomplete
      [ngModel]="modelValue"
      (ngModelChange)="handleChange($event)"
      [suggestions]="suggestions"
      [optionLabel]="optionLabel"
      [optionValue]="optionValue"
      [optionDisabled]="optionDisabled"
      [optionGroupLabel]="optionGroupLabel"
      [optionGroupChildren]="optionGroupChildren"
      [group]="group"
      [multiple]="multiple"
      [dropdown]="dropdown"
      [dropdownMode]="dropdownMode"
      [showClear]="showClear"
      [forceSelection]="forceSelection"
      [completeOnFocus]="completeOnFocus"
      [placeholder]="placeholder"
      [minLength]="minLength"
      [delay]="delay"
      [scrollHeight]="scrollHeight"
      [emptyMessage]="emptyMessage"
      [disabled]="disabled"
      [readonly]="readonly"
      [invalid]="invalid"
      [fluid]="fluid"
      [unique]="unique"
      [dataKey]="dataKey"
      [inputStyleClass]="computedInputStyleClass()"
      [inputId]="inputId"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [autofocus]="autofocus"
      (completeMethod)="completeMethod.emit($event)"
      (onSelect)="onSelect.emit($event)"
      (onUnselect)="onUnselect.emit($event)"
      (onDropdownClick)="onDropdownClick.emit($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
      (onClear)="onClear.emit()"
    ></p-autocomplete>
  `,
                }]
        }], propDecorators: { suggestions: [{
                type: Input
            }], optionLabel: [{
                type: Input
            }], optionValue: [{
                type: Input
            }], optionDisabled: [{
                type: Input
            }], optionGroupLabel: [{
                type: Input
            }], optionGroupChildren: [{
                type: Input
            }], group: [{
                type: Input
            }], multiple: [{
                type: Input
            }], dropdown: [{
                type: Input
            }], dropdownMode: [{
                type: Input
            }], showClear: [{
                type: Input
            }], forceSelection: [{
                type: Input
            }], completeOnFocus: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], minLength: [{
                type: Input
            }], delay: [{
                type: Input
            }], scrollHeight: [{
                type: Input
            }], emptyMessage: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], invalid: [{
                type: Input
            }], fluid: [{
                type: Input
            }], unique: [{
                type: Input
            }], dataKey: [{
                type: Input
            }], inputStyleClass: [{
                type: Input
            }], inputId: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], autofocus: [{
                type: Input
            }], completeMethod: [{
                type: Output
            }], onSelect: [{
                type: Output
            }], onUnselect: [{
                type: Output
            }], onDropdownClick: [{
                type: Output
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], onClear: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraAutoCompleteComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-autocomplete.mjs.map
