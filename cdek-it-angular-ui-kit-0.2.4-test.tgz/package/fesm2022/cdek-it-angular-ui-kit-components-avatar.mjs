import * as i0 from '@angular/core';
import { HostBinding, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Avatar } from 'primeng/avatar';
import { AvatarGroup } from 'primeng/avatargroup';

class ExtraAvatarComponent {
    label = '';
    icon = '';
    image = '';
    size = 'base';
    shape = 'square';
    get hostClass() {
        const classes = ['ui-avatar'];
        if (this.size === 'large')
            classes.push('ui-avatar-lg');
        if (this.size === 'xlarge')
            classes.push('ui-avatar-xl');
        return classes.join(' ');
    }
    get primeSize() {
        return this.size === 'base' ? undefined : this.size;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraAvatarComponent, isStandalone: true, selector: "extra-avatar", inputs: { label: "label", icon: "icon", image: "image", size: "size", shape: "shape" }, host: { properties: { "class": "this.hostClass" } }, ngImport: i0, template: `
    <p-avatar
      [label]="label || undefined"
      [icon]="icon || undefined"
      [image]="image || undefined"
      [size]="primeSize"
      [shape]="shape"
    ></p-avatar>
  `, isInline: true, dependencies: [{ kind: "component", type: Avatar, selector: "p-avatar", inputs: ["label", "icon", "image", "size", "shape", "styleClass", "ariaLabel", "ariaLabelledBy"], outputs: ["onImageError"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAvatarComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-avatar',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Avatar],
                    template: `
    <p-avatar
      [label]="label || undefined"
      [icon]="icon || undefined"
      [image]="image || undefined"
      [size]="primeSize"
      [shape]="shape"
    ></p-avatar>
  `
                }]
        }], propDecorators: { label: [{
                type: Input
            }], icon: [{
                type: Input
            }], image: [{
                type: Input
            }], size: [{
                type: Input
            }], shape: [{
                type: Input
            }], hostClass: [{
                type: HostBinding,
                args: ['class']
            }] } });
class ExtraAvatarGroupComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAvatarGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraAvatarGroupComponent, isStandalone: true, selector: "extra-avatar-group", ngImport: i0, template: `
    <p-avatar-group>
      <ng-content></ng-content>
    </p-avatar-group>
  `, isInline: true, dependencies: [{ kind: "component", type: AvatarGroup, selector: "p-avatarGroup, p-avatar-group, p-avatargroup", inputs: ["styleClass", "style"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAvatarGroupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-avatar-group',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [AvatarGroup],
                    template: `
    <p-avatar-group>
      <ng-content></ng-content>
    </p-avatar-group>
  `
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraAvatarComponent, ExtraAvatarGroupComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-avatar.mjs.map
