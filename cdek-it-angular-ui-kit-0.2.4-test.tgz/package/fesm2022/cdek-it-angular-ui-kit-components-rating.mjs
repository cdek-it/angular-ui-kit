import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Rating } from 'primeng/rating';

class ExtraRatingComponent {
    stars = 5;
    readonly = false;
    disabled = false;
    autofocus = false;
    onRate = new EventEmitter();
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    modelValue = null;
    onChange = () => { };
    onTouched = () => { };
    handleChange(value) {
        this.modelValue = value;
        this.onChange(value);
        this.onTouched();
    }
    writeValue(value) {
        this.modelValue = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraRatingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraRatingComponent, isStandalone: true, selector: "extra-rating", inputs: { stars: "stars", readonly: "readonly", disabled: "disabled", autofocus: "autofocus" }, outputs: { onRate: "onRate", onFocus: "onFocus", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraRatingComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    <p-rating
      [ngModel]="modelValue"
      (ngModelChange)="handleChange($event)"
      [stars]="stars"
      [readonly]="readonly"
      [disabled]="disabled"
      [autofocus]="autofocus"
      (onRate)="onRate.emit($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
    ></p-rating>
  `, isInline: true, dependencies: [{ kind: "component", type: Rating, selector: "p-rating", inputs: ["readonly", "stars", "iconOnClass", "iconOnStyle", "iconOffClass", "iconOffStyle", "autofocus"], outputs: ["onRate", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraRatingComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-rating',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Rating, FormsModule],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraRatingComponent),
                            multi: true
                        }
                    ],
                    template: `
    <p-rating
      [ngModel]="modelValue"
      (ngModelChange)="handleChange($event)"
      [stars]="stars"
      [readonly]="readonly"
      [disabled]="disabled"
      [autofocus]="autofocus"
      (onRate)="onRate.emit($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
    ></p-rating>
  `
                }]
        }], propDecorators: { stars: [{
                type: Input
            }], readonly: [{
                type: Input
            }], disabled: [{
                type: Input
            }], autofocus: [{
                type: Input
            }], onRate: [{
                type: Output
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraRatingComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-rating.mjs.map
