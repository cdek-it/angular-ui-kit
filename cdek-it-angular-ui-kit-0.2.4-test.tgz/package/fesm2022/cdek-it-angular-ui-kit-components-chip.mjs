import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Chip } from 'primeng/chip';

class ExtraChipComponent {
    label = '';
    icon = '';
    removable = false;
    disabled = false;
    onRemove = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraChipComponent, isStandalone: true, selector: "extra-chip", inputs: { label: "label", icon: "icon", removable: "removable", disabled: "disabled" }, outputs: { onRemove: "onRemove" }, ngImport: i0, template: `
    <p-chip
      [label]="label"
      [icon]="icon"
      [removable]="removable"
      [disabled]="disabled"
      (onRemove)="onRemove.emit($event)"
    ></p-chip>
  `, isInline: true, dependencies: [{ kind: "component", type: Chip, selector: "p-chip", inputs: ["label", "icon", "image", "alt", "styleClass", "disabled", "removable", "removeIcon", "chipProps"], outputs: ["onRemove", "onImageError"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraChipComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-chip',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Chip],
                    template: `
    <p-chip
      [label]="label"
      [icon]="icon"
      [removable]="removable"
      [disabled]="disabled"
      (onRemove)="onRemove.emit($event)"
    ></p-chip>
  `
                }]
        }], propDecorators: { label: [{
                type: Input
            }], icon: [{
                type: Input
            }], removable: [{
                type: Input
            }], disabled: [{
                type: Input
            }], onRemove: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraChipComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-chip.mjs.map
