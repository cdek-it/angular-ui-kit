import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Tag } from 'primeng/tag';

class ExtraTagComponent {
    value = '';
    severity = 'primary';
    rounded = false;
    icon = '';
    get primeSeverity() {
        if (this.severity === 'primary')
            return undefined;
        if (this.severity === 'warning')
            return 'warn';
        return this.severity;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTagComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraTagComponent, isStandalone: true, selector: "extra-tag", inputs: { value: "value", severity: "severity", rounded: "rounded", icon: "icon" }, ngImport: i0, template: `
    <p-tag [value]="value" [severity]="primeSeverity" [rounded]="rounded" [icon]="icon || undefined"></p-tag>
  `, isInline: true, dependencies: [{ kind: "component", type: Tag, selector: "p-tag", inputs: ["styleClass", "severity", "value", "icon", "rounded"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTagComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-tag',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Tag],
                    template: `
    <p-tag [value]="value" [severity]="primeSeverity" [rounded]="rounded" [icon]="icon || undefined"></p-tag>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], severity: [{
                type: Input
            }], rounded: [{
                type: Input
            }], icon: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraTagComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-tag.mjs.map
