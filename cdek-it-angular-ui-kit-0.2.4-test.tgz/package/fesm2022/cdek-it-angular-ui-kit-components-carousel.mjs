import * as i0 from '@angular/core';
import { Directive, EventEmitter, TemplateRef, Output, ContentChild, Input, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Carousel } from 'primeng/carousel';
import { PrimeTemplate } from 'primeng/api';

class ExtraCarouselItemDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraCarouselItemDirective, isStandalone: true, selector: "[extraCarouselItem]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraCarouselItem]', standalone: true }]
        }] });
class ExtraCarouselHeaderDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraCarouselHeaderDirective, isStandalone: true, selector: "[extraCarouselHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraCarouselHeader]', standalone: true }]
        }] });
class ExtraCarouselFooterDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraCarouselFooterDirective, isStandalone: true, selector: "[extraCarouselFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraCarouselFooter]', standalone: true }]
        }] });
class ExtraCarouselComponent {
    value = [];
    numVisible = 1;
    numScroll = 1;
    circular = false;
    orientation = 'horizontal';
    autoplayInterval = 0;
    showIndicators = true;
    showNavigators = true;
    page = 0;
    responsiveOptions;
    verticalViewPortHeight = '300px';
    itemTemplate = null;
    headerTemplate = null;
    footerTemplate = null;
    onPage = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraCarouselComponent, isStandalone: true, selector: "extra-carousel", inputs: { value: "value", numVisible: "numVisible", numScroll: "numScroll", circular: "circular", orientation: "orientation", autoplayInterval: "autoplayInterval", showIndicators: "showIndicators", showNavigators: "showNavigators", page: "page", responsiveOptions: "responsiveOptions", verticalViewPortHeight: "verticalViewPortHeight" }, outputs: { onPage: "onPage" }, queries: [{ propertyName: "itemTemplate", first: true, predicate: ExtraCarouselItemDirective, descendants: true, read: TemplateRef }, { propertyName: "headerTemplate", first: true, predicate: ExtraCarouselHeaderDirective, descendants: true, read: TemplateRef }, { propertyName: "footerTemplate", first: true, predicate: ExtraCarouselFooterDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-carousel
      [value]="value"
      [numVisible]="numVisible"
      [numScroll]="numScroll"
      [circular]="circular"
      [orientation]="orientation"
      [autoplayInterval]="autoplayInterval"
      [showIndicators]="showIndicators"
      [showNavigators]="showNavigators"
      [page]="page"
      [responsiveOptions]="responsiveOptions"
      [verticalViewPortHeight]="verticalViewPortHeight"
      (onPage)="onPage.emit($event)"
    >
      @if (itemTemplate) {
        <ng-template pTemplate="item" let-data>
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: data }"
          ></ng-container>
        </ng-template>
      }
      @if (headerTemplate) {
        <ng-template pTemplate="header">
          <ng-container [ngTemplateOutlet]="headerTemplate"></ng-container>
        </ng-template>
      }
      @if (footerTemplate) {
        <ng-template pTemplate="footer">
          <ng-container [ngTemplateOutlet]="footerTemplate"></ng-container>
        </ng-template>
      }
    </p-carousel>
  `, isInline: true, dependencies: [{ kind: "component", type: Carousel, selector: "p-carousel", inputs: ["page", "numVisible", "numScroll", "responsiveOptions", "orientation", "verticalViewPortHeight", "contentClass", "indicatorsContentClass", "indicatorsContentStyle", "indicatorStyleClass", "indicatorStyle", "value", "circular", "showIndicators", "showNavigators", "autoplayInterval", "styleClass", "prevButtonProps", "nextButtonProps"], outputs: ["onPage"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCarouselComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-carousel',
                    standalone: true,
                    imports: [Carousel, NgTemplateOutlet, PrimeTemplate],
                    template: `
    <p-carousel
      [value]="value"
      [numVisible]="numVisible"
      [numScroll]="numScroll"
      [circular]="circular"
      [orientation]="orientation"
      [autoplayInterval]="autoplayInterval"
      [showIndicators]="showIndicators"
      [showNavigators]="showNavigators"
      [page]="page"
      [responsiveOptions]="responsiveOptions"
      [verticalViewPortHeight]="verticalViewPortHeight"
      (onPage)="onPage.emit($event)"
    >
      @if (itemTemplate) {
        <ng-template pTemplate="item" let-data>
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: data }"
          ></ng-container>
        </ng-template>
      }
      @if (headerTemplate) {
        <ng-template pTemplate="header">
          <ng-container [ngTemplateOutlet]="headerTemplate"></ng-container>
        </ng-template>
      }
      @if (footerTemplate) {
        <ng-template pTemplate="footer">
          <ng-container [ngTemplateOutlet]="footerTemplate"></ng-container>
        </ng-template>
      }
    </p-carousel>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], numVisible: [{
                type: Input
            }], numScroll: [{
                type: Input
            }], circular: [{
                type: Input
            }], orientation: [{
                type: Input
            }], autoplayInterval: [{
                type: Input
            }], showIndicators: [{
                type: Input
            }], showNavigators: [{
                type: Input
            }], page: [{
                type: Input
            }], responsiveOptions: [{
                type: Input
            }], verticalViewPortHeight: [{
                type: Input
            }], itemTemplate: [{
                type: ContentChild,
                args: [ExtraCarouselItemDirective, { read: TemplateRef }]
            }], headerTemplate: [{
                type: ContentChild,
                args: [ExtraCarouselHeaderDirective, { read: TemplateRef }]
            }], footerTemplate: [{
                type: ContentChild,
                args: [ExtraCarouselFooterDirective, { read: TemplateRef }]
            }], onPage: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraCarouselComponent, ExtraCarouselFooterDirective, ExtraCarouselHeaderDirective, ExtraCarouselItemDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-carousel.mjs.map
