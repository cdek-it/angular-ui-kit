import * as i0 from '@angular/core';
import { Directive, EventEmitter, TemplateRef, forwardRef, Output, ContentChild, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Listbox } from 'primeng/listbox';
import * as i2 from 'primeng/api';
import { SharedModule } from 'primeng/api';
import { NgTemplateOutlet } from '@angular/common';

class ExtraListboxItemDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraListboxItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraListboxItemDirective, isStandalone: true, selector: "[extraListboxItem]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraListboxItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraListboxItem]', standalone: true }]
        }] });
class ExtraListboxComponent {
    options = [];
    optionLabel = 'label';
    optionValue = undefined;
    multiple = false;
    filter = false;
    filterPlaceHolder = undefined;
    checkmark = false;
    group = false;
    optionGroupLabel = undefined;
    optionGroupChildren = undefined;
    scrollHeight = '200px';
    emptyMessage = undefined;
    itemTemplate = null;
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    modelValue = null;
    _disabled = false;
    _onChange = () => { };
    _onTouched = () => { };
    get isDisabled() {
        return this._disabled;
    }
    onChangeHandler(event) {
        // Обновляем внутреннее значение и уведомляем форму об изменении.
        this.modelValue = event.value;
        this._onChange(event.value);
    }
    onBlurHandler(event) {
        // emit external onBlur and mark control as touched for forms
        this.onBlur.emit(event);
        this._onTouched();
    }
    writeValue(value) {
        this.modelValue = value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraListboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraListboxComponent, isStandalone: true, selector: "extra-listbox", inputs: { options: "options", optionLabel: "optionLabel", optionValue: "optionValue", multiple: "multiple", filter: "filter", filterPlaceHolder: "filterPlaceHolder", checkmark: "checkmark", group: "group", optionGroupLabel: "optionGroupLabel", optionGroupChildren: "optionGroupChildren", scrollHeight: "scrollHeight", emptyMessage: "emptyMessage" }, outputs: { onFocus: "onFocus", onBlur: "onBlur" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ExtraListboxComponent), multi: true }], queries: [{ propertyName: "itemTemplate", first: true, predicate: ExtraListboxItemDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-listbox
      [options]="options"
      [(ngModel)]="modelValue"
      [optionLabel]="optionLabel"
      [optionValue]="optionValue"
      [multiple]="multiple"
      [filter]="filter"
      [filterPlaceHolder]="filterPlaceHolder"
      [checkmark]="checkmark"
      [group]="group"
      [optionGroupLabel]="optionGroupLabel"
      [optionGroupChildren]="optionGroupChildren"
      [scrollHeight]="scrollHeight"
      [emptyMessage]="emptyMessage"
      [disabled]="isDisabled"
      (onChange)="onChangeHandler($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlurHandler($event)"
    >
      @if (itemTemplate) {
        <ng-template pTemplate="item" let-item>
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        </ng-template>
      }
    </p-listbox>
  `, isInline: true, dependencies: [{ kind: "component", type: Listbox, selector: "p-listbox, p-listBox, p-list-box", inputs: ["hostName", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "ariaLabel", "selectOnFocus", "searchLocale", "focusOnHover", "filterMessage", "filterFields", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "scrollHeight", "tabindex", "multiple", "styleClass", "listStyle", "listStyleClass", "readonly", "checkbox", "filter", "filterBy", "filterMatchMode", "filterLocale", "metaKeySelection", "dataKey", "showToggleAll", "optionLabel", "optionValue", "optionGroupChildren", "optionGroupLabel", "optionDisabled", "ariaFilterLabel", "filterPlaceHolder", "emptyFilterMessage", "emptyMessage", "group", "options", "filterValue", "selectAll", "striped", "highlightOnSelect", "checkmark", "dragdrop", "dropListData", "fluid"], outputs: ["onChange", "onClick", "onDblClick", "onFilter", "onFocus", "onBlur", "onSelectAllChange", "onLazyLoad", "onDrop"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraListboxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-listbox',
                    standalone: true,
                    imports: [Listbox, FormsModule, SharedModule, NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ExtraListboxComponent), multi: true }],
                    template: `
    <p-listbox
      [options]="options"
      [(ngModel)]="modelValue"
      [optionLabel]="optionLabel"
      [optionValue]="optionValue"
      [multiple]="multiple"
      [filter]="filter"
      [filterPlaceHolder]="filterPlaceHolder"
      [checkmark]="checkmark"
      [group]="group"
      [optionGroupLabel]="optionGroupLabel"
      [optionGroupChildren]="optionGroupChildren"
      [scrollHeight]="scrollHeight"
      [emptyMessage]="emptyMessage"
      [disabled]="isDisabled"
      (onChange)="onChangeHandler($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlurHandler($event)"
    >
      @if (itemTemplate) {
        <ng-template pTemplate="item" let-item>
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        </ng-template>
      }
    </p-listbox>
  `
                }]
        }], propDecorators: { options: [{
                type: Input
            }], optionLabel: [{
                type: Input
            }], optionValue: [{
                type: Input
            }], multiple: [{
                type: Input
            }], filter: [{
                type: Input
            }], filterPlaceHolder: [{
                type: Input
            }], checkmark: [{
                type: Input
            }], group: [{
                type: Input
            }], optionGroupLabel: [{
                type: Input
            }], optionGroupChildren: [{
                type: Input
            }], scrollHeight: [{
                type: Input
            }], emptyMessage: [{
                type: Input
            }], itemTemplate: [{
                type: ContentChild,
                args: [ExtraListboxItemDirective, { read: TemplateRef }]
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraListboxComponent, ExtraListboxItemDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-listbox.mjs.map
