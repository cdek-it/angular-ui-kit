import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { ProgressBar } from 'primeng/progressbar';

class ExtraProgressBarComponent {
    value = 0;
    mode = 'determinate';
    showValue = true;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraProgressBarComponent, isStandalone: true, selector: "extra-progressbar", inputs: { value: "value", mode: "mode", showValue: "showValue" }, ngImport: i0, template: ` <p-progressbar [value]="value" [mode]="mode" [showValue]="showValue"></p-progressbar> `, isInline: true, dependencies: [{ kind: "component", type: ProgressBar, selector: "p-progressBar, p-progressbar, p-progress-bar", inputs: ["value", "showValue", "styleClass", "valueStyleClass", "unit", "mode", "color"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraProgressBarComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-progressbar',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [ProgressBar],
                    template: ` <p-progressbar [value]="value" [mode]="mode" [showValue]="showValue"></p-progressbar> `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], mode: [{
                type: Input
            }], showValue: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraProgressBarComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-progressbar.mjs.map
