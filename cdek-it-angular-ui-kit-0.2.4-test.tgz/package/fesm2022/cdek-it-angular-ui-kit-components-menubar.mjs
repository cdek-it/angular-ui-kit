import * as i0 from '@angular/core';
import { Directive, TemplateRef, ContentChild, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Menubar } from 'primeng/menubar';
import { PrimeTemplate } from 'primeng/api';

class ExtraMenubarItemDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenubarItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraMenubarItemDirective, isStandalone: true, selector: "[extraMenubarItem]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenubarItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraMenubarItem]', standalone: true }]
        }] });
class ExtraMenubarComponent {
    model = [];
    itemTemplate = null;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenubarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraMenubarComponent, isStandalone: true, selector: "extra-menubar", inputs: { model: "model" }, queries: [{ propertyName: "itemTemplate", first: true, predicate: ExtraMenubarItemDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-menubar [model]="model">
      <ng-template pTemplate="item" let-item let-hasSubmenu="hasSubmenu" let-root="root">
        @if (itemTemplate) {
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item, hasSubmenu: hasSubmenu, root: root }"
          ></ng-container>
        } @else {
          <a class="p-menubar-item-link flex items-center gap-2">
            @if (item.icon) {
              <span [class]="'p-menubar-item-icon ' + item.icon"></span>
            }
            <span class="p-menubar-item-label">{{ item.label }}</span>
            @if (hasSubmenu) {
              <span
                [class]="root ? 'p-menubar-submenu-icon ti ti-chevron-down' : 'p-menubar-submenu-icon ti ti-chevron-right'"
              ></span>
            }
          </a>
        }
      </ng-template>
    </p-menubar>
  `, isInline: true, dependencies: [{ kind: "component", type: Menubar, selector: "p-menubar", inputs: ["model", "styleClass", "autoZIndex", "baseZIndex", "autoDisplay", "autoHide", "breakpoint", "autoHideDelay", "id", "ariaLabel", "ariaLabelledBy"], outputs: ["onFocus", "onBlur"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMenubarComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-menubar',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Menubar, PrimeTemplate, NgTemplateOutlet],
                    template: `
    <p-menubar [model]="model">
      <ng-template pTemplate="item" let-item let-hasSubmenu="hasSubmenu" let-root="root">
        @if (itemTemplate) {
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item, hasSubmenu: hasSubmenu, root: root }"
          ></ng-container>
        } @else {
          <a class="p-menubar-item-link flex items-center gap-2">
            @if (item.icon) {
              <span [class]="'p-menubar-item-icon ' + item.icon"></span>
            }
            <span class="p-menubar-item-label">{{ item.label }}</span>
            @if (hasSubmenu) {
              <span
                [class]="root ? 'p-menubar-submenu-icon ti ti-chevron-down' : 'p-menubar-submenu-icon ti ti-chevron-right'"
              ></span>
            }
          </a>
        }
      </ng-template>
    </p-menubar>
  `
                }]
        }], propDecorators: { model: [{
                type: Input
            }], itemTemplate: [{
                type: ContentChild,
                args: [ExtraMenubarItemDirective, { read: TemplateRef }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraMenubarComponent, ExtraMenubarItemDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-menubar.mjs.map
