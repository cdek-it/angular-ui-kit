import * as i0 from '@angular/core';
import { inject, Injector, DestroyRef, EventEmitter, forwardRef, booleanAttribute, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormControl, NgControl, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgTemplateOutlet } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { InputMask } from 'primeng/inputmask';
import { FloatLabel } from 'primeng/floatlabel';
import { ExtraTooltipDirective } from '@cdek-it/angular-ui-kit/components/tooltip';

let nextInputId = 0;
class ExtraInputMaskComponent {
    _injector = inject(Injector);
    destroyRef = inject(DestroyRef);
    _ngControl = null;
    control = new FormControl(null);
    /** Уникальный id поля для связи label ↔ input. */
    inputId = `extra-input-mask-${nextInputId++}`;
    mask = '';
    slotChar = '_';
    autoClear = true;
    /** Отображение иконки очистки поля при наличии значения. */
    clearable = false;
    unmask = false;
    placeholder = '';
    label = '';
    labelPosition = 'top';
    /** Плавающий лейбл внутри поля (PrimeNG `p-floatlabel`); перекрывает `labelPosition`. */
    floatLabel = false;
    caption = '';
    info = '';
    size = 'base';
    readonly = false;
    /** Растягивает поле на всю ширину контейнера. */
    fluid = false;
    characterPattern = '[A-Za-z]';
    keepBuffer = false;
    autocomplete = '';
    onComplete = new EventEmitter();
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    onInput = new EventEmitter();
    onClear = new EventEmitter();
    _onChange = () => { };
    _onTouched = () => { };
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
        this.control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((v) => this._onChange(v));
    }
    get invalid() {
        return this._ngControl?.invalid ?? false;
    }
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large' || this.size === 'xlarge')
            return 'large';
        return undefined;
    }
    /**
     * Классы на сам input (p-inputmask прокидывает styleClass именно туда):
     * xlg — размер вне шкалы PrimeNG, clearable — место под иконку очистки справа.
     * Класс вешаем по пропу, а не по наличию иконки: иконка появляется только у
     * заполненного поля, и padding прыгал бы на первом введённом символе.
     */
    get fieldClass() {
        return [this.size === 'xlarge' ? 'p-inputtext-xlg' : '', this.clearable ? 'extra-inputmask-clearable' : '']
            .filter(Boolean)
            .join(' ');
    }
    /**
     * p-inputmask пишет placeholder в атрибут как есть, а FloatLabel поднимает лейбл
     * по селектору `:has(input[placeholder])` — с пустой строкой атрибут остаётся в DOM
     * и лейбл висит наверху всегда. Пустое значение отдаём как undefined.
     */
    get fieldPlaceholder() {
        return this.placeholder || undefined;
    }
    handleBlur(event) {
        this._onTouched();
        this.onBlur.emit(event);
    }
    writeValue(value) {
        this.control.setValue(value ?? null, { emitEvent: false });
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        isDisabled ? this.control.disable({ emitEvent: false }) : this.control.enable({ emitEvent: false });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputMaskComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraInputMaskComponent, isStandalone: true, selector: "extra-input-mask", inputs: { mask: "mask", slotChar: "slotChar", autoClear: ["autoClear", "autoClear", booleanAttribute], clearable: ["clearable", "clearable", booleanAttribute], unmask: ["unmask", "unmask", booleanAttribute], placeholder: "placeholder", label: "label", labelPosition: "labelPosition", floatLabel: ["floatLabel", "floatLabel", booleanAttribute], caption: "caption", info: "info", size: "size", readonly: ["readonly", "readonly", booleanAttribute], fluid: ["fluid", "fluid", booleanAttribute], characterPattern: "characterPattern", keepBuffer: ["keepBuffer", "keepBuffer", booleanAttribute], autocomplete: "autocomplete" }, outputs: { onComplete: "onComplete", onFocus: "onFocus", onBlur: "onBlur", onInput: "onInput", onClear: "onClear" }, host: { styleAttribute: "display: contents" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraInputMaskComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    <!-- Без label/caption поле не оборачиваем — сохраняем прежнюю DOM-структуру
         (важно для p-inputgroup, где поле обязано быть прямым flex-элементом). -->
    @if (label || caption) {
      <!-- floatLabel перекрывает labelPosition: лейбл уезжает внутрь поля, строчной раскладки нет -->
      <div class="extra-inputmask" [class.extra-inputmask--left]="labelPosition === 'left' && !floatLabel">
        @if (label && labelPosition === 'left' && !floatLabel) {
          <ng-container [ngTemplateOutlet]="labelTpl" />
        }
        <div class="extra-inputmask-body">
          @if (label && labelPosition === 'top' && !floatLabel) {
            <ng-container [ngTemplateOutlet]="labelTpl" />
          }
          @if (floatLabel) {
            <p-floatlabel variant="in">
              <ng-container [ngTemplateOutlet]="fieldTpl" />
              @if (label) {
                <ng-container [ngTemplateOutlet]="labelTpl" />
              }
            </p-floatlabel>
          } @else {
            <ng-container [ngTemplateOutlet]="fieldTpl" />
          }
          @if (caption) {
            <div class="extra-inputmask-caption">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="fieldTpl" />
    }

    <ng-template #labelTpl>
      <label class="extra-inputmask-label" [for]="inputId">
        {{ label }}
        @if (info) {
          <i class="extra-inputmask-label-icon ti ti-info-circle" [extra-tooltip]="info"></i>
        }
      </label>
    </ng-template>

    <ng-template #fieldTpl>
      <p-inputmask
        [inputId]="inputId"
        [styleClass]="fieldClass"
        [size]="primeSize"
        [mask]="mask"
        [slotChar]="slotChar"
        [autoClear]="autoClear"
        [showClear]="clearable"
        [unmask]="unmask"
        [readonly]="readonly"
        [placeholder]="fieldPlaceholder"
        [fluid]="fluid"
        [characterPattern]="characterPattern"
        [keepBuffer]="keepBuffer"
        [invalid]="invalid"
        [autocomplete]="autocomplete"
        [formControl]="control"
        (onComplete)="onComplete.emit($event)"
        (onFocus)="onFocus.emit($event)"
        (onBlur)="handleBlur($event)"
        (onInput)="onInput.emit($event)"
        (onClear)="onClear.emit()"
      ></p-inputmask>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: InputMask, selector: "p-inputmask, p-inputMask, p-input-mask", inputs: ["type", "slotChar", "autoClear", "showClear", "style", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabel", "ariaLabelledBy", "ariaRequired", "readonly", "unmask", "characterPattern", "autofocus", "autocomplete", "keepBuffer", "mask"], outputs: ["onComplete", "onFocus", "onBlur", "onInput", "onKeydown", "onClear"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: ExtraTooltipDirective, selector: "[extra-tooltip]", inputs: ["extra-tooltip", "position", "event", "showDelay", "hideDelay", "tooltipDisabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputMaskComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-input-mask',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [InputMask, FloatLabel, NgTemplateOutlet, ReactiveFormsModule, ExtraTooltipDirective],
                    host: { style: 'display: contents' },
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraInputMaskComponent),
                            multi: true
                        }
                    ],
                    template: `
    <!-- Без label/caption поле не оборачиваем — сохраняем прежнюю DOM-структуру
         (важно для p-inputgroup, где поле обязано быть прямым flex-элементом). -->
    @if (label || caption) {
      <!-- floatLabel перекрывает labelPosition: лейбл уезжает внутрь поля, строчной раскладки нет -->
      <div class="extra-inputmask" [class.extra-inputmask--left]="labelPosition === 'left' && !floatLabel">
        @if (label && labelPosition === 'left' && !floatLabel) {
          <ng-container [ngTemplateOutlet]="labelTpl" />
        }
        <div class="extra-inputmask-body">
          @if (label && labelPosition === 'top' && !floatLabel) {
            <ng-container [ngTemplateOutlet]="labelTpl" />
          }
          @if (floatLabel) {
            <p-floatlabel variant="in">
              <ng-container [ngTemplateOutlet]="fieldTpl" />
              @if (label) {
                <ng-container [ngTemplateOutlet]="labelTpl" />
              }
            </p-floatlabel>
          } @else {
            <ng-container [ngTemplateOutlet]="fieldTpl" />
          }
          @if (caption) {
            <div class="extra-inputmask-caption">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="fieldTpl" />
    }

    <ng-template #labelTpl>
      <label class="extra-inputmask-label" [for]="inputId">
        {{ label }}
        @if (info) {
          <i class="extra-inputmask-label-icon ti ti-info-circle" [extra-tooltip]="info"></i>
        }
      </label>
    </ng-template>

    <ng-template #fieldTpl>
      <p-inputmask
        [inputId]="inputId"
        [styleClass]="fieldClass"
        [size]="primeSize"
        [mask]="mask"
        [slotChar]="slotChar"
        [autoClear]="autoClear"
        [showClear]="clearable"
        [unmask]="unmask"
        [readonly]="readonly"
        [placeholder]="fieldPlaceholder"
        [fluid]="fluid"
        [characterPattern]="characterPattern"
        [keepBuffer]="keepBuffer"
        [invalid]="invalid"
        [autocomplete]="autocomplete"
        [formControl]="control"
        (onComplete)="onComplete.emit($event)"
        (onFocus)="onFocus.emit($event)"
        (onBlur)="handleBlur($event)"
        (onInput)="onInput.emit($event)"
        (onClear)="onClear.emit()"
      ></p-inputmask>
    </ng-template>
  `
                }]
        }], propDecorators: { mask: [{
                type: Input
            }], slotChar: [{
                type: Input
            }], autoClear: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], clearable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], unmask: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], floatLabel: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], caption: [{
                type: Input
            }], info: [{
                type: Input
            }], size: [{
                type: Input
            }], readonly: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], fluid: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], characterPattern: [{
                type: Input
            }], keepBuffer: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], autocomplete: [{
                type: Input
            }], onComplete: [{
                type: Output
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], onInput: [{
                type: Output
            }], onClear: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraInputMaskComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-inputmask.mjs.map
