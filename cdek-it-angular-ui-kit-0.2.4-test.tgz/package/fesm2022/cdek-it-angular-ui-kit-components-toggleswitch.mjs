import * as i0 from '@angular/core';
import { EventEmitter, Output, Optional, Self, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ToggleSwitch } from 'primeng/toggleswitch';

class ExtraToggleSwitchComponent {
    ngControl;
    onChange = new EventEmitter();
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    modelValue = false;
    _disabled = false;
    _onChange = () => { };
    _onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (ngControl) {
            ngControl.valueAccessor = this;
        }
    }
    get isDisabled() {
        return this._disabled;
    }
    get isInvalid() {
        return !!this.ngControl?.invalid;
    }
    handleChange(value) {
        this.modelValue = value;
        this._onChange(value);
        this._onTouched();
    }
    writeValue(value) {
        this.modelValue = value ?? false;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToggleSwitchComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraToggleSwitchComponent, isStandalone: true, selector: "extra-toggleswitch", outputs: { onChange: "onChange", onFocus: "onFocus", onBlur: "onBlur" }, ngImport: i0, template: `
    <p-toggleswitch
      [ngModel]="modelValue"
      (ngModelChange)="handleChange($event)"
      [invalid]="isInvalid"
      [disabled]="isDisabled"
      (onChange)="onChange.emit($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
    ></p-toggleswitch>
  `, isInline: true, dependencies: [{ kind: "component", type: ToggleSwitch, selector: "p-toggleswitch, p-toggleSwitch, p-toggle-switch", inputs: ["styleClass", "tabindex", "inputId", "readonly", "trueValue", "falseValue", "ariaLabel", "size", "ariaLabelledBy", "autofocus"], outputs: ["onChange"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToggleSwitchComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-toggleswitch',
                    standalone: true,
                    imports: [ToggleSwitch, FormsModule],
                    template: `
    <p-toggleswitch
      [ngModel]="modelValue"
      (ngModelChange)="handleChange($event)"
      [invalid]="isInvalid"
      [disabled]="isDisabled"
      (onChange)="onChange.emit($event)"
      (onFocus)="onFocus.emit($event)"
      (onBlur)="onBlur.emit($event)"
    ></p-toggleswitch>
  `
                }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { onChange: [{
                type: Output
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraToggleSwitchComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-toggleswitch.mjs.map
