import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Divider } from 'primeng/divider';

class ExtraDividerComponent {
    layout = 'horizontal';
    type = 'solid';
    align = 'center';
    /** Маппинг Figma-значения `dash` на тип линии PrimeNG (`dashed`). */
    get primeType() {
        return this.type === 'dash' ? 'dashed' : 'solid';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDividerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraDividerComponent, isStandalone: true, selector: "extra-divider", inputs: { layout: "layout", type: "type", align: "align" }, ngImport: i0, template: `
    <p-divider [layout]="layout" [type]="primeType" [align]="align">
      <ng-content></ng-content>
    </p-divider>
  `, isInline: true, dependencies: [{ kind: "component", type: Divider, selector: "p-divider", inputs: ["styleClass", "layout", "type", "align"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraDividerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-divider',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Divider],
                    template: `
    <p-divider [layout]="layout" [type]="primeType" [align]="align">
      <ng-content></ng-content>
    </p-divider>
  `
                }]
        }], propDecorators: { layout: [{
                type: Input
            }], type: [{
                type: Input
            }], align: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraDividerComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-divider.mjs.map
