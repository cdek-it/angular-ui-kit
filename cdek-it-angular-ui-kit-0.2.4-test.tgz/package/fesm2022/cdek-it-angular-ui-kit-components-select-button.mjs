import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Optional, Self, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { SelectButton } from 'primeng/selectbutton';
import * as i2 from 'primeng/api';
import { SharedModule } from 'primeng/api';

class ExtraSelectButtonComponent {
    ngControl;
    options = [];
    optionLabel = 'name';
    optionValue = 'code';
    optionDisabled = 'disabled';
    size = 'base';
    multiple = false;
    allowEmpty = true;
    /** Растягивает группу на всю доступную ширину контейнера, сегменты делят её поровну. */
    fluid = false;
    onChange = new EventEmitter();
    value = null;
    _disabled = false;
    _onChange = (_) => { };
    _onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (ngControl)
            ngControl.valueAccessor = this;
    }
    get isDisabled() {
        return this._disabled;
    }
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large')
            return 'large';
        return undefined;
    }
    writeValue(value) {
        this.value = value ?? null;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled = isDisabled;
    }
    onValueChange(newValue) {
        this.value = newValue;
        this._onChange(newValue);
        this._onTouched();
    }
    onChangeHandler(event) {
        this.onChange.emit({ value: event.value, originalEvent: event.originalEvent });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectButtonComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraSelectButtonComponent, isStandalone: true, selector: "extra-select-button", inputs: { options: "options", optionLabel: "optionLabel", optionValue: "optionValue", optionDisabled: "optionDisabled", size: "size", multiple: "multiple", allowEmpty: "allowEmpty", fluid: "fluid" }, outputs: { onChange: "onChange" }, host: { properties: { "style.display": "fluid ? 'block' : null" } }, ngImport: i0, template: `
    <!-- Ступень xlg навешивается классом на корень: styleClass в PrimeNG 20 на корне
         p-selectbutton не остаётся, а раздаётся вниз каждому p-togglebutton, и стили
         ступени (.p-selectbutton-xlarge .p-togglebutton) не находят свой корень. -->
    <p-selectbutton
      [options]="options"
      [ngModel]="value"
      (ngModelChange)="onValueChange($event)"
      (onChange)="onChangeHandler($event)"
      [optionLabel]="optionLabel"
      [optionValue]="optionValue"
      [optionDisabled]="optionDisabled"
      [multiple]="multiple"
      [allowEmpty]="allowEmpty"
      [disabled]="isDisabled"
      [size]="primeSize"
      [fluid]="fluid"
      [class.p-selectbutton-xlarge]="size === 'xlarge'"
    >
      <ng-template pTemplate="item" let-item>
        @if ($any(item)['icon']) {
          <i [class]="$any(item)['icon']"></i>
        }
        <span>{{ $any(item)[optionLabel] }}</span>
      </ng-template>
    </p-selectbutton>
  `, isInline: true, dependencies: [{ kind: "component", type: SelectButton, selector: "p-selectButton, p-selectbutton, p-select-button", inputs: ["options", "optionLabel", "optionValue", "optionDisabled", "unselectable", "tabindex", "multiple", "allowEmpty", "styleClass", "ariaLabelledBy", "dataKey", "autofocus", "size", "fluid"], outputs: ["onOptionClick", "onChange"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-select-button',
                    standalone: true,
                    imports: [SelectButton, SharedModule, FormsModule],
                    // В обычном режиме хост остаётся inline (группа встаёт в строку рядом с другими элементами).
                    // В режиме fluid делаем его блоком: сам p-selectbutton — inline-flex, и без блочного хоста
                    // его width: 100% считается не от контейнера-родителя.
                    host: {
                        '[style.display]': "fluid ? 'block' : null"
                    },
                    template: `
    <!-- Ступень xlg навешивается классом на корень: styleClass в PrimeNG 20 на корне
         p-selectbutton не остаётся, а раздаётся вниз каждому p-togglebutton, и стили
         ступени (.p-selectbutton-xlarge .p-togglebutton) не находят свой корень. -->
    <p-selectbutton
      [options]="options"
      [ngModel]="value"
      (ngModelChange)="onValueChange($event)"
      (onChange)="onChangeHandler($event)"
      [optionLabel]="optionLabel"
      [optionValue]="optionValue"
      [optionDisabled]="optionDisabled"
      [multiple]="multiple"
      [allowEmpty]="allowEmpty"
      [disabled]="isDisabled"
      [size]="primeSize"
      [fluid]="fluid"
      [class.p-selectbutton-xlarge]="size === 'xlarge'"
    >
      <ng-template pTemplate="item" let-item>
        @if ($any(item)['icon']) {
          <i [class]="$any(item)['icon']"></i>
        }
        <span>{{ $any(item)[optionLabel] }}</span>
      </ng-template>
    </p-selectbutton>
  `
                }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { options: [{
                type: Input
            }], optionLabel: [{
                type: Input
            }], optionValue: [{
                type: Input
            }], optionDisabled: [{
                type: Input
            }], size: [{
                type: Input
            }], multiple: [{
                type: Input
            }], allowEmpty: [{
                type: Input
            }], fluid: [{
                type: Input
            }], onChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraSelectButtonComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-select-button.mjs.map
