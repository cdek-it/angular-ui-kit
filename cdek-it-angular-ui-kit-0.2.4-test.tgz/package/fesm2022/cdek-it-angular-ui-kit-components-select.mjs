import * as i0 from '@angular/core';
import { Directive, inject, Injector, EventEmitter, TemplateRef, forwardRef, booleanAttribute, Output, ContentChild, Input, Component } from '@angular/core';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/forms';
import { NgControl, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Select } from 'primeng/select';
import { FloatLabel } from 'primeng/floatlabel';
import { PrimeTemplate } from 'primeng/api';
import { ExtraTooltipDirective } from '@cdek-it/angular-ui-kit/components/tooltip';

let nextInputId = 0;
class ExtraSelectOptionDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectOptionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraSelectOptionDirective, isStandalone: true, selector: "[extraSelectOption]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectOptionDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraSelectOption]', standalone: true }]
        }] });
class ExtraSelectSelectedItemDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectSelectedItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraSelectSelectedItemDirective, isStandalone: true, selector: "[extraSelectSelectedItem]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectSelectedItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraSelectSelectedItem]', standalone: true }]
        }] });
class ExtraSelectOptionGroupDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectOptionGroupDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraSelectOptionGroupDirective, isStandalone: true, selector: "[extraSelectOptionGroup]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectOptionGroupDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraSelectOptionGroup]', standalone: true }]
        }] });
class ExtraSelectComponent {
    _injector = inject(Injector);
    _ngControl = null;
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
    }
    options;
    optionLabel;
    optionValue;
    optionDisabled;
    optionGroupLabel;
    optionGroupChildren = 'items';
    group = false;
    placeholder = '';
    label = '';
    labelPosition = 'top';
    /** Плавающий лейбл внутри поля (PrimeNG `p-floatlabel`); перекрывает `labelPosition`. */
    floatLabel = false;
    caption = '';
    info = '';
    size = 'base';
    showFilter = false;
    /** Отображение иконки очистки поля при наличии значения. */
    clearable = false;
    showCheckbox = true;
    editable = false;
    readonly = false;
    loading = false;
    inputId = `extra-select-${nextInputId++}`;
    appendTo = 'body';
    checkmarkIcon = 'ea5e';
    emptyMessage = 'Нет данных';
    emptyFilterMessage = 'Результаты не найдены';
    optionTemplate = null;
    selectedItemTemplate = null;
    optionGroupTemplate = null;
    disabled = false;
    modelValue = null;
    onChange = new EventEmitter();
    onClear = new EventEmitter();
    onFilter = new EventEmitter();
    onShow = new EventEmitter();
    onHide = new EventEmitter();
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    get invalid() {
        return !!(this._ngControl?.invalid && this._ngControl?.touched);
    }
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large' || this.size === 'xlarge')
            return 'large';
        return undefined;
    }
    get panelStyle() {
        const char = String.fromCodePoint(parseInt(this.checkmarkIcon, 16));
        return { '--p-select-checkmark-content': `"${char}"` };
    }
    get selectClasses() {
        return {
            'p-select-xlg': this.size === 'xlarge',
            'p-invalid': this.invalid
        };
    }
    _onChange = () => { };
    _onTouched = () => { };
    onSelectChange(event) {
        this.modelValue = event.value;
        this._onChange(event.value);
        this.onChange.emit({ value: event.value, originalEvent: event.originalEvent });
    }
    onFilterHandler(event) {
        this.onFilter.emit({ filter: event.filter, originalEvent: event.originalEvent });
    }
    handleBlur(event) {
        this._onTouched();
        this.onBlur.emit(event);
    }
    writeValue(value) {
        this.modelValue = value ?? null;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraSelectComponent, isStandalone: true, selector: "extra-select", inputs: { options: "options", optionLabel: "optionLabel", optionValue: "optionValue", optionDisabled: "optionDisabled", optionGroupLabel: "optionGroupLabel", optionGroupChildren: "optionGroupChildren", group: ["group", "group", booleanAttribute], placeholder: "placeholder", label: "label", labelPosition: "labelPosition", floatLabel: ["floatLabel", "floatLabel", booleanAttribute], caption: "caption", info: "info", size: "size", showFilter: ["showFilter", "showFilter", booleanAttribute], clearable: ["clearable", "clearable", booleanAttribute], showCheckbox: ["showCheckbox", "showCheckbox", booleanAttribute], editable: ["editable", "editable", booleanAttribute], readonly: ["readonly", "readonly", booleanAttribute], loading: ["loading", "loading", booleanAttribute], inputId: "inputId", appendTo: "appendTo", checkmarkIcon: "checkmarkIcon", emptyMessage: "emptyMessage", emptyFilterMessage: "emptyFilterMessage" }, outputs: { onChange: "onChange", onClear: "onClear", onFilter: "onFilter", onShow: "onShow", onHide: "onHide", onFocus: "onFocus", onBlur: "onBlur" }, host: { styleAttribute: "display: contents" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraSelectComponent),
                multi: true
            }
        ], queries: [{ propertyName: "optionTemplate", first: true, predicate: ExtraSelectOptionDirective, descendants: true, read: TemplateRef }, { propertyName: "selectedItemTemplate", first: true, predicate: ExtraSelectSelectedItemDirective, descendants: true, read: TemplateRef }, { propertyName: "optionGroupTemplate", first: true, predicate: ExtraSelectOptionGroupDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    @if (label || caption) {
      <!-- floatLabel перекрывает labelPosition: лейбл уезжает внутрь поля, строчной раскладки нет -->
      <div class="extra-select" [class.extra-select--left]="labelPosition === 'left' && !floatLabel">
        @if (label && labelPosition === 'left' && !floatLabel) {
          <ng-container [ngTemplateOutlet]="labelTpl" />
        }
        <div class="extra-select-body">
          @if (label && labelPosition === 'top' && !floatLabel) {
            <ng-container [ngTemplateOutlet]="labelTpl" />
          }
          @if (floatLabel) {
            <p-floatlabel variant="in">
              <ng-container [ngTemplateOutlet]="selectTpl" />
              @if (label) {
                <ng-container [ngTemplateOutlet]="labelTpl" />
              }
            </p-floatlabel>
          } @else {
            <ng-container [ngTemplateOutlet]="selectTpl" />
          }
          @if (caption) {
            <div class="extra-select-caption">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="selectTpl" />
    }

    <ng-template #labelTpl>
      <label class="extra-select-label" [for]="inputId">
        {{ label }}
        @if (info) {
          <i class="extra-select-label-icon ti ti-info-circle" [extra-tooltip]="info"></i>
        }
      </label>
    </ng-template>

    <ng-template #selectTpl>
      <p-select
        [ngClass]="selectClasses"
        [ngModel]="modelValue"
        [disabled]="disabled"
        [options]="options"
        [optionLabel]="optionLabel"
        [optionValue]="optionValue"
        [optionDisabled]="optionDisabled"
        [optionGroupLabel]="optionGroupLabel"
        [optionGroupChildren]="optionGroupChildren"
        [group]="group"
        [placeholder]="placeholder"
        [filter]="showFilter"
        [showClear]="clearable"
        [editable]="editable"
        [readonly]="readonly"
        [loading]="loading"
        [inputId]="inputId"
        [appendTo]="appendTo"
        [size]="primeSize"
        [checkmark]="showCheckbox"
        [panelStyle]="panelStyle"
        [emptyMessage]="emptyMessage"
        [emptyFilterMessage]="emptyFilterMessage"
        (onChange)="onSelectChange($event)"
        (onClear)="onClear.emit()"
        (onFilter)="onFilterHandler($event)"
        (onShow)="onShow.emit()"
        (onHide)="onHide.emit()"
        (onFocus)="onFocus.emit($event)"
        (onBlur)="handleBlur($event)"
      >
        @if (optionTemplate) {
          <ng-template pTemplate="item" let-option>
            <ng-container
              [ngTemplateOutlet]="optionTemplate"
              [ngTemplateOutletContext]="{ $implicit: option }"
            ></ng-container>
          </ng-template>
        }
        @if (selectedItemTemplate) {
          <ng-template pTemplate="selectedItem" let-option>
            <ng-container
              [ngTemplateOutlet]="selectedItemTemplate"
              [ngTemplateOutletContext]="{ $implicit: option }"
            ></ng-container>
          </ng-template>
        }
        @if (optionGroupTemplate) {
          <ng-template pTemplate="group" let-group>
            <ng-container
              [ngTemplateOutlet]="optionGroupTemplate"
              [ngTemplateOutletContext]="{ $implicit: group }"
            ></ng-container>
          </ng-template>
        }
      </p-select>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "directive", type: ExtraTooltipDirective, selector: "[extra-tooltip]", inputs: ["extra-tooltip", "position", "event", "showDelay", "hideDelay", "tooltipDisabled"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSelectComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-select',
                    standalone: true,
                    imports: [Select, NgClass, NgTemplateOutlet, PrimeTemplate, FormsModule, FloatLabel, ExtraTooltipDirective],
                    host: { style: 'display: contents' },
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraSelectComponent),
                            multi: true
                        }
                    ],
                    template: `
    @if (label || caption) {
      <!-- floatLabel перекрывает labelPosition: лейбл уезжает внутрь поля, строчной раскладки нет -->
      <div class="extra-select" [class.extra-select--left]="labelPosition === 'left' && !floatLabel">
        @if (label && labelPosition === 'left' && !floatLabel) {
          <ng-container [ngTemplateOutlet]="labelTpl" />
        }
        <div class="extra-select-body">
          @if (label && labelPosition === 'top' && !floatLabel) {
            <ng-container [ngTemplateOutlet]="labelTpl" />
          }
          @if (floatLabel) {
            <p-floatlabel variant="in">
              <ng-container [ngTemplateOutlet]="selectTpl" />
              @if (label) {
                <ng-container [ngTemplateOutlet]="labelTpl" />
              }
            </p-floatlabel>
          } @else {
            <ng-container [ngTemplateOutlet]="selectTpl" />
          }
          @if (caption) {
            <div class="extra-select-caption">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="selectTpl" />
    }

    <ng-template #labelTpl>
      <label class="extra-select-label" [for]="inputId">
        {{ label }}
        @if (info) {
          <i class="extra-select-label-icon ti ti-info-circle" [extra-tooltip]="info"></i>
        }
      </label>
    </ng-template>

    <ng-template #selectTpl>
      <p-select
        [ngClass]="selectClasses"
        [ngModel]="modelValue"
        [disabled]="disabled"
        [options]="options"
        [optionLabel]="optionLabel"
        [optionValue]="optionValue"
        [optionDisabled]="optionDisabled"
        [optionGroupLabel]="optionGroupLabel"
        [optionGroupChildren]="optionGroupChildren"
        [group]="group"
        [placeholder]="placeholder"
        [filter]="showFilter"
        [showClear]="clearable"
        [editable]="editable"
        [readonly]="readonly"
        [loading]="loading"
        [inputId]="inputId"
        [appendTo]="appendTo"
        [size]="primeSize"
        [checkmark]="showCheckbox"
        [panelStyle]="panelStyle"
        [emptyMessage]="emptyMessage"
        [emptyFilterMessage]="emptyFilterMessage"
        (onChange)="onSelectChange($event)"
        (onClear)="onClear.emit()"
        (onFilter)="onFilterHandler($event)"
        (onShow)="onShow.emit()"
        (onHide)="onHide.emit()"
        (onFocus)="onFocus.emit($event)"
        (onBlur)="handleBlur($event)"
      >
        @if (optionTemplate) {
          <ng-template pTemplate="item" let-option>
            <ng-container
              [ngTemplateOutlet]="optionTemplate"
              [ngTemplateOutletContext]="{ $implicit: option }"
            ></ng-container>
          </ng-template>
        }
        @if (selectedItemTemplate) {
          <ng-template pTemplate="selectedItem" let-option>
            <ng-container
              [ngTemplateOutlet]="selectedItemTemplate"
              [ngTemplateOutletContext]="{ $implicit: option }"
            ></ng-container>
          </ng-template>
        }
        @if (optionGroupTemplate) {
          <ng-template pTemplate="group" let-group>
            <ng-container
              [ngTemplateOutlet]="optionGroupTemplate"
              [ngTemplateOutletContext]="{ $implicit: group }"
            ></ng-container>
          </ng-template>
        }
      </p-select>
    </ng-template>
  `
                }]
        }], propDecorators: { options: [{
                type: Input
            }], optionLabel: [{
                type: Input
            }], optionValue: [{
                type: Input
            }], optionDisabled: [{
                type: Input
            }], optionGroupLabel: [{
                type: Input
            }], optionGroupChildren: [{
                type: Input
            }], group: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], placeholder: [{
                type: Input
            }], label: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], floatLabel: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], caption: [{
                type: Input
            }], info: [{
                type: Input
            }], size: [{
                type: Input
            }], showFilter: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], clearable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], showCheckbox: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], editable: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], readonly: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], loading: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], inputId: [{
                type: Input
            }], appendTo: [{
                type: Input
            }], checkmarkIcon: [{
                type: Input
            }], emptyMessage: [{
                type: Input
            }], emptyFilterMessage: [{
                type: Input
            }], optionTemplate: [{
                type: ContentChild,
                args: [ExtraSelectOptionDirective, { read: TemplateRef }]
            }], selectedItemTemplate: [{
                type: ContentChild,
                args: [ExtraSelectSelectedItemDirective, { read: TemplateRef }]
            }], optionGroupTemplate: [{
                type: ContentChild,
                args: [ExtraSelectOptionGroupDirective, { read: TemplateRef }]
            }], onChange: [{
                type: Output
            }], onClear: [{
                type: Output
            }], onFilter: [{
                type: Output
            }], onShow: [{
                type: Output
            }], onHide: [{
                type: Output
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraSelectComponent, ExtraSelectOptionDirective, ExtraSelectOptionGroupDirective, ExtraSelectSelectedItemDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-select.mjs.map
