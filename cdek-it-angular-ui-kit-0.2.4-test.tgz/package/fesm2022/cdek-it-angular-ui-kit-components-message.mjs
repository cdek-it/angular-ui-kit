import * as i0 from '@angular/core';
import { Input, Directive, EventEmitter, ContentChildren, ViewChild, Output, ChangeDetectionStrategy, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Message } from 'primeng/message';
import { ButtonDirective } from 'primeng/button';
import * as i1 from 'primeng/api';
import { SharedModule } from 'primeng/api';

/**
 * Именованный шаблон для слотов ExtraMessageComponent.
 *
 * ```html
 * <extra-message message="..." caption="...">
 *   Контент после caption
 *   <ng-template extraMessageTemplate="footer">
 *     <extra-button label="Действие" />
 *   </ng-template>
 * </extra-message>
 * ```
 */
class ExtraMessageTemplateDirective {
    template;
    /** Имя слота: footer. */
    extraMessageTemplate;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMessageTemplateDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraMessageTemplateDirective, isStandalone: true, selector: "[extraMessageTemplate]", inputs: { extraMessageTemplate: "extraMessageTemplate" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMessageTemplateDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[extraMessageTemplate]'
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { extraMessageTemplate: [{
                type: Input,
                args: [{ required: true }]
            }] } });

const SEVERITY_ICONS = {
    info: 'ti ti-info-circle',
    success: 'ti ti-circle-check',
    warning: 'ti ti-alert-triangle',
    danger: 'ti ti-alert-circle'
};
/** Длительность таймера автоскрытия при [timer]="true" (мс). */
const TIMER_LIFE = 3000;
class ExtraMessageComponent {
    cdr;
    severity = 'info';
    /** Таймер автоскрытия (3 с). */
    timer = false;
    message = '';
    caption = '';
    /** Класс иконки tabler icon; null скрывает иконку; undefined (не задан) — стандартная по severity. */
    icon = undefined;
    showClose = false;
    /** Ширина сообщения; `fill` — на всю ширину контейнера. */
    size = 'base';
    onClose = new EventEmitter();
    primeMessage;
    templates;
    footerTpl;
    closed = false;
    timerId;
    constructor(cdr) {
        this.cdr = cdr;
    }
    get resolvedIcon() {
        if (this.icon === null)
            return null;
        return this.icon ?? SEVERITY_ICONS[this.severity];
    }
    get sizeClass() {
        return this.size === 'base' ? '' : `p-message-size-${this.size}`;
    }
    get primeSeverity() {
        if (this.severity === 'warning')
            return 'warn';
        if (this.severity === 'danger')
            return 'error';
        return this.severity;
    }
    ngAfterContentInit() {
        this.footerTpl = this.templates.find((tpl) => tpl.extraMessageTemplate === 'footer');
        this.cdr.detectChanges();
        if (this.timer) {
            this.timerId = setTimeout(() => this.close(), TIMER_LIFE);
        }
    }
    ngOnDestroy() {
        clearTimeout(this.timerId);
    }
    /** Закрывает сообщение (крестиком, программно или по таймеру) и эмитит onClose. */
    close(event) {
        if (this.closed)
            return;
        this.closed = true;
        clearTimeout(this.timerId);
        this.primeMessage?.close(event);
        this.onClose.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMessageComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraMessageComponent, isStandalone: true, selector: "extra-message", inputs: { severity: "severity", timer: "timer", message: "message", caption: "caption", icon: "icon", showClose: "showClose", size: "size" }, outputs: { onClose: "onClose" }, queries: [{ propertyName: "templates", predicate: ExtraMessageTemplateDirective }], viewQueries: [{ propertyName: "primeMessage", first: true, predicate: Message, descendants: true }], ngImport: i0, template: `
    <p-message [severity]="primeSeverity" [closable]="false" [styleClass]="sizeClass">
      <ng-template pTemplate="container">
        <div class="p-message-accent-line"></div>
        @if (resolvedIcon) {
          <i [class]="resolvedIcon + ' p-message-icon'"></i>
        }
        <div class="p-message-text">
          @if (message) {
            <span class="p-message-summary">{{ message }}</span>
          }
          @if (caption) {
            <div class="p-message-detail">{{ caption }}</div>
          }
          <ng-content />
        </div>
        @if (showClose) {
          <button
            type="button"
            pButton
            [text]="true"
            icon="ti ti-x"
            class="p-message-close-button"
            (click)="close($event)"
          ></button>
        }
        @if (footerTpl) {
          <div class="p-message-footer">
            <ng-container [ngTemplateOutlet]="footerTpl.template" />
          </div>
        }
      </ng-template>
    </p-message>
  `, isInline: true, dependencies: [{ kind: "component", type: Message, selector: "p-message", inputs: ["severity", "text", "escape", "style", "styleClass", "closable", "icon", "closeIcon", "life", "showTransitionOptions", "hideTransitionOptions", "size", "variant"], outputs: ["onClose"] }, { kind: "directive", type: ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMessageComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-message',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Message, ButtonDirective, SharedModule, NgTemplateOutlet],
                    template: `
    <p-message [severity]="primeSeverity" [closable]="false" [styleClass]="sizeClass">
      <ng-template pTemplate="container">
        <div class="p-message-accent-line"></div>
        @if (resolvedIcon) {
          <i [class]="resolvedIcon + ' p-message-icon'"></i>
        }
        <div class="p-message-text">
          @if (message) {
            <span class="p-message-summary">{{ message }}</span>
          }
          @if (caption) {
            <div class="p-message-detail">{{ caption }}</div>
          }
          <ng-content />
        </div>
        @if (showClose) {
          <button
            type="button"
            pButton
            [text]="true"
            icon="ti ti-x"
            class="p-message-close-button"
            (click)="close($event)"
          ></button>
        }
        @if (footerTpl) {
          <div class="p-message-footer">
            <ng-container [ngTemplateOutlet]="footerTpl.template" />
          </div>
        }
      </ng-template>
    </p-message>
  `
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { severity: [{
                type: Input
            }], timer: [{
                type: Input
            }], message: [{
                type: Input
            }], caption: [{
                type: Input
            }], icon: [{
                type: Input
            }], showClose: [{
                type: Input
            }], size: [{
                type: Input
            }], onClose: [{
                type: Output
            }], primeMessage: [{
                type: ViewChild,
                args: [Message]
            }], templates: [{
                type: ContentChildren,
                args: [ExtraMessageTemplateDirective]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraMessageComponent, ExtraMessageTemplateDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-message.mjs.map
