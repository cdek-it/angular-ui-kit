import * as i0 from '@angular/core';
import { Directive, EventEmitter, TemplateRef, forwardRef, Output, Input, ContentChild, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgTemplateOutlet } from '@angular/common';
import { Password } from 'primeng/password';
import { PrimeTemplate } from 'primeng/api';
import { FloatLabel } from 'primeng/floatlabel';

class ExtraPasswordHeaderDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPasswordHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraPasswordHeaderDirective, isStandalone: true, selector: "[extraPasswordHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPasswordHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraPasswordHeader]', standalone: true }]
        }] });
class ExtraPasswordFooterDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPasswordFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraPasswordFooterDirective, isStandalone: true, selector: "[extraPasswordFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPasswordFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraPasswordFooter]', standalone: true }]
        }] });
class ExtraPasswordComponent {
    headerTemplate = null;
    footerTemplate = null;
    feedback = true;
    toggleMask = false;
    disabled = false;
    placeholder = undefined;
    size = 'base';
    variant = 'outlined';
    fluid = false;
    invalid = false;
    floatLabel = false;
    label = '';
    promptLabel = 'Введите пароль';
    weakLabel = 'Слабый';
    mediumLabel = 'Средний';
    strongLabel = 'Надёжный';
    inputId = undefined;
    inputStyleClass = undefined;
    ariaLabel = undefined;
    ariaLabelledBy = undefined;
    appendTo = 'body';
    autofocus = false;
    onFocus = new EventEmitter();
    onBlur = new EventEmitter();
    get sizeClass() {
        if (this.size === 'small')
            return 'p-inputtext-sm';
        if (this.size === 'large')
            return 'p-inputtext-lg';
        if (this.size === 'xlarge')
            return 'p-inputtext-lg p-inputtext-xlg';
        return '';
    }
    get computedInputStyleClass() {
        return [this.sizeClass, this.inputStyleClass].filter(Boolean).join(' ');
    }
    modelValue = null;
    _onChange = () => { };
    _onTouched = () => { };
    handleChange(value) {
        this.modelValue = value;
        this._onChange(value);
        this._onTouched();
    }
    writeValue(value) {
        this.modelValue = value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPasswordComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraPasswordComponent, isStandalone: true, selector: "extra-password", inputs: { feedback: "feedback", toggleMask: "toggleMask", disabled: "disabled", placeholder: "placeholder", size: "size", variant: "variant", fluid: "fluid", invalid: "invalid", floatLabel: "floatLabel", label: "label", promptLabel: "promptLabel", weakLabel: "weakLabel", mediumLabel: "mediumLabel", strongLabel: "strongLabel", inputId: "inputId", inputStyleClass: "inputStyleClass", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy", appendTo: "appendTo", autofocus: "autofocus" }, outputs: { onFocus: "onFocus", onBlur: "onBlur" }, host: { styleAttribute: "display: block" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraPasswordComponent),
                multi: true
            }
        ], queries: [{ propertyName: "headerTemplate", first: true, predicate: ExtraPasswordHeaderDirective, descendants: true, read: TemplateRef }, { propertyName: "footerTemplate", first: true, predicate: ExtraPasswordFooterDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    @if (floatLabel) {
      <p-floatlabel variant="in">
        <ng-container *ngTemplateOutlet="passwordTpl"></ng-container>
        <label [attr.for]="inputId">{{ label }}</label>
      </p-floatlabel>
    } @else {
      <ng-container *ngTemplateOutlet="passwordTpl"></ng-container>
    }

    <ng-template #passwordTpl>
      <p-password
        [ngModel]="modelValue"
        (ngModelChange)="handleChange($event)"
        [feedback]="feedback"
        [toggleMask]="toggleMask"
        [inputStyleClass]="computedInputStyleClass"
        [disabled]="disabled"
        [placeholder]="placeholder"
        [promptLabel]="promptLabel"
        [weakLabel]="weakLabel"
        [mediumLabel]="mediumLabel"
        [strongLabel]="strongLabel"
        [variant]="variant"
        [fluid]="fluid"
        [invalid]="invalid"
        [inputId]="inputId"
        [ariaLabel]="ariaLabel"
        [ariaLabelledBy]="ariaLabelledBy"
        [appendTo]="appendTo"
        [autofocus]="autofocus"
        (onFocus)="onFocus.emit($event)"
        (onBlur)="onBlur.emit($event)"
      >
        @if (headerTemplate) {
          <ng-template pTemplate="header">
            <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
          </ng-template>
        }
        @if (footerTemplate) {
          <ng-template pTemplate="footer">
            <ng-container *ngTemplateOutlet="footerTemplate"></ng-container>
          </ng-template>
        }
      </p-password>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: Password, selector: "p-password", inputs: ["ariaLabel", "ariaLabelledBy", "label", "promptLabel", "mediumRegex", "strongRegex", "weakLabel", "mediumLabel", "maxLength", "strongLabel", "inputId", "feedback", "toggleMask", "inputStyleClass", "styleClass", "inputStyle", "showTransitionOptions", "hideTransitionOptions", "autocomplete", "placeholder", "showClear", "autofocus", "tabindex", "appendTo"], outputs: ["onFocus", "onBlur", "onClear"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPasswordComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-password',
                    host: { style: 'display: block' },
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Password, FormsModule, FloatLabel, NgTemplateOutlet, PrimeTemplate],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraPasswordComponent),
                            multi: true
                        }
                    ],
                    template: `
    @if (floatLabel) {
      <p-floatlabel variant="in">
        <ng-container *ngTemplateOutlet="passwordTpl"></ng-container>
        <label [attr.for]="inputId">{{ label }}</label>
      </p-floatlabel>
    } @else {
      <ng-container *ngTemplateOutlet="passwordTpl"></ng-container>
    }

    <ng-template #passwordTpl>
      <p-password
        [ngModel]="modelValue"
        (ngModelChange)="handleChange($event)"
        [feedback]="feedback"
        [toggleMask]="toggleMask"
        [inputStyleClass]="computedInputStyleClass"
        [disabled]="disabled"
        [placeholder]="placeholder"
        [promptLabel]="promptLabel"
        [weakLabel]="weakLabel"
        [mediumLabel]="mediumLabel"
        [strongLabel]="strongLabel"
        [variant]="variant"
        [fluid]="fluid"
        [invalid]="invalid"
        [inputId]="inputId"
        [ariaLabel]="ariaLabel"
        [ariaLabelledBy]="ariaLabelledBy"
        [appendTo]="appendTo"
        [autofocus]="autofocus"
        (onFocus)="onFocus.emit($event)"
        (onBlur)="onBlur.emit($event)"
      >
        @if (headerTemplate) {
          <ng-template pTemplate="header">
            <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
          </ng-template>
        }
        @if (footerTemplate) {
          <ng-template pTemplate="footer">
            <ng-container *ngTemplateOutlet="footerTemplate"></ng-container>
          </ng-template>
        }
      </p-password>
    </ng-template>
  `
                }]
        }], propDecorators: { headerTemplate: [{
                type: ContentChild,
                args: [ExtraPasswordHeaderDirective, { read: TemplateRef }]
            }], footerTemplate: [{
                type: ContentChild,
                args: [ExtraPasswordFooterDirective, { read: TemplateRef }]
            }], feedback: [{
                type: Input
            }], toggleMask: [{
                type: Input
            }], disabled: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], size: [{
                type: Input
            }], variant: [{
                type: Input
            }], fluid: [{
                type: Input
            }], invalid: [{
                type: Input
            }], floatLabel: [{
                type: Input
            }], label: [{
                type: Input
            }], promptLabel: [{
                type: Input
            }], weakLabel: [{
                type: Input
            }], mediumLabel: [{
                type: Input
            }], strongLabel: [{
                type: Input
            }], inputId: [{
                type: Input
            }], inputStyleClass: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], appendTo: [{
                type: Input
            }], autofocus: [{
                type: Input
            }], onFocus: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraPasswordComponent, ExtraPasswordFooterDirective, ExtraPasswordHeaderDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-password.mjs.map
