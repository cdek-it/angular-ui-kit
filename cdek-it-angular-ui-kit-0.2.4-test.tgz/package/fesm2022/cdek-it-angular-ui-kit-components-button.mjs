import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Button } from 'primeng/button';

class ExtraButtonComponent {
    label = '';
    icon = '';
    iconPosition = 'left';
    variant = 'primary';
    severity = 'base';
    size = 'base';
    rounded = false;
    fluid = false;
    disabled = false;
    loading = false;
    focus = new EventEmitter();
    blur = new EventEmitter();
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large')
            return 'large';
        return undefined;
    }
    get primeStyleClass() {
        return this.size === 'xlarge' ? 'p-button-xlg' : '';
    }
    get primeSeverity() {
        if (this.severity === 'base') {
            if (this.variant === 'secondary')
                return 'secondary';
            if (this.variant === 'tertiary')
                return 'contrast';
            return null;
        }
        return this.severity === 'warning' ? 'warn' : this.severity;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraButtonComponent, isStandalone: true, selector: "extra-button", inputs: { label: "label", icon: "icon", iconPosition: "iconPosition", variant: "variant", severity: "severity", size: "size", rounded: "rounded", fluid: "fluid", disabled: "disabled", loading: "loading" }, outputs: { focus: "focus", blur: "blur" }, ngImport: i0, template: `
    <p-button
      [label]="label"
      [icon]="icon"
      [iconPos]="iconPosition"
      [severity]="primeSeverity"
      [size]="primeSize"
      [styleClass]="primeStyleClass"
      [rounded]="rounded"
      [fluid]="fluid"
      [text]="variant === 'text'"
      [link]="variant === 'link'"
      [disabled]="disabled"
      [loading]="loading"
      (onFocus)="focus.emit($event)"
      (onBlur)="blur.emit($event)"
    ></p-button>
  `, isInline: true, dependencies: [{ kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-button',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Button],
                    template: `
    <p-button
      [label]="label"
      [icon]="icon"
      [iconPos]="iconPosition"
      [severity]="primeSeverity"
      [size]="primeSize"
      [styleClass]="primeStyleClass"
      [rounded]="rounded"
      [fluid]="fluid"
      [text]="variant === 'text'"
      [link]="variant === 'link'"
      [disabled]="disabled"
      [loading]="loading"
      (onFocus)="focus.emit($event)"
      (onBlur)="blur.emit($event)"
    ></p-button>
  `
                }]
        }], propDecorators: { label: [{
                type: Input
            }], icon: [{
                type: Input
            }], iconPosition: [{
                type: Input
            }], variant: [{
                type: Input
            }], severity: [{
                type: Input
            }], size: [{
                type: Input
            }], rounded: [{
                type: Input
            }], fluid: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loading: [{
                type: Input
            }], focus: [{
                type: Output
            }], blur: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraButtonComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-button.mjs.map
