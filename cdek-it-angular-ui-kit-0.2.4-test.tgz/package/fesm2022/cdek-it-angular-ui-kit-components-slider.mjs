import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormControl, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Slider } from 'primeng/slider';

class ExtraSliderComponent {
    min = 0;
    max = 100;
    step = undefined;
    range = false;
    orientation = 'horizontal';
    set disabled(value) {
        value ? this.control.disable() : this.control.enable();
    }
    onSlideEnd = new EventEmitter();
    control = new FormControl(0, { nonNullable: true });
    _onChange = () => { };
    _onTouched = () => { };
    _sub;
    constructor() {
        this._sub = this.control.valueChanges.subscribe((v) => this._onChange(v));
    }
    ngOnChanges(changes) {
        if (changes['range']) {
            const current = this.control.value;
            if (this.range && !Array.isArray(current)) {
                this.control.setValue([this.min, this.max], { emitEvent: false });
            }
            else if (!this.range && Array.isArray(current)) {
                this.control.setValue(current[0], { emitEvent: false });
            }
        }
    }
    ngOnDestroy() {
        this._sub.unsubscribe();
    }
    writeValue(value) {
        this.control.setValue(this.normalize(value ?? 0), { emitEvent: false });
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        isDisabled ? this.control.disable() : this.control.enable();
    }
    normalize(value) {
        if (this.range && !Array.isArray(value))
            return [this.min, this.max];
        if (!this.range && Array.isArray(value))
            return value[0];
        return value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraSliderComponent, isStandalone: true, selector: "extra-slider", inputs: { min: "min", max: "max", step: "step", range: "range", orientation: "orientation", disabled: "disabled" }, outputs: { onSlideEnd: "onSlideEnd" }, host: { styleAttribute: "display: block" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraSliderComponent),
                multi: true
            }
        ], usesOnChanges: true, ngImport: i0, template: `
    <p-slider
      [formControl]="control"
      [min]="min"
      [max]="max"
      [step]="step"
      [range]="range"
      [orientation]="orientation"
      (onSlideEnd)="onSlideEnd.emit($event)"
    ></p-slider>
  `, isInline: true, dependencies: [{ kind: "component", type: Slider, selector: "p-slider", inputs: ["animate", "min", "max", "orientation", "step", "range", "styleClass", "ariaLabel", "ariaLabelledBy", "tabindex", "autofocus"], outputs: ["onChange", "onSlideEnd"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSliderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-slider',
                    host: { style: 'display: block' },
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Slider, ReactiveFormsModule],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraSliderComponent),
                            multi: true
                        }
                    ],
                    template: `
    <p-slider
      [formControl]="control"
      [min]="min"
      [max]="max"
      [step]="step"
      [range]="range"
      [orientation]="orientation"
      (onSlideEnd)="onSlideEnd.emit($event)"
    ></p-slider>
  `
                }]
        }], ctorParameters: () => [], propDecorators: { min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], range: [{
                type: Input
            }], orientation: [{
                type: Input
            }], disabled: [{
                type: Input
            }], onSlideEnd: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraSliderComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-slider.mjs.map
