import * as i0 from '@angular/core';
import { Input, Component } from '@angular/core';
import { ScrollPanel } from 'primeng/scrollpanel';

class ExtraScrollPanelComponent {
    step = 10;
    height = '100px';
    width = '100%';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraScrollPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraScrollPanelComponent, isStandalone: true, selector: "extra-scroll-panel", inputs: { step: "step", height: "height", width: "width" }, host: { styleAttribute: "display: block" }, ngImport: i0, template: `
    <p-scrollpanel [step]="step" [style]="{ width: width, height: height }">
      <ng-content></ng-content>
    </p-scrollpanel>
  `, isInline: true, dependencies: [{ kind: "component", type: ScrollPanel, selector: "p-scroll-panel, p-scrollPanel, p-scrollpanel", inputs: ["styleClass", "step"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraScrollPanelComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-scroll-panel',
                    host: { style: 'display: block' },
                    standalone: true,
                    imports: [ScrollPanel],
                    template: `
    <p-scrollpanel [step]="step" [style]="{ width: width, height: height }">
      <ng-content></ng-content>
    </p-scrollpanel>
  `
                }]
        }], propDecorators: { step: [{
                type: Input
            }], height: [{
                type: Input
            }], width: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraScrollPanelComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-scroll-panel.mjs.map
