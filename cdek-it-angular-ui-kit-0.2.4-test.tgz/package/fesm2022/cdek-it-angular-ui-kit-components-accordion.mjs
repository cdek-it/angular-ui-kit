import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component } from '@angular/core';
import { Accordion, AccordionPanel, AccordionHeader, AccordionContent } from 'primeng/accordion';

class ExtraAccordionComponent {
    items = [];
    multiple = false;
    activeValue = '0';
    activeValueChange = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraAccordionComponent, isStandalone: true, selector: "extra-accordion", inputs: { items: "items", multiple: "multiple", activeValue: "activeValue" }, outputs: { activeValueChange: "activeValueChange" }, host: { styleAttribute: "display: block" }, ngImport: i0, template: `
    <p-accordion [multiple]="multiple" [value]="activeValue" (valueChange)="activeValueChange.emit($event)">
      @for (item of items; track item.value) {
        <p-accordion-panel [value]="item.value" [disabled]="item.disabled ?? false">
          <p-accordion-header>
            <div>
              @if (item.icon) {
                <i [class]="item.icon"></i>
              }
              <span>{{ item.header }}</span>
            </div>
          </p-accordion-header>
          <p-accordion-content>{{ item.content }}</p-accordion-content>
        </p-accordion-panel>
      }
    </p-accordion>
  `, isInline: true, dependencies: [{ kind: "component", type: Accordion, selector: "p-accordion", inputs: ["value", "multiple", "styleClass", "expandIcon", "collapseIcon", "selectOnFocus", "transitionOptions"], outputs: ["valueChange", "onClose", "onOpen"] }, { kind: "component", type: AccordionPanel, selector: "p-accordion-panel, p-accordionpanel", inputs: ["value", "disabled"], outputs: ["valueChange"] }, { kind: "component", type: AccordionHeader, selector: "p-accordion-header, p-accordionheader" }, { kind: "component", type: AccordionContent, selector: "p-accordion-content, p-accordioncontent" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraAccordionComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-accordion',
                    host: { style: 'display: block' },
                    standalone: true,
                    imports: [Accordion, AccordionPanel, AccordionHeader, AccordionContent],
                    template: `
    <p-accordion [multiple]="multiple" [value]="activeValue" (valueChange)="activeValueChange.emit($event)">
      @for (item of items; track item.value) {
        <p-accordion-panel [value]="item.value" [disabled]="item.disabled ?? false">
          <p-accordion-header>
            <div>
              @if (item.icon) {
                <i [class]="item.icon"></i>
              }
              <span>{{ item.header }}</span>
            </div>
          </p-accordion-header>
          <p-accordion-content>{{ item.content }}</p-accordion-content>
        </p-accordion-panel>
      }
    </p-accordion>
  `
                }]
        }], propDecorators: { items: [{
                type: Input
            }], multiple: [{
                type: Input
            }], activeValue: [{
                type: Input
            }], activeValueChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraAccordionComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-accordion.mjs.map
