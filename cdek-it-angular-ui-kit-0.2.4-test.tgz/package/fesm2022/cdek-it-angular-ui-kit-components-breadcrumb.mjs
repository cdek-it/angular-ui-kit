import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Breadcrumb } from 'primeng/breadcrumb';

class ExtraBreadcrumbComponent {
    model = [];
    home = undefined;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraBreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraBreadcrumbComponent, isStandalone: true, selector: "extra-breadcrumb", inputs: { model: "model", home: "home" }, ngImport: i0, template: ` <p-breadcrumb [model]="model" [home]="home"></p-breadcrumb> `, isInline: true, dependencies: [{ kind: "component", type: Breadcrumb, selector: "p-breadcrumb", inputs: ["model", "style", "styleClass", "home", "homeAriaLabel"], outputs: ["onItemClick"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-breadcrumb',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Breadcrumb],
                    template: ` <p-breadcrumb [model]="model" [home]="home"></p-breadcrumb> `
                }]
        }], propDecorators: { model: [{
                type: Input
            }], home: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraBreadcrumbComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-breadcrumb.mjs.map
