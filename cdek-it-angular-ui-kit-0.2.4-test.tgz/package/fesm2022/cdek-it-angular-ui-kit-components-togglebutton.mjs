import * as i0 from '@angular/core';
import { EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgClass } from '@angular/common';
import { ToggleButton } from 'primeng/togglebutton';

class ExtraToggleButtonComponent {
    cdr;
    constructor(cdr) {
        this.cdr = cdr;
    }
    onLabel = 'Вкл';
    offLabel = 'Выкл';
    onIcon = undefined;
    offIcon = undefined;
    iconPos = 'left';
    size = 'base';
    disabled = false;
    iconOnly = false;
    allowEmpty = undefined;
    fluid = false;
    ariaLabel = undefined;
    ariaLabelledBy = undefined;
    inputId = undefined;
    tabindex = undefined;
    autofocus = undefined;
    onChange = new EventEmitter();
    modelValue = false;
    _onChange = () => { };
    _onTouched = () => { };
    get primeSize() {
        if (this.size === 'small')
            return 'small';
        if (this.size === 'large' || this.size === 'xlarge')
            return 'large';
        return undefined;
    }
    get extraClasses() {
        return {
            'p-togglebutton-xlarge': this.size === 'xlarge',
            'p-togglebutton-icon-only': this.iconOnly,
        };
    }
    onChangeHandler(event) {
        this._onChange(event.checked);
        this._onTouched();
        this.onChange.emit(event);
    }
    writeValue(value) {
        this.modelValue = value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this.cdr.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToggleButtonComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraToggleButtonComponent, isStandalone: true, selector: "extra-toggle-button", inputs: { onLabel: "onLabel", offLabel: "offLabel", onIcon: "onIcon", offIcon: "offIcon", iconPos: "iconPos", size: "size", disabled: "disabled", iconOnly: "iconOnly", allowEmpty: "allowEmpty", fluid: "fluid", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy", inputId: "inputId", tabindex: "tabindex", autofocus: "autofocus" }, outputs: { onChange: "onChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraToggleButtonComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <p-togglebutton
      [ngClass]="extraClasses"
      [onLabel]="onLabel"
      [offLabel]="offLabel"
      [onIcon]="onIcon"
      [offIcon]="offIcon"
      [iconPos]="iconPos"
      [size]="primeSize!"
      [disabled]="disabled"
      [allowEmpty]="allowEmpty"
      [fluid]="fluid"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [inputId]="inputId"
      [tabindex]="tabindex"
      [autofocus]="autofocus"
      [(ngModel)]="modelValue"
      (onChange)="onChangeHandler($event)"
    ></p-togglebutton>
  `, isInline: true, dependencies: [{ kind: "component", type: ToggleButton, selector: "p-toggleButton, p-togglebutton, p-toggle-button", inputs: ["onLabel", "offLabel", "onIcon", "offIcon", "ariaLabel", "ariaLabelledBy", "styleClass", "inputId", "tabindex", "iconPos", "autofocus", "size", "allowEmpty", "fluid"], outputs: ["onChange"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraToggleButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-toggle-button',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [ToggleButton, NgClass, FormsModule],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraToggleButtonComponent),
                            multi: true,
                        },
                    ],
                    template: `
    <p-togglebutton
      [ngClass]="extraClasses"
      [onLabel]="onLabel"
      [offLabel]="offLabel"
      [onIcon]="onIcon"
      [offIcon]="offIcon"
      [iconPos]="iconPos"
      [size]="primeSize!"
      [disabled]="disabled"
      [allowEmpty]="allowEmpty"
      [fluid]="fluid"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [inputId]="inputId"
      [tabindex]="tabindex"
      [autofocus]="autofocus"
      [(ngModel)]="modelValue"
      (onChange)="onChangeHandler($event)"
    ></p-togglebutton>
  `,
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { onLabel: [{
                type: Input
            }], offLabel: [{
                type: Input
            }], onIcon: [{
                type: Input
            }], offIcon: [{
                type: Input
            }], iconPos: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], allowEmpty: [{
                type: Input
            }], fluid: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], inputId: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], autofocus: [{
                type: Input
            }], onChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraToggleButtonComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-togglebutton.mjs.map
