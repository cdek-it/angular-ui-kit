import * as i0 from '@angular/core';
import { HostListener, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { PanelMenu } from 'primeng/panelmenu';

class ExtraPanelMenuComponent {
    el;
    model = [];
    multiple = false;
    tabindex = undefined;
    activeItemId = null;
    constructor(el) {
        this.el = el;
    }
    onItemClick(event) {
        const target = event.target;
        if (target.closest('.p-panelmenu-header'))
            return;
        const item = target.closest('.p-panelmenu-item');
        if (!item)
            return;
        this.activeItemId = item.id || null;
        this.applyActiveClass();
    }
    ngAfterViewChecked() {
        if (this.activeItemId) {
            this.applyActiveClass();
        }
    }
    applyActiveClass() {
        const root = this.el.nativeElement;
        root
            .querySelectorAll('.p-panelmenu-item-active')
            .forEach((el) => el.classList.remove('p-panelmenu-item-active'));
        if (this.activeItemId) {
            const active = root.querySelector(`#${CSS.escape(this.activeItemId)}`);
            if (active) {
                active.classList.add('p-panelmenu-item-active');
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPanelMenuComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraPanelMenuComponent, isStandalone: true, selector: "extra-panelmenu", inputs: { model: "model", multiple: "multiple", tabindex: "tabindex" }, host: { listeners: { "click": "onItemClick($event)" } }, ngImport: i0, template: ` <p-panelmenu [model]="model" [multiple]="multiple" [tabindex]="tabindex"></p-panelmenu> `, isInline: true, dependencies: [{ kind: "component", type: PanelMenu, selector: "p-panelMenu, p-panelmenu, p-panel-menu", inputs: ["model", "styleClass", "multiple", "transitionOptions", "id", "tabindex"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPanelMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-panelmenu',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [PanelMenu],
                    template: ` <p-panelmenu [model]="model" [multiple]="multiple" [tabindex]="tabindex"></p-panelmenu> `
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { model: [{
                type: Input
            }], multiple: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], onItemClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraPanelMenuComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-panelmenu.mjs.map
