import * as i0 from '@angular/core';
import { Directive, EventEmitter, TemplateRef, Output, ContentChild, Input, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from 'primeng/galleria';
import { GalleriaModule } from 'primeng/galleria';
import * as i3 from 'primeng/api';
import { PrimeTemplate } from 'primeng/api';

class ExtraGalleriaItemDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraGalleriaItemDirective, isStandalone: true, selector: "[extraGalleriaItem]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraGalleriaItem]', standalone: true }]
        }] });
class ExtraGalleriaThumbnailDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaThumbnailDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraGalleriaThumbnailDirective, isStandalone: true, selector: "[extraGalleriaThumbnail]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaThumbnailDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraGalleriaThumbnail]', standalone: true }]
        }] });
class ExtraGalleriaCaptionDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaCaptionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraGalleriaCaptionDirective, isStandalone: true, selector: "[extraGalleriaCaption]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaCaptionDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraGalleriaCaption]', standalone: true }]
        }] });
class ExtraGalleriaIndicatorDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaIndicatorDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraGalleriaIndicatorDirective, isStandalone: true, selector: "[extraGalleriaIndicator]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaIndicatorDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraGalleriaIndicator]', standalone: true }]
        }] });
class ExtraGalleriaHeaderDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraGalleriaHeaderDirective, isStandalone: true, selector: "[extraGalleriaHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraGalleriaHeader]', standalone: true }]
        }] });
class ExtraGalleriaFooterDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraGalleriaFooterDirective, isStandalone: true, selector: "[extraGalleriaFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraGalleriaFooter]', standalone: true }]
        }] });
class ExtraGalleriaComponent {
    value = [];
    numVisible = 3;
    showItemNavigators = false;
    showItemNavigatorsOnHover = false;
    showThumbnails = true;
    showThumbnailNavigators = true;
    showIndicators = false;
    showIndicatorsOnItem = false;
    circular = false;
    autoPlay = false;
    transitionInterval = 4000;
    fullScreen = false;
    visible = false;
    containerClass = undefined;
    containerStyle = undefined;
    responsiveOptions = undefined;
    itemTemplate = null;
    thumbnailTemplate = null;
    captionTemplate = null;
    indicatorTemplate = null;
    headerTemplate = null;
    footerTemplate = null;
    activeIndexChange = new EventEmitter();
    visibleChange = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraGalleriaComponent, isStandalone: true, selector: "extra-galleria", inputs: { value: "value", numVisible: "numVisible", showItemNavigators: "showItemNavigators", showItemNavigatorsOnHover: "showItemNavigatorsOnHover", showThumbnails: "showThumbnails", showThumbnailNavigators: "showThumbnailNavigators", showIndicators: "showIndicators", showIndicatorsOnItem: "showIndicatorsOnItem", circular: "circular", autoPlay: "autoPlay", transitionInterval: "transitionInterval", fullScreen: "fullScreen", visible: "visible", containerClass: "containerClass", containerStyle: "containerStyle", responsiveOptions: "responsiveOptions" }, outputs: { activeIndexChange: "activeIndexChange", visibleChange: "visibleChange" }, host: { styleAttribute: "display: contents" }, queries: [{ propertyName: "itemTemplate", first: true, predicate: ExtraGalleriaItemDirective, descendants: true, read: TemplateRef }, { propertyName: "thumbnailTemplate", first: true, predicate: ExtraGalleriaThumbnailDirective, descendants: true, read: TemplateRef }, { propertyName: "captionTemplate", first: true, predicate: ExtraGalleriaCaptionDirective, descendants: true, read: TemplateRef }, { propertyName: "indicatorTemplate", first: true, predicate: ExtraGalleriaIndicatorDirective, descendants: true, read: TemplateRef }, { propertyName: "headerTemplate", first: true, predicate: ExtraGalleriaHeaderDirective, descendants: true, read: TemplateRef }, { propertyName: "footerTemplate", first: true, predicate: ExtraGalleriaFooterDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-galleria
      [value]="value"
      [numVisible]="numVisible"
      [showItemNavigators]="showItemNavigators"
      [showItemNavigatorsOnHover]="showItemNavigatorsOnHover"
      [showThumbnails]="showThumbnails"
      [showThumbnailNavigators]="showThumbnailNavigators"
      [showIndicators]="showIndicators"
      [showIndicatorsOnItem]="showIndicatorsOnItem"
      [circular]="circular"
      [autoPlay]="autoPlay"
      [transitionInterval]="transitionInterval"
      [fullScreen]="fullScreen"
      [visible]="visible"
      [containerClass]="containerClass"
      [containerStyle]="containerStyle"
      [responsiveOptions]="responsiveOptions"
      (activeIndexChange)="activeIndexChange.emit($event)"
      (visibleChange)="visibleChange.emit($event)"
    >
      <ng-template pTemplate="item" let-item>
        @if (itemTemplate) {
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="thumbnail" let-item>
        @if (thumbnailTemplate) {
          <ng-container
            [ngTemplateOutlet]="thumbnailTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="caption" let-item>
        @if (captionTemplate) {
          <ng-container
            [ngTemplateOutlet]="captionTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="indicator" let-item>
        @if (indicatorTemplate) {
          <ng-container
            [ngTemplateOutlet]="indicatorTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="header">
        @if (headerTemplate) {
          <ng-container [ngTemplateOutlet]="headerTemplate"></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="footer">
        @if (footerTemplate) {
          <ng-container [ngTemplateOutlet]="footerTemplate"></ng-container>
        }
      </ng-template>
    </p-galleria>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: GalleriaModule }, { kind: "component", type: i2.Galleria, selector: "p-galleria", inputs: ["activeIndex", "fullScreen", "id", "value", "numVisible", "responsiveOptions", "showItemNavigators", "showThumbnailNavigators", "showItemNavigatorsOnHover", "changeItemOnIndicatorHover", "circular", "autoPlay", "shouldStopAutoplayByClick", "transitionInterval", "showThumbnails", "thumbnailsPosition", "verticalThumbnailViewPortHeight", "showIndicators", "showIndicatorsOnItem", "indicatorsPosition", "baseZIndex", "maskClass", "containerClass", "containerStyle", "showTransitionOptions", "hideTransitionOptions", "visible"], outputs: ["activeIndexChange", "visibleChange"] }, { kind: "directive", type: i3.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraGalleriaComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-galleria',
                    standalone: true,
                    imports: [CommonModule, GalleriaModule, PrimeTemplate],
                    host: { style: 'display: contents' },
                    template: `
    <p-galleria
      [value]="value"
      [numVisible]="numVisible"
      [showItemNavigators]="showItemNavigators"
      [showItemNavigatorsOnHover]="showItemNavigatorsOnHover"
      [showThumbnails]="showThumbnails"
      [showThumbnailNavigators]="showThumbnailNavigators"
      [showIndicators]="showIndicators"
      [showIndicatorsOnItem]="showIndicatorsOnItem"
      [circular]="circular"
      [autoPlay]="autoPlay"
      [transitionInterval]="transitionInterval"
      [fullScreen]="fullScreen"
      [visible]="visible"
      [containerClass]="containerClass"
      [containerStyle]="containerStyle"
      [responsiveOptions]="responsiveOptions"
      (activeIndexChange)="activeIndexChange.emit($event)"
      (visibleChange)="visibleChange.emit($event)"
    >
      <ng-template pTemplate="item" let-item>
        @if (itemTemplate) {
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="thumbnail" let-item>
        @if (thumbnailTemplate) {
          <ng-container
            [ngTemplateOutlet]="thumbnailTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="caption" let-item>
        @if (captionTemplate) {
          <ng-container
            [ngTemplateOutlet]="captionTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="indicator" let-item>
        @if (indicatorTemplate) {
          <ng-container
            [ngTemplateOutlet]="indicatorTemplate"
            [ngTemplateOutletContext]="{ $implicit: item }"
          ></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="header">
        @if (headerTemplate) {
          <ng-container [ngTemplateOutlet]="headerTemplate"></ng-container>
        }
      </ng-template>
      <ng-template pTemplate="footer">
        @if (footerTemplate) {
          <ng-container [ngTemplateOutlet]="footerTemplate"></ng-container>
        }
      </ng-template>
    </p-galleria>
  `
                }]
        }], propDecorators: { value: [{
                type: Input
            }], numVisible: [{
                type: Input
            }], showItemNavigators: [{
                type: Input
            }], showItemNavigatorsOnHover: [{
                type: Input
            }], showThumbnails: [{
                type: Input
            }], showThumbnailNavigators: [{
                type: Input
            }], showIndicators: [{
                type: Input
            }], showIndicatorsOnItem: [{
                type: Input
            }], circular: [{
                type: Input
            }], autoPlay: [{
                type: Input
            }], transitionInterval: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], visible: [{
                type: Input
            }], containerClass: [{
                type: Input
            }], containerStyle: [{
                type: Input
            }], responsiveOptions: [{
                type: Input
            }], itemTemplate: [{
                type: ContentChild,
                args: [ExtraGalleriaItemDirective, { read: TemplateRef }]
            }], thumbnailTemplate: [{
                type: ContentChild,
                args: [ExtraGalleriaThumbnailDirective, { read: TemplateRef }]
            }], captionTemplate: [{
                type: ContentChild,
                args: [ExtraGalleriaCaptionDirective, { read: TemplateRef }]
            }], indicatorTemplate: [{
                type: ContentChild,
                args: [ExtraGalleriaIndicatorDirective, { read: TemplateRef }]
            }], headerTemplate: [{
                type: ContentChild,
                args: [ExtraGalleriaHeaderDirective, { read: TemplateRef }]
            }], footerTemplate: [{
                type: ContentChild,
                args: [ExtraGalleriaFooterDirective, { read: TemplateRef }]
            }], activeIndexChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraGalleriaCaptionDirective, ExtraGalleriaComponent, ExtraGalleriaFooterDirective, ExtraGalleriaHeaderDirective, ExtraGalleriaIndicatorDirective, ExtraGalleriaItemDirective, ExtraGalleriaThumbnailDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-galleria.mjs.map
