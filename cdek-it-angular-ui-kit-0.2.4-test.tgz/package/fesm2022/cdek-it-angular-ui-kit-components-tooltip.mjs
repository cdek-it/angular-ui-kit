import * as i0 from '@angular/core';
import { inject, Input, Directive } from '@angular/core';
import * as i1 from 'primeng/tooltip';
import { Tooltip } from 'primeng/tooltip';

class ExtraTooltipDirective {
    delegate = inject(Tooltip);
    /** Текст подсказки — соответствует Figma-свойству `text-tooltip`. */
    tooltip;
    /** Позиция подсказки относительно хост-элемента. */
    position = 'right';
    /** Событие, по которому показывается подсказка. */
    event = 'hover';
    /** Задержка перед появлением подсказки в миллисекундах. */
    showDelay;
    /** Задержка перед скрытием подсказки в миллисекундах. */
    hideDelay;
    /**
     * Отключает подсказку. Названо `tooltipDisabled`, а не `disabled`, чтобы не
     * конфликтовать с одноимённым свойством хост-компонента (например, `extra-button`).
     */
    tooltipDisabled = false;
    ngOnChanges(_changes) {
        // Пробрасываем своё типизированное API в опции PrimeNG Tooltip. PrimeNG
        // читает эти опции при показе (show → create/updateText/align), а
        // `tooltipEvent` — при навешивании слушателей в `onAfterViewInit`,
        // который выполняется строго после `ngOnChanges`.
        this.delegate.setOption({
            tooltipLabel: this.tooltip ?? null,
            tooltipPosition: this.position,
            tooltipEvent: this.event,
            showDelay: this.showDelay,
            hideDelay: this.hideDelay,
            disabled: this.tooltipDisabled
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraTooltipDirective, isStandalone: true, selector: "[extra-tooltip]", inputs: { tooltip: ["extra-tooltip", "tooltip"], position: "position", event: "event", showDelay: "showDelay", hideDelay: "hideDelay", tooltipDisabled: "tooltipDisabled" }, usesOnChanges: true, hostDirectives: [{ directive: i1.Tooltip }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[extra-tooltip]',
                    standalone: true,
                    hostDirectives: [Tooltip]
                }]
        }], propDecorators: { tooltip: [{
                type: Input,
                args: ['extra-tooltip']
            }], position: [{
                type: Input
            }], event: [{
                type: Input
            }], showDelay: [{
                type: Input
            }], hideDelay: [{
                type: Input
            }], tooltipDisabled: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraTooltipDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-tooltip.mjs.map
