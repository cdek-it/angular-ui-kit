import * as i0 from '@angular/core';
import { ContentChildren, Input, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Card } from 'primeng/card';
import * as i1 from 'primeng/api';
import { SharedModule, PrimeTemplate } from 'primeng/api';

class ExtraCardComponent {
    cdr;
    title = '';
    subtitle = '';
    overlay = false;
    templates;
    headerTpl;
    contentTpl;
    footerTpl;
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterContentInit() {
        this.templates.forEach((tpl) => {
            switch (tpl.getType()) {
                case 'header':
                    this.headerTpl = tpl;
                    break;
                case 'content':
                    this.contentTpl = tpl;
                    break;
                case 'footer':
                    this.footerTpl = tpl;
                    break;
            }
        });
        this.cdr.detectChanges();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCardComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraCardComponent, isStandalone: true, selector: "extra-card", inputs: { title: "title", subtitle: "subtitle", overlay: "overlay" }, host: { styleAttribute: "display: block" }, queries: [{ propertyName: "templates", predicate: PrimeTemplate }], ngImport: i0, template: `
    <p-card [styleClass]="overlay ? 'shadow-md' : ''">
      @if (headerTpl) {
        <ng-template pTemplate="header">
          <ng-container [ngTemplateOutlet]="headerTpl.template"></ng-container>
        </ng-template>
      }
      @if (title || subtitle) {
        <ng-template pTemplate="title">
          <div class="p-card-caption">
            @if (title) {
              <div class="p-card-title m-0" data-pc-section="title">{{ title }}</div>
            }
            @if (subtitle) {
              <div class="p-card-subtitle m-0" data-pc-section="subtitle">{{ subtitle }}</div>
            }
          </div>
        </ng-template>
      }
      @if (contentTpl) {
        <ng-template pTemplate="content">
          <ng-container [ngTemplateOutlet]="contentTpl.template"></ng-container>
        </ng-template>
      }
      @if (footerTpl) {
        <ng-template pTemplate="footer">
          <ng-container [ngTemplateOutlet]="footerTpl.template"></ng-container>
        </ng-template>
      }
    </p-card>
  `, isInline: true, dependencies: [{ kind: "component", type: Card, selector: "p-card", inputs: ["header", "subheader", "style", "styleClass"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCardComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-card',
                    host: { style: 'display: block' },
                    standalone: true,
                    imports: [Card, SharedModule, NgTemplateOutlet],
                    template: `
    <p-card [styleClass]="overlay ? 'shadow-md' : ''">
      @if (headerTpl) {
        <ng-template pTemplate="header">
          <ng-container [ngTemplateOutlet]="headerTpl.template"></ng-container>
        </ng-template>
      }
      @if (title || subtitle) {
        <ng-template pTemplate="title">
          <div class="p-card-caption">
            @if (title) {
              <div class="p-card-title m-0" data-pc-section="title">{{ title }}</div>
            }
            @if (subtitle) {
              <div class="p-card-subtitle m-0" data-pc-section="subtitle">{{ subtitle }}</div>
            }
          </div>
        </ng-template>
      }
      @if (contentTpl) {
        <ng-template pTemplate="content">
          <ng-container [ngTemplateOutlet]="contentTpl.template"></ng-container>
        </ng-template>
      }
      @if (footerTpl) {
        <ng-template pTemplate="footer">
          <ng-container [ngTemplateOutlet]="footerTpl.template"></ng-container>
        </ng-template>
      }
    </p-card>
  `
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], overlay: [{
                type: Input
            }], templates: [{
                type: ContentChildren,
                args: [PrimeTemplate]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraCardComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-card.mjs.map
