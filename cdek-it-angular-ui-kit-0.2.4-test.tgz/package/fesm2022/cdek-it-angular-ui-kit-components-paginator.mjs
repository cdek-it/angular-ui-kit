import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component } from '@angular/core';
import { Paginator } from 'primeng/paginator';

class ExtraPaginatorComponent {
    first = 0;
    rows = 10;
    totalRecords = 0;
    rowsPerPageOptions;
    currentPageReportTemplate = '{currentPage} из {totalPages}';
    showCurrentPageReport = false;
    showFirstLastIcon = true;
    showJumpToPageDropdown = false;
    showJumpToPageInput = false;
    showPageLinks = true;
    pageLinkSize = 5;
    alwaysShow = true;
    onPageChange = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraPaginatorComponent, isStandalone: true, selector: "extra-paginator", inputs: { first: "first", rows: "rows", totalRecords: "totalRecords", rowsPerPageOptions: "rowsPerPageOptions", currentPageReportTemplate: "currentPageReportTemplate", showCurrentPageReport: "showCurrentPageReport", showFirstLastIcon: "showFirstLastIcon", showJumpToPageDropdown: "showJumpToPageDropdown", showJumpToPageInput: "showJumpToPageInput", showPageLinks: "showPageLinks", pageLinkSize: "pageLinkSize", alwaysShow: "alwaysShow" }, outputs: { onPageChange: "onPageChange" }, ngImport: i0, template: `
    <p-paginator
      [first]="first"
      [rows]="rows"
      [totalRecords]="totalRecords"
      [rowsPerPageOptions]="rowsPerPageOptions"
      [currentPageReportTemplate]="currentPageReportTemplate"
      [showCurrentPageReport]="showCurrentPageReport"
      [showFirstLastIcon]="showFirstLastIcon"
      [showJumpToPageDropdown]="showJumpToPageDropdown"
      [showJumpToPageInput]="showJumpToPageInput"
      [showPageLinks]="showPageLinks"
      [pageLinkSize]="pageLinkSize"
      [alwaysShow]="alwaysShow"
      (onPageChange)="onPageChange.emit($event)"
    ></p-paginator>
  `, isInline: true, dependencies: [{ kind: "component", type: Paginator, selector: "p-paginator", inputs: ["pageLinkSize", "styleClass", "alwaysShow", "dropdownAppendTo", "templateLeft", "templateRight", "dropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showFirstLastIcon", "totalRecords", "rows", "rowsPerPageOptions", "showJumpToPageDropdown", "showJumpToPageInput", "jumpToPageItemTemplate", "showPageLinks", "locale", "dropdownItemTemplate", "first", "appendTo"], outputs: ["onPageChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraPaginatorComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-paginator',
                    standalone: true,
                    imports: [Paginator],
                    template: `
    <p-paginator
      [first]="first"
      [rows]="rows"
      [totalRecords]="totalRecords"
      [rowsPerPageOptions]="rowsPerPageOptions"
      [currentPageReportTemplate]="currentPageReportTemplate"
      [showCurrentPageReport]="showCurrentPageReport"
      [showFirstLastIcon]="showFirstLastIcon"
      [showJumpToPageDropdown]="showJumpToPageDropdown"
      [showJumpToPageInput]="showJumpToPageInput"
      [showPageLinks]="showPageLinks"
      [pageLinkSize]="pageLinkSize"
      [alwaysShow]="alwaysShow"
      (onPageChange)="onPageChange.emit($event)"
    ></p-paginator>
  `
                }]
        }], propDecorators: { first: [{
                type: Input
            }], rows: [{
                type: Input
            }], totalRecords: [{
                type: Input
            }], rowsPerPageOptions: [{
                type: Input
            }], currentPageReportTemplate: [{
                type: Input
            }], showCurrentPageReport: [{
                type: Input
            }], showFirstLastIcon: [{
                type: Input
            }], showJumpToPageDropdown: [{
                type: Input
            }], showJumpToPageInput: [{
                type: Input
            }], showPageLinks: [{
                type: Input
            }], pageLinkSize: [{
                type: Input
            }], alwaysShow: [{
                type: Input
            }], onPageChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraPaginatorComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-paginator.mjs.map
