import * as i0 from '@angular/core';
import { Input, Component } from '@angular/core';
import { NgClass } from '@angular/common';
import { InputGroup } from 'primeng/inputgroup';
import { InputGroupAddon } from 'primeng/inputgroupaddon';

class ExtraInputGroupComponent {
    size = 'base';
    get sizeClass() {
        if (this.size === 'xlarge')
            return 'p-inputgroup-xlg';
        return '';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraInputGroupComponent, isStandalone: true, selector: "extra-input-group", inputs: { size: "size" }, ngImport: i0, template: `
    <p-inputgroup [ngClass]="sizeClass">
      <ng-content></ng-content>
    </p-inputgroup>
  `, isInline: true, dependencies: [{ kind: "component", type: InputGroup, selector: "p-inputgroup, p-inputGroup, p-input-group", inputs: ["styleClass"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputGroupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-input-group',
                    standalone: true,
                    imports: [InputGroup, NgClass],
                    template: `
    <p-inputgroup [ngClass]="sizeClass">
      <ng-content></ng-content>
    </p-inputgroup>
  `
                }]
        }], propDecorators: { size: [{
                type: Input
            }] } });

class ExtraInputGroupAddonComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputGroupAddonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraInputGroupAddonComponent, isStandalone: true, selector: "extra-input-group-addon", ngImport: i0, template: `
    <p-inputgroup-addon>
      <ng-content></ng-content>
    </p-inputgroup-addon>
  `, isInline: true, dependencies: [{ kind: "component", type: InputGroupAddon, selector: "p-inputgroup-addon, p-inputGroupAddon", inputs: ["style", "styleClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputGroupAddonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-input-group-addon',
                    standalone: true,
                    imports: [InputGroupAddon],
                    template: `
    <p-inputgroup-addon>
      <ng-content></ng-content>
    </p-inputgroup-addon>
  `
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraInputGroupAddonComponent, ExtraInputGroupComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-inputgroup.mjs.map
