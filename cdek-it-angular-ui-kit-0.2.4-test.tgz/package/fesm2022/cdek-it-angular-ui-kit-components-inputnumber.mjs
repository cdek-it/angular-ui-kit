import * as i0 from '@angular/core';
import { inject, Injector, EventEmitter, forwardRef, Output, Input, Component } from '@angular/core';
import * as i2 from '@angular/forms';
import { NgControl, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgClass } from '@angular/common';
import { InputNumber } from 'primeng/inputnumber';
import * as i1 from 'primeng/api';
import { SharedModule } from 'primeng/api';

class ExtraInputNumberComponent {
    _injector = inject(Injector);
    _ngControl = null;
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
    }
    size = 'base';
    showButtons = false;
    buttonLayout = 'stacked';
    mode = 'decimal';
    currency;
    locale;
    placeholder = '';
    readonly = false;
    fluid = false;
    min;
    max;
    step = 1;
    prefix;
    suffix;
    minFractionDigits;
    maxFractionDigits;
    useGrouping = true;
    incrementButtonIcon;
    decrementButtonIcon;
    disabled = false;
    get invalid() {
        return this._ngControl?.invalid ?? false;
    }
    onInput = new EventEmitter();
    modelValue = null;
    _onChange = () => { };
    onTouched = () => { };
    get inputSizeClass() {
        if (this.size === 'small')
            return 'p-inputtext-sm';
        if (this.size === 'large' || this.size === 'xlarge')
            return 'p-inputtext-lg';
        return '';
    }
    get sizeClass() {
        return { 'p-inputnumber-xlg': this.size === 'xlarge' };
    }
    onModelChange(value) {
        this.modelValue = value;
        this._onChange(value);
        this.onInput.emit({ value });
    }
    writeValue(value) {
        this.modelValue = value ?? null;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputNumberComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraInputNumberComponent, isStandalone: true, selector: "extra-input-number", inputs: { size: "size", showButtons: "showButtons", buttonLayout: "buttonLayout", mode: "mode", currency: "currency", locale: "locale", placeholder: "placeholder", readonly: "readonly", fluid: "fluid", min: "min", max: "max", step: "step", prefix: "prefix", suffix: "suffix", minFractionDigits: "minFractionDigits", maxFractionDigits: "maxFractionDigits", useGrouping: "useGrouping", incrementButtonIcon: "incrementButtonIcon", decrementButtonIcon: "decrementButtonIcon" }, outputs: { onInput: "onInput" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraInputNumberComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    <p-inputNumber
      [ngClass]="sizeClass"
      [inputStyleClass]="inputSizeClass"
      [showButtons]="showButtons"
      [buttonLayout]="buttonLayout"
      [mode]="mode"
      [currency]="currency"
      [locale]="locale"
      [placeholder]="placeholder"
      [disabled]="disabled"
      [invalid]="invalid"
      [readonly]="readonly"
      [fluid]="fluid"
      [min]="min"
      [max]="max"
      [step]="step"
      [prefix]="prefix"
      [suffix]="suffix"
      [minFractionDigits]="minFractionDigits"
      [maxFractionDigits]="maxFractionDigits"
      [useGrouping]="useGrouping"
      [incrementButtonIcon]="incrementButtonIcon"
      [decrementButtonIcon]="decrementButtonIcon"
      [ngModel]="modelValue"
      (ngModelChange)="onModelChange($event)"
      (onBlur)="onTouched()"
    >
      @if (!incrementButtonIcon) {
        <ng-template pTemplate="incrementbuttonicon">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M12 5v14M5 12h14" />
          </svg>
        </ng-template>
      }
      @if (!decrementButtonIcon) {
        <ng-template pTemplate="decrementbuttonicon">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M5 12h14" />
          </svg>
        </ng-template>
      }
    </p-inputNumber>
  `, isInline: true, dependencies: [{ kind: "component", type: InputNumber, selector: "p-inputNumber, p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraInputNumberComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-input-number',
                    standalone: true,
                    imports: [InputNumber, SharedModule, FormsModule, NgClass],
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraInputNumberComponent),
                            multi: true
                        }
                    ],
                    template: `
    <p-inputNumber
      [ngClass]="sizeClass"
      [inputStyleClass]="inputSizeClass"
      [showButtons]="showButtons"
      [buttonLayout]="buttonLayout"
      [mode]="mode"
      [currency]="currency"
      [locale]="locale"
      [placeholder]="placeholder"
      [disabled]="disabled"
      [invalid]="invalid"
      [readonly]="readonly"
      [fluid]="fluid"
      [min]="min"
      [max]="max"
      [step]="step"
      [prefix]="prefix"
      [suffix]="suffix"
      [minFractionDigits]="minFractionDigits"
      [maxFractionDigits]="maxFractionDigits"
      [useGrouping]="useGrouping"
      [incrementButtonIcon]="incrementButtonIcon"
      [decrementButtonIcon]="decrementButtonIcon"
      [ngModel]="modelValue"
      (ngModelChange)="onModelChange($event)"
      (onBlur)="onTouched()"
    >
      @if (!incrementButtonIcon) {
        <ng-template pTemplate="incrementbuttonicon">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M12 5v14M5 12h14" />
          </svg>
        </ng-template>
      }
      @if (!decrementButtonIcon) {
        <ng-template pTemplate="decrementbuttonicon">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path d="M5 12h14" />
          </svg>
        </ng-template>
      }
    </p-inputNumber>
  `
                }]
        }], propDecorators: { size: [{
                type: Input
            }], showButtons: [{
                type: Input
            }], buttonLayout: [{
                type: Input
            }], mode: [{
                type: Input
            }], currency: [{
                type: Input
            }], locale: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], readonly: [{
                type: Input
            }], fluid: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], prefix: [{
                type: Input
            }], suffix: [{
                type: Input
            }], minFractionDigits: [{
                type: Input
            }], maxFractionDigits: [{
                type: Input
            }], useGrouping: [{
                type: Input
            }], incrementButtonIcon: [{
                type: Input
            }], decrementButtonIcon: [{
                type: Input
            }], onInput: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraInputNumberComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-inputnumber.mjs.map
