import * as i0 from '@angular/core';
import { inject, Injector, EventEmitter, forwardRef, Output, Input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { NgControl, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgTemplateOutlet } from '@angular/common';
import { Checkbox } from 'primeng/checkbox';

let nextInputId = 0;
class ExtraCheckboxComponent {
    _injector = inject(Injector);
    _ngControl = null;
    ngOnInit() {
        this._ngControl = this._injector.get(NgControl, null, { self: true, optional: true });
    }
    label = '';
    labelPosition = 'right';
    caption = '';
    indeterminate = false;
    onChange = new EventEmitter();
    /** Уникальный id поля для связи label ↔ input. */
    inputId = `extra-checkbox-${nextInputId++}`;
    disabled = false;
    modelValue = false;
    get invalid() {
        return this._ngControl?.invalid ?? false;
    }
    _onChange = () => { };
    _onTouched = () => { };
    onChangeHandler(event) {
        const checked = !!event.checked;
        this.modelValue = checked;
        this._onChange(checked);
        this._onTouched();
        this.onChange.emit({ checked, originalEvent: event.originalEvent });
    }
    writeValue(value) {
        this.modelValue = !!value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraCheckboxComponent, isStandalone: true, selector: "extra-checkbox", inputs: { label: "label", labelPosition: "labelPosition", caption: "caption", indeterminate: "indeterminate" }, outputs: { onChange: "onChange" }, host: { styleAttribute: "display: contents" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtraCheckboxComponent),
                multi: true
            }
        ], ngImport: i0, template: `
    @if (label || caption) {
      <div class="extra-checkbox" [class.extra-checkbox--left]="labelPosition === 'left'">
        <ng-container [ngTemplateOutlet]="fieldTpl" />
        <div class="extra-checkbox-body">
          @if (label) {
            <label class="checkbox-label" [class.checkbox-label--disabled]="disabled" [for]="inputId">{{
              label
            }}</label>
          }
          @if (caption) {
            <div class="checkbox-caption" [class.checkbox-caption--disabled]="disabled">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="fieldTpl" />
    }

    <ng-template #fieldTpl>
      <p-checkbox
        [binary]="true"
        [(ngModel)]="modelValue"
        [disabled]="disabled"
        [indeterminate]="indeterminate"
        [class.p-checkbox-indeterminate]="indeterminate"
        [invalid]="invalid"
        [inputId]="inputId"
        (onChange)="onChangeHandler($event)"
      ></p-checkbox>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraCheckboxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-checkbox',
                    standalone: true,
                    imports: [Checkbox, FormsModule, NgTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: { style: 'display: contents' },
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtraCheckboxComponent),
                            multi: true
                        }
                    ],
                    template: `
    @if (label || caption) {
      <div class="extra-checkbox" [class.extra-checkbox--left]="labelPosition === 'left'">
        <ng-container [ngTemplateOutlet]="fieldTpl" />
        <div class="extra-checkbox-body">
          @if (label) {
            <label class="checkbox-label" [class.checkbox-label--disabled]="disabled" [for]="inputId">{{
              label
            }}</label>
          }
          @if (caption) {
            <div class="checkbox-caption" [class.checkbox-caption--disabled]="disabled">{{ caption }}</div>
          }
        </div>
      </div>
    } @else {
      <ng-container [ngTemplateOutlet]="fieldTpl" />
    }

    <ng-template #fieldTpl>
      <p-checkbox
        [binary]="true"
        [(ngModel)]="modelValue"
        [disabled]="disabled"
        [indeterminate]="indeterminate"
        [class.p-checkbox-indeterminate]="indeterminate"
        [invalid]="invalid"
        [inputId]="inputId"
        (onChange)="onChangeHandler($event)"
      ></p-checkbox>
    </ng-template>
  `
                }]
        }], propDecorators: { label: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], caption: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], onChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraCheckboxComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-checkbox.mjs.map
