import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component } from '@angular/core';
import { Skeleton } from 'primeng/skeleton';

class ExtraSkeletonComponent {
    shape = 'rectangle';
    animation = 'wave';
    width = '100%';
    height = '1rem';
    size = undefined;
    borderRadius = undefined;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.15", type: ExtraSkeletonComponent, isStandalone: true, selector: "extra-skeleton", inputs: { shape: "shape", animation: "animation", width: "width", height: "height", size: "size", borderRadius: "borderRadius" }, host: { styleAttribute: "display: block" }, ngImport: i0, template: `
    <p-skeleton
      [shape]="shape"
      [animation]="animation"
      [width]="width"
      [height]="height"
      [size]="size"
      [borderRadius]="borderRadius"
    ></p-skeleton>
  `, isInline: true, dependencies: [{ kind: "component", type: Skeleton, selector: "p-skeleton", inputs: ["styleClass", "shape", "animation", "borderRadius", "size", "width", "height"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraSkeletonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-skeleton',
                    host: { style: 'display: block' },
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Skeleton],
                    template: `
    <p-skeleton
      [shape]="shape"
      [animation]="animation"
      [width]="width"
      [height]="height"
      [size]="size"
      [borderRadius]="borderRadius"
    ></p-skeleton>
  `
                }]
        }], propDecorators: { shape: [{
                type: Input
            }], animation: [{
                type: Input
            }], width: [{
                type: Input
            }], height: [{
                type: Input
            }], size: [{
                type: Input
            }], borderRadius: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraSkeletonComponent };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-skeleton.mjs.map
