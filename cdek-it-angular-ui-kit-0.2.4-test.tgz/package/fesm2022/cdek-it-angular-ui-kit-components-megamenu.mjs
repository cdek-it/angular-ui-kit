import * as i0 from '@angular/core';
import { Directive, TemplateRef, ContentChild, Input, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { MegaMenu } from 'primeng/megamenu';
import { PrimeTemplate } from 'primeng/api';
import { Badge } from 'primeng/badge';

class ExtraMegaMenuItemDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMegaMenuItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.15", type: ExtraMegaMenuItemDirective, isStandalone: true, selector: "[extraMegaMenuItem]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMegaMenuItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[extraMegaMenuItem]', standalone: true }]
        }] });
class ExtraMegaMenuComponent {
    model = [];
    orientation = 'horizontal';
    breakpoint = '960px';
    scrollHeight = '';
    disabled = false;
    ariaLabel = undefined;
    ariaLabelledBy = undefined;
    tabindex = 0;
    itemTemplate = null;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMegaMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.15", type: ExtraMegaMenuComponent, isStandalone: true, selector: "extra-megamenu", inputs: { model: "model", orientation: "orientation", breakpoint: "breakpoint", scrollHeight: "scrollHeight", disabled: "disabled", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy", tabindex: "tabindex" }, host: { styleAttribute: "display: contents" }, queries: [{ propertyName: "itemTemplate", first: true, predicate: ExtraMegaMenuItemDirective, descendants: true, read: TemplateRef }], ngImport: i0, template: `
    <p-megamenu
      [model]="model"
      [orientation]="orientation"
      [breakpoint]="breakpoint"
      [scrollHeight]="scrollHeight"
      [disabled]="disabled"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [tabindex]="tabindex"
    >
      <ng-template pTemplate="item" let-item let-hasSubmenu="hasSubmenu">
        @if (itemTemplate) {
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item, hasSubmenu: hasSubmenu }"
          >
          </ng-container>
        } @else {
          <a
            class="p-megamenu-item-link"
            role="menuitem"
            tabindex="0"
            [class.p-disabled]="item.disabled"
            [attr.href]="item.url || null"
            [attr.target]="item.target || null"
          >
            @if (item.icon) {
              <span [class]="item.icon + ' p-megamenu-item-icon'"></span>
            }
            @if ($any(item).description) {
              <div class="megamenu-item-label">
                <span class="p-megamenu-item-label">{{ item.label }}</span>
                <small class="megamenu-item-caption">{{ $any(item).description }}</small>
              </div>
            } @else {
              <span class="p-megamenu-item-label">{{ item.label }}</span>
            }
            @if ($any(item).badge) {
              <p-badge [value]="$any(item).badge"></p-badge>
            }
            @if (hasSubmenu) {
              <span class="p-megamenu-submenu-icon ti ti-chevron-down"></span>
            }
          </a>
        }
      </ng-template>
    </p-megamenu>
  `, isInline: true, dependencies: [{ kind: "component", type: MegaMenu, selector: "p-megaMenu, p-megamenu, p-mega-menu", inputs: ["model", "styleClass", "orientation", "id", "ariaLabel", "ariaLabelledBy", "breakpoint", "scrollHeight", "disabled", "tabindex"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.15", ngImport: i0, type: ExtraMegaMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'extra-megamenu',
                    host: { style: 'display: contents' },
                    standalone: true,
                    imports: [MegaMenu, PrimeTemplate, NgTemplateOutlet, Badge],
                    template: `
    <p-megamenu
      [model]="model"
      [orientation]="orientation"
      [breakpoint]="breakpoint"
      [scrollHeight]="scrollHeight"
      [disabled]="disabled"
      [ariaLabel]="ariaLabel"
      [ariaLabelledBy]="ariaLabelledBy"
      [tabindex]="tabindex"
    >
      <ng-template pTemplate="item" let-item let-hasSubmenu="hasSubmenu">
        @if (itemTemplate) {
          <ng-container
            [ngTemplateOutlet]="itemTemplate"
            [ngTemplateOutletContext]="{ $implicit: item, hasSubmenu: hasSubmenu }"
          >
          </ng-container>
        } @else {
          <a
            class="p-megamenu-item-link"
            role="menuitem"
            tabindex="0"
            [class.p-disabled]="item.disabled"
            [attr.href]="item.url || null"
            [attr.target]="item.target || null"
          >
            @if (item.icon) {
              <span [class]="item.icon + ' p-megamenu-item-icon'"></span>
            }
            @if ($any(item).description) {
              <div class="megamenu-item-label">
                <span class="p-megamenu-item-label">{{ item.label }}</span>
                <small class="megamenu-item-caption">{{ $any(item).description }}</small>
              </div>
            } @else {
              <span class="p-megamenu-item-label">{{ item.label }}</span>
            }
            @if ($any(item).badge) {
              <p-badge [value]="$any(item).badge"></p-badge>
            }
            @if (hasSubmenu) {
              <span class="p-megamenu-submenu-icon ti ti-chevron-down"></span>
            }
          </a>
        }
      </ng-template>
    </p-megamenu>
  `
                }]
        }], propDecorators: { model: [{
                type: Input
            }], orientation: [{
                type: Input
            }], breakpoint: [{
                type: Input
            }], scrollHeight: [{
                type: Input
            }], disabled: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], tabindex: [{
                type: Input
            }], itemTemplate: [{
                type: ContentChild,
                args: [ExtraMegaMenuItemDirective, { read: TemplateRef }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ExtraMegaMenuComponent, ExtraMegaMenuItemDirective };
//# sourceMappingURL=cdek-it-angular-ui-kit-components-megamenu.mjs.map
